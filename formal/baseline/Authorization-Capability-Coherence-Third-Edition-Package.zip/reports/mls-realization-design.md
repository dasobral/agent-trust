# Phases 3–5 design and critical validation: external authorization composed with MLS

## Executive verdict

A non-vacuous commit-immediate realization is feasible, but not from RFC 9420 alone. The smallest credible realization has three jointly trusted enforcement elements:

1. a **linearizable Authorization, Permit, and Fence service (APF)** that orders authorization commits and exact operation admissions;
2. a **canonical MLS Commit sequencer** (which can be part of APF/DS) that uses compare-and-swap on the parent MLS frontier; and
3. a **mandatory adapter at every honest application boundary** that refuses to emit or accept a protected effect without APF evidence and an MLS state at least as new as the persisted frontier.

The central construction below is called **LAP-MLS** (Linearized Authorization-Permit MLS). A read revocation closes a right-scoped traffic fence in the same linearizable transaction that commits the denial, drives an RFC 9420 `Remove` plus successor `Commit`, and resumes read-confidential traffic only in the qualifying successor epoch. Write, admin, and admit are not reduced to key secrecy: they are separately excluded by APF verifier-generation changes and mandatory application validation.

This is a useful realization, not a transparent mode of ordinary MLS. It deliberately gives up offline operation while the APF service is unreachable. That is the availability price of commit-immediate authorization. It also trusts the APF quorum and honest boundary code. A pure peer-to-peer MLS deployment with partition-tolerant offline sending cannot provide this semantics against an unseen authorization commit.

One publication-critical caveat remains: no single existing MLS theorem supplies the paper's whole `Sec_MLS` premise. The current closest result is Cremers et al.'s ETK realization of an external-operations CGKA ideal functionality for the RFC 9420 core. It provides the right group-key consistency/confidentiality/authentication foundation but explicitly reports weaker PCS in the presence of external operations. The full-MLS modular theorem of Alwen et al. is an excellent proof pattern, but it analyzes an earlier MLS draft. Section 9 therefore states the exact removal-freshness bridge needed from ETK and marks it as an **OPEN CRYPTOGRAPHIC PROOF OBLIGATION**. The structural LAP-MLS realization and trace theorem are complete at the interface level; their concrete cryptographic discharge, and hence a publication claim of an end-to-end computational theorem, remains incomplete until that bridge is proved. Write/admin/admit exclusion is supplied by LAP-MLS, not by an MLS theorem.

## 1. Standards and primary-source facts that constrain the design

The realization uses the following facts, and does not silently ask MLS to do more than these facts support.

- In RFC 9420, a proposal does not change group state. A `Commit` initiates the new epoch and applies proposals. A removal `Commit` supplies fresh entropy to the continuing members but not to the removed member ([RFC 9420, protocol overview and removal](https://datatracker.ietf.org/doc/html/rfc9420#section-3.2)). A `Remove` proposal is therefore not an exclusion event by itself.
- A `Commit` covering a `Remove` requires an `UpdatePath`; RFC 9420 explains that the path is what evicts the removed member's old appearance ([RFC 9420, Commit](https://datatracker.ietf.org/doc/html/rfc9420#section-12.4)).
- `GroupContext` contains `group_id`, `epoch`, `tree_hash`, `confirmed_transcript_hash`, and extensions. It is an input to the epoch key schedule, and `GroupContextExtensions` changes are confirmed through the new epoch's confirmation tag ([RFC 9420, Group Context](https://datatracker.ietf.org/doc/html/rfc9420#section-8.1), [GroupContextExtensions](https://datatracker.ietf.org/doc/html/rfc9420#section-12.1.7)). This is the right RFC hook for an authorization-revision binding.
- An entity configured in the `external_senders` GroupContext extension can sign an external `remove` or `group_context_extensions` proposal. The standard authenticates the sender and syntax; the application still decides whether the proposal is authorized ([RFC 9420, External Proposals](https://datatracker.ietf.org/doc/html/rfc9420#section-12.1.8)).
- RFC 9420 does not guarantee that a pending removal proposal appears in the next `Commit`: committers should include valid proposals, but receivers should not require every observed proposal to be included. LAP-MLS must therefore make an APF-certified removal mandatory in its own Commit-validity rule, not infer this from base MLS ([RFC 9420, Commit processing](https://datatracker.ietf.org/doc/html/rfc9420#section-12.4)).
- Applications must serialize or canonically resolve competing Commits; RFC 9420 explicitly warns that a Commit is premised on a specific parent epoch and requires applications to establish conflict resolution ([RFC 9420, Sequencing of State Changes](https://datatracker.ietf.org/doc/html/rfc9420#section-14)). RFC 9750 describes a strongly consistent DS that orders competing Commits as one allowed deployment pattern ([RFC 9750, strongly consistent delivery](https://datatracker.ietf.org/doc/html/rfc9750#section-5.2.1)).
- MLS application traffic is epoch-specific. Each epoch creates a fresh secret tree, and an application must apply a group change before encrypting new application data so that removed users no longer receive it ([RFC 9420, Application Messages](https://datatracker.ietf.org/doc/html/rfc9420#section-15)). Nevertheless, a removed client may temporarily retain the previous epoch's secret tree for late messages. Revocation cannot retroactively erase plaintext, ciphertext, or an already learned key ([RFC 9420, receiving a removal Commit](https://datatracker.ietf.org/doc/html/rfc9420#section-12.4.2)).
- Access-control policy and user-to-client expansion are application responsibilities. MLS membership is at client/device granularity; a user-level removal must enumerate the user's client leaves ([RFC 9750, Membership Changes](https://datatracker.ietf.org/doc/html/rfc9750#section-6.1), [Access Control](https://datatracker.ietf.org/doc/html/rfc9750#section-6.4)).
- MLS does not, by itself, prevent insider replay within an epoch. RFC 9750 recommends an application unique identifier in the signed payload or `authenticated_data` ([RFC 9750, No Protection Against Replay by Insiders](https://datatracker.ietf.org/doc/html/rfc9750#section-8.6)). LAP-MLS uses its `opid` for exactly this reason.
- A compromised DS can suppress messages and starve commits. Progress must consequently assume reachability and fair delivery; it cannot be unconditional ([RFC 9420, Delivery Service Compromise](https://datatracker.ietf.org/doc/html/rfc9420#section-16.9)).
- Active-security CGKA work already models proposals, commits, changing membership, an ordering service, exposure, and higher-level group policies; it should be cited as a component-security precedent, not claimed as new ([Alwen et al., *Continuous Group Key Agreement with Active Security*, TCC 2020](https://eprint.iacr.org/2020/752)).
- The closest final-RFC core proof is ETK: it models RFC 9420 external proposals and commits and proves an ideal-functionality realization for consistency, confidentiality, and authentication, while warning that external operations weaken previously claimed PCS ([Cremers et al., *ETK*, EUROCRYPT 2026 / ePrint 2025/229](https://eprint.iacr.org/2025/229)).
- The modular SGM construction of Alwen et al. composes CGKA, forward-secure group AEAD, and a PRF-PRNG, but it is tied to an earlier MLS draft. It supplies a proof architecture, not a drop-in theorem for the final RFC plus LAP-MLS metadata ([Alwen et al., *Modular Design of Secure Group Messaging Protocols and the Security of MLS*, CCS 2021](https://eprint.iacr.org/2021/1083)).

## 2. LAP-MLS architecture

### 2.1 Components

**Authorization, Permit, and Fence service (APF).** A replicated, linearizable state machine stores the committed authorization log, per-grant generations, the per-group read fence, non-read verifier closures, one-use release and recipient-consumption records, and the canonical MLS frontier. Its signing key authenticates policy snapshots, operation certificates, removal directives, consumption receipts, and frontier checkpoints. Consensus safety and durable storage are trusted; availability is conditional.

**Canonical Commit sequencer.** The sequencer accepts MLS handshake messages as `PublicMessage` objects for control epochs that change authorization bindings. This is allowed by RFC 9420 when the DS must inspect handshake messages, though it leaks control metadata. It atomically accepts at most one candidate successor for a parent tuple `(group_id, epoch, tree_hash, confirmed_transcript_hash)`. The sequencer can verify signatures, proposal syntax, public tree changes, and APF policy evidence, but it cannot by itself verify secret-dependent processing such as the confirmation tag. Consequently, “qualifying” remains a client-relative predicate that also requires successful local RFC processing. The sequencer can be co-located with APF, but the proof treats its compare-and-swap and APF policy read as one linearizable transaction.

**External authorization proposer.** APF is configured as an RFC 9420 external sender. On a read denial it emits a signed external `Remove` proposal for every live leaf mapped to the denied incarnation and a signed `GroupContextExtensions` proposal containing the new policy binding. A continuing member, not APF, constructs the UpdatePath and the MLS `Commit`; an external proposer does not possess the group's path secrets.

**Honest client adapter.** Every honest MLS client puts LAP-MLS immediately above its MLS library. The adapter is part of the protection boundary. It (i) obtains exact APF operation admission, (ii) places `opid` and the certificate hash in signed MLS `authenticated_data` or signed application payload, (iii) validates certificates on receive, (iv) rejects stale generations and stale/cross-branch epochs, (v) processes only canonical qualifying Commits, and (vi) persists its frontier before reopening locally. The DS alone is not a complete boundary because an attacker can bypass or compromise it.

**Unmodified RFC 9420 cryptographic core plus private-use extensions.** LAP-MLS does not change TreeKEM. It defines a required LeafNode extension `authz_incarnation` and a GroupContext extension `external_authz_binding`. A production standardization would allocate extension identifiers; a prototype can use RFC 9420's private-use range. All clients advertise support, and the group's `required_capabilities` requires them.

### 2.2 Concrete authorization and epoch objects

At APF revision `v`, the authenticated snapshot is

\[
A_v=(\mathsf{domain},g,v,H(A_{v-1}),\mathsf{Allow}_v,\mathsf{Gen}_v,\mathsf{ClientMap}_v,\mathsf{sig}_A).
\]

`ClientMap_v` expands application users to MLS clients/leaves. The authorization decision for a finite typed support `S` is

\[
\operatorname{Auth}^{r}_{v}(S)=1
\quad\text{iff every grant source in }S\text{ is live at }v
\quad\text{and the right-specific joint policy holds.}
\]

A grant source is `x=(i,g,r,γ)` where `i=(principal, incarnation)` and `γ=Gen_v(i,g,r)`. In the basic realization policies are decomposable except for admit, whose support is joint: `{admin-grant of the authorizer, admit-grant of the candidate incarnation}`. The theorem does not depend on decomposability.

The custom LeafNode extension is

\[
\mathsf{AuthzIncarnation}=(\mathsf{domain},g,i,\Gamma_i,\rho_{authz},H(B^{pub}_{authz}),\mathsf{cert}_A).
\]

Here `Gamma_i` is the four-right generation vector and `rho_authz` is a fresh APF allocation nonce. `B^{pub}_{authz}` is a domain-separated, source-tagged canonical TLS encoding. For `leaf_node_source=key_package`, call it `KP^{pub}` and encode `(domain,g,i,Gamma_i,rho_authz,key_package,version,cipher_suite,init_key,leaf encryption_key,leaf signature_key,credential,capabilities,lifetime,all non-LAP LeafNode extensions,all KeyPackage extensions)`. For an Update or Commit LeafNode, encode the corresponding source tag, parent group/epoch/branch context, leaf encryption/signature keys, credential, capabilities, source-specific fields, and all non-LAP LeafNode extensions. In every case the preimage excludes the APF certificate bytes, the LAP extension's own hash field, and LeafNode/KeyPackage signatures. The client first supplies these public fields and nonce to APF; APF signs their hash; the client then inserts the certificate and signs the LeafNode and, where applicable, KeyPackage. A verifier reconstructs exactly this stripped canonical preimage from the finalized object and requires hash equality. Thus the certificate binds fresh public key material and a credential to one incarnation/generation vector without placing `H(KeyPackage)` inside the KeyPackage that it hashes. The finalized extension remains signed as part of the LeafNode and committed by the ratchet-tree hash.

The GroupContext extension is

\[
\mathsf{PolicyBinding}_e=(\mathsf{domain},g,v_e,f_e,H(A_{v_e}),
H(\Gamma_e),H(\widehat{\mathcal G}_e),H(\mathcal X_e),\mathsf{sig}_A).
\]

Here `f_e` is the APF fence sequence, `Γ_e` the relevant generation map, `\widehat{G}_e` the support-cover commitment, and `X_e` the cumulative excluded grant instances. Because the extension is in `GroupContext`, it enters the epoch key schedule and is confirmed by the MLS confirmation tag. This gives an authenticated dependency `dep(e)`; it does not make `v_e` automatically fresh for every later operation. APF separately tracks `requiredRev[g,r]`, the latest revision whose change affects a support currently live, conservatively covered, or pending exclusion for right `r` in group `g`. A read allow for an absent candidate does not change this floor until an Add tries to make that support live; a read denial of a current/covered leaf does. A read fence may open when the installed binding covers `requiredRev[g,read]`; unrelated write/admin changes need not force a read rekey. Each later operation still carries the current APF admission revision `v_o`, which may exceed `v_e`.

### 2.3 Exact APF interfaces and the operation linearization point

APF exposes the following abstract calls.

1. `PolicyCommit(expected_v, delta)`. On successful compare-and-swap, APF appends `A_{v+1}`, updates generations, and invalidates affected unreleased reservations. A read denial of a live, conservatively covered, or pending-exclusion grant atomically closes `ReadFence[g]`. A write/admin/admit denial atomically closes only the old grant verifier `(i,g,r,gamma)` and advances its verifier revision; it does **not** close a group-wide fence. This transaction's consensus linearization point is the event that **commits an authorization revision**.
2. `Preallocate(contextPrefix)`. APF chooses fresh unpredictable `opid` and `certid`, records them as `allocated`, and returns them. This call makes no authorization decision and cannot authorize exposure. The pair is never recycled, including after a crash.
3. `AuthorizeRelease(opid, certid, g, r, e, b, kappa, mu, cover, claims)`. Before this call the boundary freezes the payload or control bytes and the following cycle-free commitment:

   \[
   \mu=H(\mathsf{"LAP-content-v1"},g,r,dir,\mathsf{payload/control},aux),
   \]

   together with the deterministic envelope context

   \[
   \kappa=(\mathsf{domain},g,r,dir,e,b,\mathsf{sender/actor},opid,certid,
   \mathsf{MLS\ suite/framing\ mode},H(aux),\mu).
   \]

   Neither value contains the later certificate or randomized MLS ciphertext. APF atomically reads the current snapshot and frontier, checks the read fence or right-specific verifier closure as applicable, exact binding, generation, and every support in the supplied sound cover, then changes the unique reservation from `allocated` to `released`. The successful linearization point is the operation's cut. APF returns exactly one signed certificate

   \[
   \phi_o=(\mathsf{opid},\mathsf{certid},g,r,dir,e,b,v_o,f,
   H(\widehat{\mathcal G}_o),H(Q_o),\Gamma_o,H(\kappa),\mu,\mathsf{sig}_A).
   \]

4. `Consume(opid, certid, boundary, recipient, effectKind)`. After certificate/envelope verification but before application delivery, the boundary atomically changes the corresponding APF consumption cell from `unused` to `spent`, updates the rollback-resistant spent root, and obtains a signed receipt. The call succeeds at most once for each logical central effect or each `(opid,recipient-incarnation)` group delivery. It is a replay barrier, not a new authorization cut.
5. `Canonicalize(commit, repairCertificate, validityAttestation?)`. APF/sequencer compare-and-swaps the MLS parent frontier and accepts at most one publicly valid candidate child. Each honest client still decides whether the child qualifies after secret-dependent RFC processing. A validity attestation is required only by the progress configuration described in Section 10; safety remains fail-closed without it.
6. `Checkpoint()` returns the signed durable APF/MLS frontier, including the release and consumption-log roots.

After receiving `phi_o`, the sender constructs the only exposable envelope

\[
E_o=\mathsf{encode}(\kappa,\phi_o,C_o),\qquad
C_o=\mathsf{MLS.Protect}(\mathsf{payload/control};
\mathsf{authenticated\_data}=\mathsf{encode}(\kappa,H(\phi_o))).
\]

The certificate never hashes `E_o`, `C_o`, or itself, so there is no cycle. The protected logical object authorized at the cut is the immutable pair `(kappa,payload/control)`; `E_o` is the only exposable certificate-bearing wire object for this operation. The honest boundary invokes `MLS.Protect` once, crash-consistently persists the resulting `E_o` before its first network write, and thereafter may retransmit only those byte-identical stored bytes. If a crash loses `E_o`, recovery abandons the released operation rather than encrypting it again. Before emission the boundary recomputes `mu` from its frozen bytes, checks every field of `kappa` for byte equality with the pre-authorized value, verifies `phi_o`, and checks `H(kappa)` and `mu` in the certificate. A receiver first verifies the certificate and signed authenticated data, decrypts, recomputes `mu` and `kappa`, requires byte equality with the envelope and certificate, and then successfully calls `Consume` before delivering the effect. Any mismatch, missing reservation, reused `(opid,certid)`, or unavailable APF fails closed. Thus encryption may occur after the cut without permitting content or context created after the cut to replace the pre-bound logical object.

For commit-immediate semantics,

\[
\operatorname{cut}_{0}(\tau,o)=
\text{the APF revision read at the successful linearization of }\mathsf{AuthorizeRelease}(o).
\]

Thus a denial committed before `AuthorizeRelease` is effective; one committed after it is not retroactively applied to that already admitted operation. An operation certificate is not a general bearer permit: it is bound to one `(opid,certid)`, one immutable content commitment and envelope context, one branch/epoch, one support cover, and one generation vector. This prevents an implementation from prefetching generic permits and then labeling post-revocation actions as old operations. The release transition is one-shot, and rollback-resistant `Consume` records make central effects and each honest-recipient delivery one-shot under the same logical `opid`.

The definition does **not** claim that no network byte may arrive after a policy commit. An operation linearized just before the denial may complete later. This is the standard consequence of locating the cut at operation admission rather than at physical delivery.

### 2.4 Where traffic is fenced

LAP-MLS distinguishes one group-level cryptographic fence from grant-scoped verifier closure.

- **Read/confidentiality emit:** `ReadFence[g]` is the only group-level fence. Before `AuthorizeRelease`, an honest sender freezes the payload and deterministic envelope context. A read denial of a live or conservatively covered grant atomically closes this fence. While closed, no honest adapter obtains a release certificate or produces a new protected logical object for the old epoch. After a qualifying removal, it produces content only for the successor epoch.
- **Read delivery of older traffic:** a client may retain old epoch keys for bounded late delivery, as RFC 9420 permits, but the adapter delivers only an exactly bound envelope whose recorded cut precedes the relevant denial and whose `(opid,recipient-incarnation)` consumption cell can be atomically spent. No claim is made that the removed endpoint forgets those messages or keys.
- **Write/integrity accept:** a write denial atomically closes the old sender grant generation in APF's verifier state; it does not stop unrelated writers. An honest application accepts a purported actor effect only with an exact APF certificate for the sender's write support and a successful one-shot `Consume`. A syntactically valid old-epoch MLS message is insufficient.
- **Admin:** an admin denial atomically closes the old admin generation without closing a group-wide admin fence. The sequencer and every honest Commit processor reject a membership/policy Commit unless its signed `authenticated_data` names an APF admin certificate bound to the exact parent frontier, deterministic control commitment, and exact proposal list. Repair Commits are authorized separately by the APF removal directive, not by the human committer's admin grant.
- **Admit:** an admit denial atomically closes the candidate's old generation without blocking unrelated admissions. An `Add` or external Commit is rejected unless its evidence jointly covers the authorizer's admin support (where policy requires one) and the candidate incarnation's admit support, binds `H(KP^{pub})`, the finalized KeyPackage's recomputed stripped preimage, and the fresh generation vector. A Welcome is released only after canonicalization, matching RFC 9420's rule that a Welcome must not be delivered until the Commit has won sequencing.

These gates distinguish “can form an MLS message with retained state” from “can cause an honest application to accept the protected effect.”

## 3. Complete mapping of abstract objects

The table deliberately maps more than the short Phase 3 checklist so that the realization can be type-checked against the notebook.

| Abstract object | LAP-MLS realization |
|---|---|
| `P`, `D`, `G`, `R` | Application principal names; concrete MLS clients/devices; MLS `group_id`s; `{read, write, admin, admit}`. User-level policy is expanded to client incarnations before it becomes an MLS membership decision. |
| `I=P×N` | APF-certified incarnation in the `authz_incarnation` LeafNode extension. Every deny-to-allow transition uses a larger right-specific generation and fresh authorization credential/key material; read re-addition uses a fresh KeyPackage, while an existing authorized reader reauthorized for a non-read right installs a freshly keyed LeafNode through an Update/full Commit before that grant becomes usable. |
| `A`, `A_v` | APF's linearizable authorization LTS and signed hash-chained snapshot at revision `v`. |
| Revision-commit event | Successful consensus linearization of `PolicyCommit`; it is not an MLS `Commit`. The paper must consistently say “policy commit” versus “MLS Commit.” |
| `allow_v(i,g,r)`, `gen_v(i,g,r)` | Fields of the APF snapshot. `gen` increases on every deny-to-allow transition and never decreases. |
| `C`, `C_e` | The extended capability state consisting of RFC 9420 group state plus the LAP verifier/frontier state; concrete MLS epoch `e` includes GroupContext, ratchet tree, epoch secrets, branch hashes, and `PolicyBinding_e`. |
| MLS branch | `b_e=H(group_id, epoch, tree_hash, confirmed_transcript_hash)`. Competing children of one parent are candidates until APF canonicalizes one. |
| `Controls_tau(d,i)` | Credential/LeafNode ownership plus the APF client-incarnation certificate binding device `d` to incarnation `i`. |
| Grant source `x=(i,g,r,γ)` | The APF grant instance named in a LeafNode certificate or operation certificate. |
| `H_{e,r}` | For `read`, the derivation from a certified leaf membership through the TreeKEM path/epoch secret to the encryption secret and per-sender ratchets. For `write`, `admin`, and `admit`, the derivation combines the current LeafNode/application credential with the exact APF certificate and receiver/sequencer verifier state. |
| `ValidProof`, `supp`, `gsupp` | Successful RFC/adapter validation transcript; its full cryptographic and APF premises; and the projection to typed APF grants. Read proofs are normally singleton per recipient leaf. Admit is normally a joint two-grant proof. |
| `SuppBar_r`, `bottom_r` | The total support type `Supp_r^+ + {bottom_r}` with `Auth_v^r(bottom_r)=0`; malformed, missing, or invalid provenance can never disappear from the trace. |
| `Cap` replacement | Deterministic events `recover(d,o,u)` and `acceptedAct(h,d,o,u)`, where `h` is the honest accepting boundary and `u` is `prov(e_pi,c,pi,S)` or `unattributed(r_o)`. Probability appears only in the common computational experiment and component bounds. |
| `widehat G_o` | A signed commitment to a sound support cover. For read sealing it contains every recipient leaf support in the canonical epoch, plus any uncertain candidate support; an unresolved fork closes the fence. For write it contains the authenticated sender support. For admin it contains every required authorizer support. For admit it contains the joint admin/candidate support. |
| Sound cover condition | `Users_tau(o) subseteq widehat G_o`. Extra supports cause rejection and reduce availability; omission is a safety failure. When the canonical MLS leaf set is known, the read cover is exact, but exactness is not a theorem premise. |
| Protection boundary | APF linearization and canonicalization, plus the mandatory send/receive/Commit adapter at every honest endpoint and application receiver. The DS by itself is not the boundary. |
| Freshness witness `phi` | The signed, exact, durable APF operation certificate returned by `AuthorizeRelease`. |
| `cut_0` | APF revision at the operation's `AuthorizeRelease` linearization point. |
| `Allowed_0(tau,o)` | All complete supports `S` for which `Auth^r_{cut_0}(S)=1`. |
| `o` | The atomic tuple `(opid,g,r,e,dir,digest,aux)`, with `digest=H(kappa,mu)`. Its successful exercises are read recovery or an honest-boundary accepted write/admin/admit effect. One chat send normally induces one confidentiality operation with multiple recipient exercises and distinct integrity-accept operations. |
| `ReqSupp_h(tau,o)` | For read, `(incarnation, singleton grant support)` for every client leaf intended to recover the new payload; for other rights, the exact actor/join support required by policy. |
| `UseSupp_tau(o)`, `Users_tau(o)` | The total occurrence-indexed successful-event relation and its support projection defined immediately below; `unattributed(r)` projects to `bottom_r`. |
| `Exclude_C`, `Qualifies_C` | The four right-specific transitions defined in Section 5 below. |
| `F_h=(b,e,v,Gamma,X,chi,rho_rel,rho_spent)` | Durable accepted branch hash, MLS epoch, APF revision, generation root, cumulative qualifying exclusions, support-cover root, release-log root, and recipient-consumption/spent-log root. |
| `AuthCapSafe_0` | Every exposed successful operation's actual support is authorized at its APF linearization cut. This is the renamed, interface-independent target property. |
| `ACC_0` / `GoodTrace_0` | Exactly the nine independently checkable clauses in Section 9.1: mediation; authentic full binding; sound cover; authorization of cover and claims at the cut; valid total provenance; monotone frontier/lineage; qualifying right-specific exclusion; post-exclusion non-use; and message confidentiality/integrity. |

For each right let `SuppBar_r = Supp_r^+ \uplus {bottom_r}` and define `Auth_v^r(bottom_r)=0`. An occurrence witness is total:

\[
u ::= \mathsf{prov}(e_\pi,c,\pi,S)\mid\mathsf{unattributed}(r_o),
\quad
\mathsf{support}(\mathsf{prov}(e_\pi,c,\pi,S))=S,
\quad
\mathsf{support}(\mathsf{unattributed}(r))=\bot_r.
\]

`exercise_tau(d,o,u)` is the typed disjunction of `recover(d,o,u)` and `acceptedAct(h,d,o,u)` for some honest boundary `h`. Every successful protected effect creates exactly one such occurrence; missing or invalid provenance creates `unattributed(r_o)`, never no event. Define

\[
\begin{aligned}
UseSupp_\tau(o)&=\{(d,u,\mathsf{support}(u)):exercise_\tau(d,o,u)\},\\
Users_\tau(o)&=\{S:\exists d,u.\ (d,u,S)\in UseSupp_\tau(o)\}.
\end{aligned}
\]

`ProvOK_tau(o,u)` is checked separately and holds only for a non-bottom witness whose RFC, APF, envelope-equality, and support derivation validate. These are deterministic functions and predicates of a fixed trace. The guard reasons prospectively about a conservative support cover; it does not wait for later exercises to reveal `Users_tau(o)`.

## 4. Support cover without hidden global agreement

For a read-seal operation in epoch `e`, define

\[
\widehat{\mathcal G}_{o}^{read}
=\{\{(i,g,read,\gamma_i)\}:\text{a canonical leaf in }C_e\}
\cup U_o,
\]

where `U_o` is a conservative set of supports whose disposition is uncertain because of a not-yet-resolved branch, incomplete user-to-client expansion, or recovery. APF authorizes the operation only if every support in this family is read-authorized at `cut_0`. Any unresolved fork affecting the group makes `U_o` unknown and closes the fence rather than guessing.

Soundness comes from two independently checkable facts: (i) RFC-valid group-state processing determines the leaf set for a particular canonical branch; and (ii) the adapter's only read-capability constructors are the named MLS epoch-key derivations. If the application has an exporter, attachment key, backup key, push-preview key, or server-side plaintext cache, each is another capability constructor and its support must be added. Omitting such a path is an adapter failure, not an MLS theorem failure.

For integrity directions, the exact MLS sender index, signature, `opid`, and APF record identify the used support. The support cover can therefore be much smaller:

- write: the sender's write grant support;
- admin: all supports required by the application rule for that exact Commit/proposal list;
- admit: a single joint support containing the authorizer-admin grant and candidate-admit grant, or the exact alternatives specified by policy.

The model never converts a conjunction `{x_admin,x_admit}` into two alternatives `{x_admin}`, `{x_admit}`. A Merkle root authenticates the structured family and canonical encoding includes support boundaries.

## 5. Right-specific exclusion and resumption

### 5.1 Read

For denied source `x=(i,g,read,γ)`:

\[
\operatorname{Exclude}^{read}_{C}(e,e',x)
\]

holds when a canonical RFC-valid MLS Commit based on `e` removes every leaf certified for incarnation/generation `(i,γ)`, contains an UpdatePath with fresh commit entropy, installs `PolicyBinding_{e'}` carrying the denial and cumulative exclusion, and moves to `e'=e+1` (or the canonical next epoch). `Qualifies` additionally requires:

1. the resulting tree contains no leaf whose accepted derivation includes `x`;
2. every continuing leaf has read authorization at the Commit's APF binding revision;
3. the Commit is the APF canonical child of the persisted parent;
4. the client's RFC processor successfully verifies it and persists the new frontier before local fence opening; and
5. the ETK/MLS removal-freshness predicate needed by the chosen confidentiality theorem holds.

Post-exclusion non-use means that the removed incarnation cannot recover **fresh, honest, post-cut application payloads sealed to qualifying later epochs** except with negligible probability. It does not mean deletion of old plaintext, old ciphertext, previous-epoch keys, or information deliberately leaked by a continuing authorized member.

### 5.2 Write

`Exclude^write_C(F,F',x)` is the APF verifier-state transition at the policy commit that marks generation `γ` denied, advances the durable authorization frontier, invalidates unreleased reservations for `x`, and makes every later `AuthorizeRelease(write,...)` for `x` fail. It does not close a group-wide write fence, so unrelated writers continue. `Qualifies` requires all honest acceptors to require an exact APF certificate, envelope equality, and rollback-resistant `(opid,recipient)` consumption. MLS removal is neither necessary nor sufficient for this right if the principal remains an authorized reader.

### 5.3 Admin

`Exclude^admin_C(F,F',x)` advances the canonical Commit-policy verifier so no later proposal list/Commit can be canonicalized or accepted under the old admin generation; other administrators remain live without a group-wide fence. `Qualifies` requires APF/sequencer checking, identical validation by every honest Commit processor, exact control-envelope equality, and one-shot consumption. An unauthorized actor may still manufacture a syntactically valid MLS Commit or a private fork; it cannot cause the canonical or honest accepted admin effect.

### 5.4 Admit

`Exclude^admit_C(F,F',x)` removes the old candidate generation from the KeyPackage/Welcome acceptance set without fencing unrelated candidates. `Qualifies` requires a later Add/external Commit to carry a fresh candidate generation, a finalized KeyPackage whose stripped canonical preimage recomputes `H(KP^{pub})`, fresh key/credential material, and any required admin co-support; Welcome delivery is coupled to the canonical winning Commit. Reusing an old KeyPackage, Welcome, certificate, or candidate permit is rejected.

### 5.5 Which existing theorem supplies post-exclusion non-use?

There is no honest answer of “one theorem for all four rights.”

- For **read**, use the ETK realization of `F_ECGKA` as the final-RFC core foundation, restricted to its actual freshness/corruption predicate, and derive a LAP-MLS removal bridge lemma: a qualifying RFC 9420 removal makes the successor epoch secret hidden from the removed pre-epoch state. Compose that lemma with the RFC key schedule and application AEAD. RFC 9750 states the intended guarantee that future-epoch message secrecy is recovered after an actively compromised client is removed, but this standards prose is not itself the paper's reduction ([RFC 9750, endpoint compromise](https://datatracker.ietf.org/doc/html/rfc9750#section-8.3.1.3)).
- For **write**, MLS message authentication helps bind the sender, but non-acceptance after an external write denial follows from APF certificate unforgeability, linearizability, generation checks, and replay protection.
- For **admin** and **admit**, the result follows from APF plus application-level Commit validation. RFC 9420 intentionally leaves additional policy enforcement to the application ([RFC 9420, Additional Policy Enforcement](https://datatracker.ietf.org/doc/html/rfc9420#section-16.11)).

Claiming that “MLS security” alone supplies all four exclusions would be false.

## 6. Qualifying removal protocol

The following is the one primary realization; causal/lease variants should be relegated to discussion.

1. At revision `v`, a policy administrator submits a denial. APF linearizes `PolicyCommit`, updates the generation state, records the exact affected leaf incarnations, and atomically closes `ReadFence[g]`. This is when revocation becomes effective for every later operation cut.
2. APF emits signed external `Remove` proposals for all affected leaves and a `GroupContextExtensions` proposal containing `PolicyBinding(v)`. These are authenticated external proposals, not yet a group transition.
3. A fair-scheduled, continuing, honest member receives the directives and constructs an RFC 9420 Commit with an UpdatePath. The committer need not hold a human admin grant: the APF repair certificate authorizes this narrowly scoped maintenance action.
4. A **qualifying Commit** must:
   - name exactly the persisted canonical parent epoch/branch;
   - cover all still-required APF removal directives for that parent and no unauthorized Add/Update/ReInit;
   - update the full GroupContext extension list, preserving unrelated extensions because RFC `GroupContextExtensions` is wholesale replacement;
   - install a `PolicyBinding` whose authority signature, revision, generation root, cover root, exclusion root, and fence sequence verify;
   - have an RFC-required UpdatePath and result in a tree containing no denied read incarnation;
   - include the APF repair `opid` in signed `authenticated_data`; and
   - win the sequencer's compare-and-swap for the parent.
5. A continuing client processes the canonical Commit with its ordinary RFC implementation, checks the LAP conditions, durably persists `F_h`, including the release/spent-log roots, deletes/limits superseded secrets as RFC 9420 requires, and only then opens its local read fence. A client that has not processed it remains fenced.
6. APF permits later `AuthorizeRelease` calls only for the successor epoch and current cover. An authorized member can now send new traffic. The removed endpoint has retained old state but, conditional on the open removal bridge in Section 9, not the successor epoch/application keys.

“The successor epoch is accepted” therefore has two precise parts: the sequencer has canonicalized a candidate, and the particular honest boundary about to expose an operation has successfully processed that candidate and durably advanced its own frontier. It does not posit an instantaneous atomic update of every offline group member. A maliciously malformed candidate can win public sequencing yet fail at every honest client, causing denial of service but not an unsafe local reopen. The progress theorem must assume that an RFC-valid repair candidate wins (or add a separate Byzantine-validity/attestation protocol); base MLS does not solve that availability problem.

## 7. Rollback, frontier persistence, and allow–revoke–allow

The concrete frontier is

\[
F_h=(b_h,e_h,v_h,\Gamma_h,\mathcal X_h,\chi_h,\rho^{rel}_h,\rho^{spent}_h),
\]

with `b_h=H(group_id,e_h,tree_hash,confirmed_transcript_hash)`. `rho^rel_h` commits to all allocated/released `(opid,certid)` records and `rho^spent_h` commits to central and per-recipient consumption cells. APF durably stores the canonical maximum and append-only proofs for both roots. Each client stores an authenticated checkpoint, local MLS state, and the latest APF consumption receipt using crash-consistent atomic replacement before acknowledging readiness or application delivery.

On startup or recovery the adapter must contact APF. It compares the local checkpoint with APF's signed frontier:

- lower revision/epoch/generation, missing exclusion, or older release/spent root: fetch and verify the descendant and append-only log proofs, then advance;
- same epoch but different branch: mark `Forked` and fence;
- incomparable state: fence until an APF-certified resolution that carries both branches' exclusions, componentwise maximum generations, and append-only union/superset release and spent roots;
- APF unreachable: remain fenced for protected effects.

A signature on an old checkpoint is not anti-rollback evidence. The monotonic fact comes from the non-rollbackable APF quorum (or, in an alternative deployment, a trusted monotonic hardware counter). After any local rollback, a receiver must synchronize both roots before it can call `Consume`; APF rejects a previously spent cell even if the local image forgot it. An envelope whose release record is absent, whose root proof is stale, or whose per-recipient cell is already spent is rejected. If an adversary can roll back both the client and the APF durable quorum, the theorem does not apply.

For every allow–revoke–allow sequence, APF strictly increments `gen(i,g,r)` and issues fresh authorization credential/key material; the exact old grant `(i,g,r,gamma)` never becomes valid again. If `r=read`, the old MLS leaf is never simply declared live again. Reauthorization supplies a fresh KeyPackage, fresh leaf HPKE and signature keys, and a fresh `authz_incarnation` certificate. The old leaf is removed before the read fence opens, and only a Welcome for the winning Add Commit is delivered. For `write`, `admin`, or `admit` when the incarnation remains an authorized reader, the new grant is unusable until a full Commit/Update installs a freshly keyed LeafNode and refreshed four-right generation vector; unrelated operations remain available while this grant-scoped installation is pending. A replacement device instead uses a new incarnation and fresh KeyPackage. A combined remove-old/add-fresh Commit is possible for read, but a two-epoch remove-then-add flow is simpler to prove and should be the primary paper path.

## 8. Threat and trust assumptions

### 8.1 Adversary

The adversary controls the network and DS scheduling, may delay/drop/replay/reorder messages, may submit competing or malformed Commits, and may fully corrupt a revoked endpoint, retaining every pre-revocation secret and persistent image it ever learned. It may replay old APF and MLS artifacts and roll back local client storage. It may control other unauthorized clients and request arbitrary permits. It is polynomial-time for cryptographic claims.

### 8.2 Trusted/assumed correct

- APF consensus safety, authorization-admin authentication, signing key, durable non-rollbackable quorum state, and correct support evaluation;
- the canonical sequencer's compare-and-swap (or the combined APF transaction);
- MLS credential Authentication Service integrity, or an explicitly modeled key-transparency mechanism; RFC 9420 notes that AS compromise enables impersonation;
- the LAP adapter and MLS implementation at every boundary called honest;
- collision resistance, signature/AEAD/KDF/HPKE assumptions and, conditionally, `Fresh_LAP^remove` plus the open `Bridge_ETK^remove` needed by the removal lemma;
- for read secrecy after removal, no continuing authorized member that learns the successor plaintext or epoch secret deliberately leaks it to the revoked party.

### 8.3 Explicitly out of scope

Retroactive erasure; a malicious authorized insider exfiltrating plaintext or keys; physical compromise of an honest boundary during the challenged successor epoch; APF/quorum compromise or total rollback; AS compromise without detection; metadata privacy for public authorization Commits; and availability under arbitrary partitions or a suppressing DS.

## 9. Concrete composition theorem

### 9.1 Component predicates

Let `R_LAP` be the concrete system above and define:

- `Sec_A`: APF policy commits form one durable linearizable history, only authorized policy administrators can change it, and its authenticated snapshots have the stated meaning.
- `Sec_release`: every accepted certificate corresponds to one exact durable `AuthorizeRelease` transition at the revision it names; `(opid,certid)`, `H(kappa)`, `mu`, cover, claims, generation, branch, and epoch bind exactly; a reservation is released once; and each protected acceptance has one successful rollback-resistant consumption transition.
- `Sec_frontier`: canonical parent compare-and-swap, append-only release/spent roots, lineage/exclusion/generation monotonicity, and fail-closed synchronization hold despite local rollback.
- `AdapterConditions`: every successful effect is mediated and recorded as `recover(d,o,u)` or `acceptedAct(h,d,o,u)`; envelope and plaintext equality are recomputed; conservative covers and right-specific validators are used; invalid provenance becomes `unattributed(r)`; fences fail closed; persistence precedes reopen/delivery; and there is no unmodeled exporter/attachment/backup/plaintext path.

For every exposed operation, `GoodTrace_0(tau)` is exactly the conjunction of these nine independently checkable clauses:

1. complete mediation at every trusted send, receive, and control boundary;
2. authentic binding of operation ID, certificate ID, group, right, direction, immutable content commitment, deterministic envelope context, epoch, branch, authorization revision, cover commitment, claim supports, and grant generations;
3. `CoverSound_tau(o,widehat G_o)`, i.e. `Users_tau(o) subseteq widehat G_o`;
4. authorization at `cut_0(tau,o)` of every support in `widehat G_o union Q_o`;
5. `ProvOK_tau(o,u)` for every observed exercise, so an `unattributed(r)`/bottom occurrence makes this clause false rather than disappearing;
6. monotone accepted frontier, append-only release/spent roots, and lineage continuity across recovery;
7. a qualifying right-specific exclusion before resuming on a lineage that carried an effectively denied grant;
8. post-exclusion non-use for that right and exact grant generation; and
9. the stated message confidentiality and integrity protection.

The exact read predicate required for the cryptographic bridge is `Fresh_LAP^remove(tau,e,e',x,o)`. It holds only if: (i) `e'` is the canonical qualifying child of `e` created by a regular Commit from a continuing honest member and contains the required UpdatePath and external-Remove result; (ii) exact grant `x` is absent from `e'` and every descendant through challenged operation `o`; (iii) the committer samples fresh path/commit entropy that is not revealed before the challenge and successfully erases superseded secrets; (iv) no member in the challenged successor roster, no AS/APF key, and no successor epoch/application secret is corrupted or revealed before the challenge; (v) no continuing authorized member leaks plaintext or keys to the removed party; (vi) no stale GroupInfo, external join/commit, PSK, fork switch, or state-resynchronization operation gives `x` a successor secret; (vii) the adversary may hold all of `x`'s pre-successor endpoint state, including signature keys and old epoch secrets; and (viii) `o` is a fresh honest application object first protected in `e'` or a qualifying descendant.

`Bridge_ETK^remove` is the lemma that `Fresh_LAP^remove` implies the ETK safety/freshness predicate for the corresponding test sequence and that ETK key indistinguishability, the RFC 9420 key schedule, and application AEAD imply that `x` cannot recover `o` except with negligible advantage. This is an **OPEN CRYPTOGRAPHIC PROOF OBLIGATION**: the present design does not claim that ETK already proves this implication, especially because ETK documents weaker PCS with external operations. Define `Sec_MLS^excl := Bridge_ETK^remove and Sec_MLS-msg` only conditionally on a completed proof of that lemma.

### 9.2 Theorem statement

**Theorem (structural LAP-MLS commit-immediate authorization–capability safety).** For every trace `tau` of `R_LAP`,

\[
GoodTrace_0(\tau)\Longrightarrow AuthCapSafe_{0}(\tau).
\]

This is a deterministic trace theorem. It does not assume that every success has valid provenance: an unattributed success is retained with bottom support and makes `GoodTrace_0` false.

**Conditional computational composition theorem.** For every polynomial-time adversary satisfying Section 8, the concrete implication

\[
Sec_A\land Sec_{release}\land Sec_{frontier}\land
Bridge_{ETK}^{remove}\land Sec_{MLS-msg}\land AdapterConditions
\Longrightarrow AuthCapSafe_0
\]

holds subject to the common-experiment bound below. Because `Bridge_ETK^remove` is open, this is a conditional theorem, not a completed end-to-end reduction.

Define one experiment `Exp_LAP(A,1^lambda;q_op,q_cert,q_excl)` that samples all primitive keys/randomness, runs APF, MLS, sequencer, adapters, crashes, recoveries, and the adversary in one trace, and records these named events:

- `B_lin`: a policy commit, release, consumption, or canonicalization result violates the declared shared linearizable order;
- `B_authority`: an unauthorized policy or verifier transition is accepted;
- `B_forge`: a new APF snapshot, release, repair, consumption, or frontier signature verifies without an issuing record;
- `B_bind`: unequal content, envelope context, source-tagged authorization/KeyPackage public preimage, cover, claims, generation, branch, or epoch passes equality/binding checks, including a hash collision;
- `B_release`: a `(opid,certid)` is released twice or a central/per-recipient consumption cell succeeds twice;
- `B_cover`: an actual total support, including bottom for unattributed provenance, is omitted from the authenticated cover;
- `B_frontier`: stale, rolled-back, fork-incomparable, or non-append-only release/spent state is accepted as ready;
- `B_adapter`: an effect bypasses mediation, or an adapter exposes/accepts bytes not equal to the recomputed immutable logical object;
- `B_MLS-excl`: the stated removal bridge, MLS message confidentiality, or MLS message integrity fails for a fresh qualifying challenge.

Then `Unsafe implies not GoodTrace_0 implies union_j B_j`, and the union bound gives

\[
\begin{aligned}
\Pr[\neg AuthCapSafe_0]
\le {}& \epsilon_{lin}+\epsilon_{authority}
+q_{cert}Adv^{euf}_{APFsig}
+q_{op}Adv^{coll}_{H}
+q_{op}\epsilon_{release}
\\&+\epsilon_{cover}+\epsilon_{frontier}+\epsilon_{adapter}
+q_{excl}(Adv^{bridge}_{ETK}+Adv^{prf}_{KDF}+Adv^{conf/int}_{MLS-msg}).
\end{aligned}
\]

Here the `q` factors apply when the displayed primitive advantages are single-instance bounds; if an advantage is already defined for the full `q`-bounded multi-user experiment, that factor is omitted rather than counted twice. `Adv_ETK^bridge` is a placeholder until the open bridge is proved. Linearizability, correct authority evaluation, cover construction, frontier durability, release uniqueness, and adapter correctness are operational trust assumptions by default, in which case their epsilons are zero and they are premises, not probabilistic claims. They appear as probabilities only for an implementation that explicitly supplies a sampled crash/fault/consensus model. The inequality is secondary bookkeeping over the one experiment, not the structural theorem.

### 9.3 Proof skeleton

Fix the first exposed operation `o` and occurrence witness `u` with `S=support(u)` such that `Auth^r_cut(S)=0`.

1. **Total occurrence and provenance.** The effect appears in `UseSupp_tau(o)`. If `u=unattributed(r)`, then `S=bottom_r` is unauthorized by definition and clause 5 of `GoodTrace_0` is false. Otherwise `ProvOK` gives the typed complete support used below.
2. **Mediation and binding.** Clauses 1–2 give one preceding `AuthorizeRelease` record bound to exact `(opid,certid)`, group, right, direction, branch, epoch, generation, immutable `mu`, `kappa`, claims, and structured support cover; receiver equality and one-shot consumption also hold.
3. **Cut freshness.** By the shared order, the revision in the record equals `cut_0(tau,o)`. A policy denial ordered before the operation is visible. `Preallocate` or an authentic old snapshot cannot stand in for this linearization.
4. **Cover.** Soundness gives `S in widehat G_o`. Clause 4 says APF checked `Auth^r_cut(S')=1` for every `S'` in that cover. This contradicts `Auth^r_cut(S)=0`.
5. **Historically callable but excluded support.** If the operation purports to use a historical capability removed from the current cover, clauses 6–8 require a recorded right-specific `Exclude_C` before reopening. Rollback, branch switching, and forgotten spent IDs are rejected by the APF floor, append-only roots, and readiness/consumption checks.
6. **Read case.** Between denial and qualifying successor, `ReadFence[g]` prevents a new release. After the successor, the old support is absent; at the computational layer, post-exclusion recovery additionally relies on the explicitly open `Bridge_ETK^remove`. Pre-cut late traffic is authorized at its own earlier cut and is not a counterexample.
7. **Write/admin/admit cases.** The old generation cannot obtain a new exact APF certificate; unequal envelopes, replayed consumption cells, and stale generations are rejected. Admin and admit also fail canonical/recipient Commit validation. Unrelated grants remain live because these are grant-scoped closures, not group fences.

The structural contradiction is set inclusion. The computational statement separately bounds how a concrete implementation can leave `GoodTrace_0`; it is complete only after the removal bridge is discharged.

## 10. Non-vacuity and conditional useful progress

### 10.1 Witness trace

Start with authorized clients Alice and Bob in canonical epoch `e`, fence open, and a valid APF binding. Revoke Bob's read grant at policy revision `v+1`. APF closes the read fence, so Alice cannot release new content in `e`. Alice receives APF's external Remove/binding proposals, constructs and wins the successor Commit `e+1`, processes it, and persists the new frontier. Her local read fence opens. Alice preallocates distinct confidentiality and integrity operations, freezes each operation's content/context, obtains their current read and write `AuthorizeRelease` certificates, constructs the exact envelope for message `m`, and the continuing honest members consume and recover their respective effects once. Bob retains epoch-`e` state but, conditional on `Bridge_ETK^remove`, cannot derive epoch-`e+1` application keys. The structural trace contains a post-revocation authorized operation irrespective of that cryptographic discharge, so safety is not achieved only by permanent blocking.

### 10.2 Progress theorem

**Theorem (conditional authorized progress after read revocation).** Suppose there is a stable suffix beginning at the final relevant policy revision `v*`:

1. no policy revision after `v*` changes the relevant read authorization, generation, cover, or repair directive, and no competing accepted MLS child changes the designated parent before repair;
2. the APF/sequencer quorum is reachable and its operations terminate;
3. APF's removal/binding directive and the winning Commit are eventually delivered;
4. at least one continuing authorized honest member remains online, has valid credentials/state, can construct the required UpdatePath, and is weakly fairly scheduled;
5. sequencer validity is supplied by one explicit deployment mechanism: either an honest authorized repair committer has an exclusive/fair repair slot, or the sequencer requires a verifiable validity attestation from at least one continuing honest client that successfully processed the candidate, including its confirmation tag and LAP checks, before the parent CAS; base public sequencing alone is not sufficient;
6. honest MLS/APF processing and durable writes terminate, with sufficient storage/counter capacity; and
7. after the fence opens, an authorized operation request is issued (or issued infinitely often) and delivery of its messages is fair.

Then

\[
\Diamond\bigl(\neg ReadFence[g]\land bindingRevision=v^*\land AuthorizedProgress\bigr).
\]

**Proof.** The stable suffix leaves one continuously enabled signed repair directive. Fair delivery gives it to a continuing committer; weak fairness yields construction/submission. The exclusive honest slot or verified validity attestation prevents a secret-invalid candidate from consuming the parent, and fair arbitration canonicalizes the qualifying child. Terminating honest processing and persistence advances a continuing client's frontier and opens its local fence. Reachability then linearizes the authorized operation; fair message delivery and consumption produce the successful effect.

The theorem does not cover a group with no continuing member: RFC MLS has no unilateral external “remove the last member” operation, and a removed member cannot commit its own removal. Nor does it cover a malicious DS that permanently suppresses repair, a permanent APF partition, exhausted durable storage, or a deployment that supplies neither an honest repair slot nor a validity attestation. A later relevant policy change starts a new suffix and theorem instance; it is not silently folded into the old `v*` conclusion.

## 11. Bounded TLA+/TLC target

The appropriate first mechanization is the structural state machine, not HPKE, AEAD, or ETK. Model cryptographic verification as an atomic interface that either produces a valid authenticated artifact or not; do not claim computational soundness from TLC.

### 11.1 Finite instance

Use exactly:

- `Clients = {A,B,C}` (two initial members and one possible rejoiner),
- `Rights = {read,write,admin,admit}`,
- `Revisions = 0..3`, `Epochs = 0..3`,
- `PermitIds = {p0,p1}`, `CommitIds = {c0,c1}`,
- one group and one canonical branch hash per accepted Commit,
- at most one application message slot and two competing pending Commit slots.

Apply TLC symmetry to `Clients` only in configurations whose initial authorization is symmetric; otherwise do not assert unsafe symmetry. Cap the number of policy changes and require spare epoch capacity in liveness configurations.

### 11.2 State variables

Use the following finite variables.

- `aHist`: sequence of authorization snapshots; `rev = Len(aHist)-1`; each snapshot maps `(client,right)` to `(allow,gen)`.
- `members`: current canonical MLS client set; `incGen[client,right]` and `leafKeyVersion[client]`: the four-right generation vector and fresh key/credential version installed in each active LeafNode. The pair `(client,leafKeyVersion[client])` is the modeled incarnation.
- `epoch`, `branch`, `bindRev`, `requiredRev[right]`, `cover`, `excluded`: the canonical epoch and policy binding. `requiredRev[r]` is the latest policy revision affecting right `r`; `cover` may contain extra clients.
- `readFenced`, `mustRemove`, `closedGrant`: the single group-level read fence, denied read incarnations awaiting removal, and grant-scoped closed write/admin/admit generations.
- `pending[cid]`: either `None` or record `[parentEpoch,parentBranch,bindRev,removeSet,addSet,resultMembers,committer,publicValid,clientValid,validityAttested]`. `clientValid` abstracts successful secret-dependent processing; `validityAttested` is an additional liveness premise, not a base-sequencer capability.
- `permits[pid]`: `free`, `allocated`, or `released`, plus exact `[opid,certid,client,right,dir,cutRev,gen,epoch,branch,cover,kappaHash,mu]`.
- `releaseLog`, `consumeCell`, `releaseRoot`, `spentRoot`: append-only APF records and their rollback-resistant roots. `consumeCell[opid,recipient]` is `unused` or `spent`.
- `messages`: bounded exact envelopes `[opid,certid,epoch,cutRev,kappa,mu,ciphertext,recipientSupports]`.
- `keys[client,gen]`: epochs known by that exact incarnation. Removal never deletes old elements; a qualifying successor adds the new epoch only to the resulting `(client,incGen)` pairs. Reauthorization therefore does not erase or relabel the old incarnation's knowledge.
- `serverF`, `frontierHist`: APF durable frontier, including `releaseRoot` and `spentRoot`, and its bounded history.
- `localImage[client]`, `effectiveF[client]`, `ready[client]`, `forked[client]`: recovery/rollback state. `RollbackLocal` can choose an older image, but protected actions require synchronization with `serverF`.
- `uses`: bounded successful-event log, each occurrence naming `recover(d,o,u)` or `acceptedAct(h,d,o,u)`, total witness `u`, projected support (including bottom), cut revision, generation, epoch, `(opid,certid)`, and frontier.
- `quiescent`, `repairRequested`, `progressSinceStable`: liveness-control variables.

### 11.3 Actions

`Next` is the disjunction of these small actions:

1. `PolicyDeny(c,r)` / `PolicyAllow(c,r)`: append one snapshot. If the changed grant is in the live/conservative cover for `r`, set `requiredRev[r]` to the new revision; otherwise leave the floor unchanged until an operation (such as Add) attempts to make it live. Reallow increments generation for every right and requires a later `InstallFreshLeaf` action with a larger key/credential version. A read denial of a current member atomically sets `readFenced` and adds the exact `(client,oldGen)` incarnation to `mustRemove`; a non-read denial adds only the exact grant to `closedGrant`.
2. `Preallocate(pid,...)`: creates fresh `(opid,certid)` and immutable `kappa`/`mu` inputs but cannot create a use.
3. `AuthorizeRelease(pid,...)`: at current `rev`, checks the exact frontier, `~readFenced` only for read, grant closure/current generations for non-read, structured cover, and `AuthAt(rev,S,r)` for every cover/claim support; changes `allocated` to `released`, appends `releaseLog`, updates `releaseRoot`, and records `cutRev=rev`.
4. `BuildEnvelope(pid)`: creates the certificate-bearing wire envelope only from the released record and exactly equal `kappa`/`mu`; a mutation action can attempt unequal content/context and must fail.
5. `Consume(pid,recipient)` / `ReplayConsume(pid,recipient)`: after exact verification at a ready boundary, atomically changes one cell to `spent`, advances `spentRoot`, and records `acceptedAct`; replay stutters/rejects.
6. `Recover(c,gen,msg)`: succeeds only if `epoch(msg) in keys[c,gen]`, envelope/certificate/`kappa`/`mu` equality holds, the boundary is ready and synchronized to both roots, and `Consume(opid,c)` succeeds. It records `recover(c,o,u)` against the message's release cut, not delivery time. A mutation action records `unattributed(r)` rather than dropping malformed successful provenance.
7. `BuildRepair(cid,committer)` and `BuildCompetingCommit`: create candidate children of the current parent; policy may change after construction to test stale rejection.
8. `Canonicalize(cid)`: succeeds only if the parent CAS matches and the candidate is publicly valid, has the required binding/removal result and no unauthorized add. It may select a `clientValid=FALSE` child because the base sequencer cannot verify secret-dependent processing. It increments epoch/branch, records exclusions and roots, clears the central read fence, and sets every client's `ready` flag false. `ProcessAndPersist` separately represents client-relative RFC validation.
9. `ProcessAndPersist(client,cid)`: succeeds only when `clientValid=TRUE`; it atomically advances effective/local frontier, including both roots, and becomes ready. A client that cannot process the canonical child remains not ready.
10. `InstallFreshLeaf` / `BuildAdd` / `CanonicalizeAdd`: activate a reauthorized generation only with a larger `leafKeyVersion`, and couple any Welcome to the winning child.
11. `RollbackLocal(client)`, `ReplayOldCommit`, `PresentFork`, `SyncFromAPF`: adversarial recovery actions. Old or incomparable states set `ready=FALSE`; only verified synchronization can restore it.
12. `Stabilize`, `GrantRepairSlot` / `AttachValidityAttestation`, and fair request/delivery actions for liveness. Once `quiescent=TRUE`, relevant policy-changing actions are disabled. A liveness configuration enables exactly one of the two sequencer-validity mechanisms; the base safety configuration need not.

### 11.4 Exact safety invariants

TLC should check the following named state predicates in every reachable state.

1. `TypeOK`: every variable lies in the finite types above.
2. `PolicyHistory`: `rev=Len(aHist)-1`; generations never decrease between adjacent snapshots; a `FALSE -> TRUE` transition strictly increases generation.
3. `TotalOccurrences`: every successful recovery/acceptance has exactly one typed occurrence witness; malformed or missing provenance projects to `bottom_r` and remains in `Users`.
4. `CoverSound`: `members subseteq cover`. For every logged read message, its actual recipient supports, including bottom if present, are a subset of its recorded cover.
5. `OpenReadCoherent`:

   \[
   \neg readFenced\Rightarrow
   (bindRev=requiredRev[read]\land bindRev\le rev\land mustRemove=\varnothing\land
   \forall c\in members:\ AuthAt(rev,c,read)\land incGen[c]=GenAt(rev,c,read)).
   \]

6. `CanonicalBranch`: `serverF=(branch,epoch,...)`; every accepted child names the immediately prior `(branch,epoch)` in `frontierHist`; no two accepted children share one parent.
7. `FrontierMonotone`: adjacent entries in `frontierHist` have nondecreasing revision and generations, increasing descendant epoch/branch where applicable, monotonically growing `excluded`, and append-only `releaseRoot`/`spentRoot` histories.
8. `RollbackFenced`: `ready[c]` implies `effectiveF[c]=serverF`, `~forked[c]`, and the local generation/exclusion/release/spent floor dominates every earlier accepted use. Every new use record was created at a ready synchronized boundary.
9. `ReleaseExact`: each released record has one unique `(opid,certid)`, its `cutRev` indexes an existing snapshot, its generation equals that snapshot, and its later envelope has byte-equal `kappa`, `mu`, branch, epoch, cover, and claims.
10. `OneShot`: no released `(opid,certid)` is issued twice; no central or `(opid,recipient-incarnation)` consumption cell succeeds twice, including after `RollbackLocal`.
11. `NoExposureWhileFenced`: a read message cannot be released between a covered read denial and the qualifying successor. Non-read uses instead require that their exact grant is absent from `closedGrant`; there is no group-wide non-read fence.
12. `AuthCapSafe`:

    \[
    \forall u\in uses:\ AuthAt(u.cutRev,u.support,u.right)=TRUE.
    \]

    For joint admit support, `AuthAt` checks both elements and the joint rule.
13. `ReadPostExclusion`: for each recorded read exclusion `(c,oldGen,e')`, the exact pair `(c,oldGen)` is not active, `e' notin keys[c,oldGen]`, and no message released in any descendant epoch lists the excluded grant in an actual recipient support.
14. `NoGenerationResurrection`: no exact `(client,right,oldGen)` in `excluded` reappears in a release, member binding, or successful support. Every reauthorized right has a strictly larger generation and `leafKeyVersion` before use.
15. `AdminAdmitValidity`: every accepted admin Commit has an exact admin or repair release/consumption record; every accepted Add has the candidate's current admit generation, recomputed non-self-referential KeyPackage binding, required admin co-support, and a winning-Commit Welcome.

The model should include mutation switches that deliberately omit `members subseteq cover`, total unattributed occurrences, immutable envelope equality, release/consumption uniqueness, spent-root recovery, parent CAS, current-revision comparison, fresh reauthorization keys, or ready/frontier comparison. TLC should produce the expected counterexample for each switch. This is stronger evidence that the invariants test the intended contract rather than only restate guarded actions.

### 11.5 Liveness properties

Use weak fairness only for the actions covered by the progress theorem: directive delivery, `BuildRepair`, the selected `GrantRepairSlot` or `AttachValidityAttestation` mechanism, `Canonicalize`, `ProcessAndPersist`, authorized request, `Consume`, and delivery. Do not make adversarial policy changes fair. `quiescent` denotes the exact stable suffix, not merely a long quiet interval.

With `Enough = epoch < MaxEpoch and exists a continuing authorized online honest member` and `ValidityForProgress = honestRepairSlot or validAttestation`, check:

\[
L_{repair}\equiv
(quiescent\land readFenced\land Enough\land ValidityForProgress)
\leadsto
(\neg readFenced\land bindRev=requiredRev[read]\land mustRemove=\varnothing).
\]

Then check:

\[
L_{progress}\equiv
(quiescent\land\neg readFenced\land AuthorizedRequester)
\leadsto progressSinceStable.
\]

Also check the negative controls: without fair delivery, with APF unreachable, or with neither an honest repair slot nor a valid-processing attestation, TLC must admit an infinite stuttering/fenced behavior. A publicly valid but `clientValid=FALSE` candidate may win in the base safety model and strand the group; the liveness configuration excludes exactly that behavior through `ValidityForProgress`. This is expected and prevents an accidental claim that public sequencing verifies secret-dependent MLS validity.

This finite instance is intentionally small enough for TLC: three clients, four rights, four revisions/epochs, two permit IDs, two competing commits, one message. If state count is still excessive, first fix `Rights={read,write}` for the concurrency run and run a separate `{admin,admit}` configuration over the same module; do not remove the four-right invariants from the specification. TLC provides bounded bug-finding, not an unbounded mechanized proof. A later TLAPS/Ivy proof can generalize the structural invariant once the model stabilizes.

## 12. Impossible or overstated claims to remove

1. **“RFC 9420 implements external authorization.”** False. MLS authenticates protocol actors and provides policy hooks; the application must enforce ACLs and consistent authorization.
2. **“A Remove proposal makes revocation effective.”** False. Only a successor Commit changes membership, and base MLS permits a Commit to omit a pending proposal.
3. **“A successor epoch is atomically accepted by the group.”** False in an asynchronous system. LAP-MLS distinguishes canonicalization from each client's verified, persisted acceptance.
4. **“Removal erases the old member's capability.”** False. The removed endpoint can retain old secrets and decrypt old/late ciphertext. The defensible claim concerns fresh honest payloads in qualifying successor epochs.
5. **“MLS removal alone excludes write, admin, and admit.”** False. Those are application acceptance rights and need current verifier state, exact APF evidence, and replay protection.
6. **“A signed policy revision prevents rollback.”** False. An old signed state remains authentic. Anti-rollback requires a monotonic APF/hardware floor and fail-closed recovery.
7. **“The DS is a complete protection boundary.”** False against bypass or DS compromise. Honest recipients/senders must validate locally.
8. **“Commit-immediate revocation is compatible with offline partitioned operation.”** Not for a linearizable authority. An endpoint unable to learn whether a denial committed must block or weaken the semantics.
9. **“Any operation-specific permit suffices.”** Overstated. A reusable, payload-independent, or stockpilable permit lets the implementation backdate later effects. The permit must be one-operation, hash/context/generation-bound, and linearized as the operation admission.
10. **“All current MLS members are authorized readers” follows from MLS.** False. It follows only from the application-maintained client/incarnation mapping and sound read cover. Every user-level revoke must expand to all device leaves.
11. **“Post-removal secrecy holds despite a colluding continuing member.”** Impossible: a currently authorized reader can reveal plaintext or keys out of band.
12. **“ETK or the CCS 2021 MLS theorem directly proves the full concrete theorem.”** Overstated. ETK covers the final-RFC external-operations core under its own predicate and notes weaker PCS; the modular full-SGM theorem targets an earlier draft. The LAP bridge lemma and adapter proof remain obligations.
13. **“TLC mechanizes the cryptographic theorem or proves all group sizes.”** False. It checks a bounded structural model with crypto interfaces treated axiomatically.
14. **“Progress holds against a suppressing DS, permanent APF partition, no continuing member, or perpetual competing policy changes.”** False. Each is explicitly excluded by the conditional progress theorem.
15. **“Public control Commits preserve ordinary MLS metadata privacy.”** False. Requiring inspectable authorization metadata creates a privacy trade-off; deployments needing privacy require a zero-knowledge/committed policy proof or a different sequencer design, which is outside this first realization.

## 13. Recommended publication claim

The defensible result is:

> We give a complete structural instantiation of a support-sensitive authorization–capability interface for MLS using a linearizable one-shot release/fence service, cycle-free immutable-object commitments, rollback-resistant consumption, an authorization-bound MLS epoch transition, and mandatory application adapters. The deterministic theorem `GoodTrace_0 => AuthCapSafe_0` holds at a precise commit-immediate release cut, and conditional progress follows on a stable suffix with explicit sequencer-validity, reachability, and fairness assumptions. A concrete end-to-end cryptographic theorem remains conditional on the open lemma that the stated qualifying-removal predicate implies the exact ETK freshness/safety predicate and successor application-key secrecy; we do not claim that ETK already discharges this bridge.

Do not call APF mediation, MLS rekeying, dynamic membership, replay defense, or generic composition new. The paper's positive contribution is the explicit cross-system mapping, support-cover rule, operation-cut semantics, right-specific exclusion, and the theorem that composes them.

## Primary references

- R. Barnes et al., [*The Messaging Layer Security (MLS) Protocol*, RFC 9420](https://www.rfc-editor.org/rfc/rfc9420), 2023.
- B. Beurdouche et al., [*The Messaging Layer Security (MLS) Architecture*, RFC 9750](https://www.rfc-editor.org/rfc/rfc9750), 2025.
- C. Cremers, E. Günsay, V. Wesselkamp, and M. Zhao, [*ETK: External-Operations TreeKEM and the Security of MLS in RFC 9420*](https://eprint.iacr.org/2025/229), EUROCRYPT 2026.
- J. Alwen, S. Coretti, D. Jost, and M. Mularczyk, [*Continuous Group Key Agreement with Active Security*](https://eprint.iacr.org/2020/752), TCC 2020.
- J. Alwen, S. Coretti, Y. Dodis, and Y. Tselekounis, [*Modular Design of Secure Group Messaging Protocols and the Security of MLS*](https://eprint.iacr.org/2021/1083), CCS 2021.
- T. Wallez, J. Protzenko, B. Beurdouche, and K. Bhargavan, [*TreeSync: Authenticated Group Management for Messaging Layer Security*](https://www.usenix.org/conference/usenixsecurity23/presentation/wallez), USENIX Security 2023.
- M. Weidner, M. Kleppmann, D. Hugenroth, and A. R. Beresford, [*Key Agreement for Decentralized Secure Group Messaging with Strong Security Guarantees*](https://www.cl.cam.ac.uk/~arb33/papers/WeidnerEtAl-DecentralisedGroupKeyAgreement-CCS2021.pdf), CCS 2021.

## Round-2 repair status

**SPEC COMPLIANCE: PASS for the structural/interface design. CRYPTOGRAPHIC DISCHARGE: OPEN.** This round restores the total occurrence-indexed trace semantics and all nine `GoodTrace` clauses; replaces self-referential KeyPackage and release hashes with canonical cycle-free commitments; defines the exact pre-bound logical object and certificate-bearing envelope checks; adds rollback-resistant release/spent roots and per-recipient one-shot consumption; separates the read group fence from non-read grant closure; requires fresh generation/key/credential material for every reauthorization; gives one common-experiment bound; and strengthens progress to a stable suffix with explicit sequencer validity. The only publication-gating proof item intentionally left open is `Bridge_ETK^remove`; no end-to-end computational MLS claim is approved until that lemma is discharged against the cited ETK version.
