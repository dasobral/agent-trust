# Formal Repair Audit - Phase 1

## Scope and verdict

This audit compares Phase 1 of `Pasted markdown(2).md` with the complete text of the 91-page Second Edition study notes. Page references below use the printed page number when one exists; physical PDF page numbers are supplied where useful for front matter.

The Phase 1 repair is necessary. The present notebook still has four coupled defects:

1. `Cap_tau` embeds "non-negligible probability" in a predicate on one fixed trace. Consequently `Readers_tau`, `Actors_tau`, `UseSupp_tau`, and `Users_tau` are not deterministic trace objects.
2. The guard and continuity machinery require an exact `CompleteSupp` family. That makes exact global support knowledge a principal safety premise and can hide the coordination problem in `chi`.
3. Theorem 6.6 mixes a structural implication, implementation clauses, component assumptions, and the absence of mechanism-specific bad events. Its excluded-support proof case also starts from an already successful `Cap_tau` use and then rules that same use out by assuming no exclusion/protection failure.
4. `ACCSafe` names the target property after one sufficient interface, and the prose sometimes says the system "authorizes" an operation, uses unqualified "current authorization," or claims a generality broader than the first group/MLS/CGKA publication should claim.

The repair should be made as one coordinated change. A partial edit - for example, renaming `ACCSafe` without replacing `Cap_tau`, or adding a cover while leaving exact `CompleteSupp` inside `FrontierOK` - will not satisfy Phase 1.

## Normative replacement model

### 1. Deterministic successful-use events

Keep the existing universes `D`, `G`, `R`, `I`, `Grant_r`, operations, epochs, and proof DAGs. Add the following total support type for each right:

\[
  \mathsf{Supp}_r^+ = \{S \subseteq_{\mathrm{fin}} \mathsf{Grant} : S \ne \varnothing\},
  \qquad
  \overline{\mathsf{Supp}}_r = \mathsf{Supp}_r^+ \uplus \{\bot_r\}.
\]

The distinguished value `bottom_r` records a successful effect for which no valid grant-support provenance is available. Extend authorization by definition:

\[
  \mathsf{Auth}_v^r(\bot_r)=0
  \quad\text{for every }v\in V_\bot.
\]

This bottom tag is important. Without it, an unprovenanced successful effect can disappear from `Users_tau`, making the target property vacuously true exactly when provenance fails.

For an operation `o` with fields `(g_o,r_o,e_o,dir_o)`, define the following tagged union:

\[
\begin{aligned}
\mathsf{UseWitness}(o)={}&
 \{\mathsf{prov}(e_\pi,c,\pi,S):
   e_\pi\preceq e_o,\ c\in V_{e_\pi,r_o},\\
 &\hspace{39mm}\pi\in\mathsf{Proof}(e_\pi,r_o,c),\
   S\in\mathsf{Supp}_{r_o}^+\}\\
 &\uplus\{\mathsf{unattributed}(r_o)\}.
\end{aligned}
\]

Let

\[
\mathsf{support}(\mathsf{prov}(e_\pi,c,\pi,S))=S,
\qquad
\mathsf{support}(\mathsf{unattributed}(r_o))=\bot_{r_o}.
\]

Treat every trace event as an occurrence with a unique identity `epsilon`, even when two occurrences have the same payload. Instrument traces with direction-specific success occurrences

\[
  \epsilon:\mathsf{recover}(d,o,u),
  \qquad
  \epsilon:\mathsf{acceptedAct}(h,d,o,u),
  \qquad u\in\mathsf{UseWitness}(o).
\]

The first occurrence means endpoint `d` actually recovers the fresh payload protected by confidentiality-emission operation `o`. The second means honest boundary `h` actually accepts the integrity-relevant effect of `o` as caused through endpoint `d`.

The operational semantics supplies a partial, occurrence-indexed witness function

\[
\mathsf{OpWitness}_{\tau_{\leq\epsilon}}(\epsilon,d,o)
  \in
  \{(e_\pi,c,\pi,S)\}
\]

only when that exact success occurrence was produced through capability `c` and proof `pi`, the proof and operation contexts agree on authority, group, right, epoch/lineage, direction, payload or action digest, and protocol context, and `S=gsupp(pi)`. The trace label is canonical, not adversary-selectable:

\[
\mathsf{canon}_{\tau}(\epsilon)=
\begin{cases}
\mathsf{prov}(e_\pi,c,\pi,S),
 &\mathsf{OpWitness}_{\tau_{\leq\epsilon}}(\epsilon,d,o)
    =(e_\pi,c,\pi,S),\\
\mathsf{unattributed}(r_o),&\text{otherwise.}
\end{cases}
\]

A well-formed success occurrence must carry `u=canon_tau(epsilon)`. A missing witness, an invalid proof, a context mismatch, an inconsistent support, or an attempted relabeling therefore normalizes to `unattributed(r_o)` and projects to `bottom_r`; it cannot be repaired by attaching some unrelated valid proof.

Define the deterministic occurrence relation:

\[
\begin{aligned}
\mathsf{ExerciseOcc}_\tau(\epsilon,d,o,u) \iff {}&
  \bigl(dir(o)=\mathsf{confEmit}\land
  (\epsilon:\mathsf{recover}(d,o,u))\in\tau\bigr)\\
  &\lor\bigl(dir(o)=\mathsf{intAccept}\land
  \exists h\in H_{\mathrm{hon}}:\
  (\epsilon:\mathsf{acceptedAct}(h,d,o,u))\in\tau\bigr).
\end{aligned}
\]

Then replace `Readers_tau`, `Actors_tau`, and the old probability-bearing `Cap_tau` path with:

\[
\begin{aligned}
  \mathsf{UseSupp}_\tau(o)
    &= \{(\epsilon,d,u,\mathsf{support}(u)):
          \mathsf{ExerciseOcc}_\tau(\epsilon,d,o,u)\},\\
  \mathsf{Users}_\tau(o)
    &= \{S:\exists \epsilon,d,u\;
          (\epsilon,d,u,S)\in\mathsf{UseSupp}_\tau(o)\}.
\end{aligned}
\]

`Readers_tau` and `Actors_tau` may remain only as direction-specific projections of `ExerciseOcc_tau`; they must not contain a probability phrase or a modal "can" predicate, and they must not erase occurrence identity before prefix-sensitive checks are performed.

The provenance condition becomes deterministic:

\[
\begin{aligned}
\mathsf{ProvOK}_\tau(o) \iff
  \forall(\epsilon,d,u,S)\in\mathsf{UseSupp}_\tau(o):\ \exists e_\pi,c,\pi:\ {}&
  u=\mathsf{prov}(e_\pi,c,\pi,S)\\
  &\land \mathsf{OpWitness}_{\tau_{\leq\epsilon}}(\epsilon,d,o)
       =(e_\pi,c,\pi,S)\\
  &\land \mathsf{ContextMatch}_{\tau_{\leq\epsilon}}
       (\epsilon,o,e_\pi,r_o,c,\pi)\\
  &\land S=\mathsf{gsupp}(\pi)\\
  &\land\mathsf{ValidProof}_{\tau_{\leq \epsilon}}
       (e_\pi,r_o,c,\pi),
\end{aligned}
\]

Here `epsilon` is bound by the displayed universal quantifier and names the exact success occurrence being checked. A cryptographic provenance failure is the event `not ProvOK`; its probability belongs only to a sampled experiment. In particular, a future proof or a later repeated success cannot validate an earlier occurrence.

Replace the current callable-proof support-conservation formula by the actual-use form:

\[
\begin{aligned}
  &\mathsf{ExerciseOcc}_\tau
    (\epsilon,d,o,\mathsf{prov}(e_\pi,c,\pi,S))\\
  &\qquad\Longrightarrow
  \mathsf{DispositionOK}_{\tau_{\leq\epsilon}}(e_o,r_o,\pi,S).
\end{aligned}
\]

The prose must say "a proof actually exercised in `tau`" at the trace level. Statements about an adversary being able to exercise a retained proof with non-negligible probability belong in `Sec_C^r` or the computational games.

### 2. The renamed target property

Keep the effective cut and support authorization definitions, extended to reject `bottom_r`:

\[
\mathsf{Allowed}_\sigma(\tau,o)=
\begin{cases}
\varnothing,&\mathsf{cut}_\sigma(\tau,o)=\bot,\\
\{S\in\mathsf{Supp}_{r_o}^+:
\mathsf{Auth}_{v}^{r_o}(S)=1\},&v=\mathsf{cut}_\sigma(\tau,o)\in\mathbb N.
\end{cases}
\]

Use the interface-independent name:

\[
\begin{aligned}
  \mathsf{Compat}_\sigma(\tau,o)
    &\iff \mathsf{Users}_\tau(o)\subseteq
            \mathsf{Allowed}_\sigma(\tau,o),\\
  \mathsf{AuthCapSafe}_\sigma(\tau)
    &\iff \forall o:\mathsf{Exposed}_\tau(o)
       \Longrightarrow \mathsf{Compat}_\sigma(\tau,o).
\end{aligned}
\]

`ACC` remains the name of the proposed sufficient mechanism/interface. The target does not inherit that name.

For consistency, rename the computational advantages to `Adv^{AuthCapConf}` and `Adv^{AuthCapInt}`. The sampled game trace records `recover` and `acceptedAct` events deterministically; probability is taken over sampled traces, adversary coins, and protocol coins.

### 3. Sound support cover

Let `g` be a successful guard occurrence for operation `o`, and let `tau_{<=g}` be the trace prefix through that occurrence. The guard record identifies the exact persisted frontier `F_g` that it accepted. For each operation define a finite, typed family checked by that guard occurrence:

\[
  \widehat{\mathcal G}(o,g)
  \subseteq_{\mathrm{fin}}
  \overline{\mathsf{Supp}}_{r_o}.
\]

Each accepted frontier carries a typed family

\[
  \widehat{\mathcal G}^{F_g}_{e,r}
  \subseteq_{\mathrm{fin}}\overline{\mathsf{Supp}}_r
\]

for every protected `(e,r)`. Define a deterministic, prefix-local extraction function

\[
\mathsf{ExtractCover}_{\tau_{\leq g}}(F_g,o,\mathcal Q_o)
  \subseteq_{\mathrm{fin}}\overline{\mathsf{Supp}}_{r_o}
\]

that conservatively projects the accepted epoch/right cover to the exact operation context. It must satisfy

\[
\begin{aligned}
\mathcal Q_o&\subseteq
 \mathsf{ExtractCover}_{\tau_{\leq g}}(F_g,o,\mathcal Q_o),\\
\mathsf{RelevantCover}_{\tau_{\leq g}}
 (F_g,o,\widehat{\mathcal G}^{F_g}_{e_o,r_o})
 &\subseteq
 \mathsf{ExtractCover}_{\tau_{\leq g}}(F_g,o,\mathcal Q_o).
\end{aligned}
\]

The exact checked operand is

\[
 \widehat{\mathcal G}(o,g)=
 \mathsf{ExtractCover}_{\tau_{\leq g}}(F_g,o,\mathcal Q_o).
\]

`RelevantCover` and `ExtractCover` are realization-defined but typed and prefix-local; a concrete realization must prove that every later successful use of this exposed operation arises from the extracted family unless a named provenance, lineage, exclusion, or protection event occurs. They may conservatively retain irrelevant or impossible supports.

Separate authentication of the operand from semantic cover soundness:

\[
\begin{aligned}
  \mathsf{CoverCommitOK}_{\tau_{\leq g}}
    (g,o,F_g,\widehat{\mathcal G}(o,g))&\in\{0,1\},\\
  \mathsf{SoundCover}_\tau(o,g)
    &\iff \mathsf{Users}_\tau(o)\subseteq\widehat{\mathcal G}(o,g).
\end{aligned}
\]

`CoverCommitOK` checks that the authenticated operand is exactly the finite family extracted from the named persisted frontier and evaluated by this guard occurrence, and that it is bound to the operation context. It does not claim that the family is globally exact. `SoundCover` is the whole-trace structural obligation. An implementation establishes it from the prefix-local extraction rule, provenance accounting, conservative transitions, mediation, and its cryptographic assumptions; it is not recomputed by looking into the future.

The guard becomes:

\[
\begin{aligned}
\mathsf{GuardCheck}_\sigma(\tau_{\leq g},g,o,F_g,\phi,
       \widehat{\mathcal G}(o,g))\iff{}&
  \mathsf{VerifyWitness}_\sigma(\phi,o)=1\\
  &\land\mathsf{Match}(\phi,\mathsf{bind}(o))\\
  &\land\mathsf{CoverCommitOK}_{\tau_{\leq g}}
       (g,o,F_g,\widehat{\mathcal G}(o,g))=1\\
  &\land v_\phi=v_o\\
  &\land\forall S\in\widehat{\mathcal G}(o,g):
       \mathsf{Auth}_{v_o}^{r_o}(S)=1\\
  &\land\mathsf{FrontierCoverOK}
       (\tau_{\leq g},g,o,F_g,\widehat{\mathcal G}(o,g)).
\end{aligned}
\]

`FrontierCoverOK` holds exactly when `F_g` equals or security-dominates the boundary's persisted frontier, no relevant fork is unresolved, the accepted epoch/right cover is the one authenticated by `F_g`, and the checked operation family equals `ExtractCover_{tau_{<=g}}(F_g,o,Q_o)`. This is the formal link between the operation guard and the persisted cover frontier.

Do not put `SoundCover_tau` inside the run-time check: it is a property of the completed trace and the support abstraction, not something the pre-exposure boundary can decide by inspecting future execution. `GoodTrace` requires it separately, while the mechanism/realization lemma below proves it from prefix-local invariants except on named bad events.

At the occurrence `a` that accepts an epoch/frontier state, require the prefix-local live-cover invariant:

\[
  \mathsf{LiveSupp}_{C,\tau_{\leq a}}(e,r)
  \subseteq \widehat{\mathcal G}^{F_a}_{e,r}.
\]

Use one typed disposal/carry operator for ordinary transitions and fork merges. For a transition or merge certificate `kappa`, a prefix `tau_{<=a'}`, right `r`, and finite source family `F subseteq SuppBar_r`, define

\[
\begin{aligned}
\mathsf{Dispose}^{r}_{\tau_{\leq a'}}(\mathcal F,\kappa)
  &=\{S\in\mathcal F:
       \mathsf{DispositionCertOK}^{r}_{\tau_{\leq a'}}(S,\kappa)=1\},\\
\mathsf{Carry}^{r}_{\tau_{\leq a'}}(\mathcal F,\kappa)
  &=\mathcal F\setminus
       \mathsf{Dispose}^{r}_{\tau_{\leq a'}}(\mathcal F,\kappa).
\end{aligned}
\]

`DispositionCertOK` accepts only a certified qualifying right-specific exclusion, or a realization-defined authenticated impossibility proof whose soundness is separately established. It is false for `bottom_r`; an unattributed possibility is never silently discarded.

For an ordinary certified successor `kappa:e -> e'` accepted at `a'`, require

\[
  \mathsf{Carry}^{r}_{\tau_{\leq a'}}
    (\widehat{\mathcal G}^{F_a}_{e,r},\kappa)
  \subseteq \widehat{\mathcal G}^{F_{a'}}_{e',r}.
\]

For a certified fork merge `rho:(e_1,e_2)->e_*` accepted at `a_*`, use the same operator with the typed union of both parent families:

\[
  \mathsf{Carry}^{r}_{\tau_{\leq a_*}}
  (\widehat{\mathcal G}^{F_1}_{e_1,r}
   \cup\widehat{\mathcal G}^{F_2}_{e_2,r},\rho)
  \subseteq \widehat{\mathcal G}^{F_*}_{e_*,r}.
\]

An implementation may retain an extra impossible support indefinitely. The guard then may reject because that extra support is unauthorized. This is the intended trade-off:

\[
  \text{over-approximation} \Longrightarrow
  \text{safety preserved and availability may decrease}.
\]

Dropping a support outside `Dispose` is an unsafe under-approximation. The same `Carry` signature is used for one-parent successors and multi-parent merges, so there is no arity change or untyped union.

The exact property may remain under an explicitly stronger name:

\[
\begin{aligned}
\mathsf{ExactLiveSupp}_{\tau_{\leq a}}(F_a,e,r,\mathcal G)
  \iff{}&\mathsf{FrontierCoverCommitOK}_{\tau_{\leq a}}
      (F_a,e,r,\mathcal G)\\
  &\land \mathcal G=\mathsf{LiveSupp}_{C,\tau_{\leq a}}(e,r).
\end{aligned}
\]

`ExactLiveSupp` may be an optimization, realization theorem, mechanization lemma, or appendix property. It must not occur in the premises of the principal safety theorem, principal guard, `FrontierCoverOK`, ordinary transition acceptance, or fork resolution.

### 4. Pure structural good-trace predicate

Let an exposure event reference the exact successful guard record used at that boundary, so the guard and the exposed operation cannot be separated by an unbound state change. Define the following deterministic predicates:

- `MediationOK_tau(o,g)`: exposure of `o` references successful guard record `g` for that exact operation, and the checked binding is unchanged through exposure.
- `ContextOK_tau(o,g)`: authority, operation id, group, right, epoch, historical dependency, generation map, witness, cover commitment, and protocol context authenticate and match.
- `SupportCoverOK_tau(o,g)`: `CoverCommitOK_{tau_{<=g}}(g,o,F_g,widehat G(o,g))=1` and `SoundCover_tau(o,g)`.
- `CutAuthOK_sigma(tau,o,g)`: `Covers_sigma(tau,phi_g,o)`, the witness projection equals `cut_sigma(tau,o)`, and every `S in widehat G(o,g)` is authorized by `Auth^{r_o}` at that cut.
- `ProvOK_tau(o)`: every occurrence-indexed exercise has the exact non-bottom operational witness, prefix-valid proof, matching context, and grant support specified above.
- `ContinuityOK_tau(o,g)`: `FrontierCoverOK(tau_{<=g},g,o,F_g,widehat G(o,g))`, no relevant fork is unresolved, every accepted lineage/fork transition obeys the single typed `Carry` rule above, and the guard-to-exposure interval does not change the bound frontier or cover.
- `ResumeOK_sigma(tau,o,g)`: for every exact source `x=(i,g_o,r_o,gamma)` and pre-cut accepted lineage support `S` containing `x`, if `x` is denied at `cut_sigma(tau,o)` and this exposed `o` is later on that lineage, there exist named epochs and a named certificate occurrence before `g` witnessing `Exclude_C^{r_o}(e,e',x)` with `Qualifies_C^{r_o}(e,e',x)=1`.
- `PostExcludeOK_tau(o,g)`: for every `(x,e,e')` furnished by `ResumeOK_sigma(tau,o,g)`, no occurrence `(epsilon,d,u,S) in UseSupp_tau(o)` in a qualifying later epoch has `x in S`; an alternative occurrence with a separately proven support omitting `x` is unaffected.
- `MessageProtectOK_tau(o,g)`: the exposed artifact/accepted action is bound to the same operation context, and every successful recovery or accepted action occurrence is represented by `ExerciseOcc_tau` and its canonical operational witness rather than by a message-protection failure.

Now define:

\[
\begin{aligned}
\mathsf{GoodTrace}_\sigma(\tau)\iff
\forall o:\mathsf{Exposed}_\tau(o)\Longrightarrow
\exists g:\;&\mathsf{MediationOK}_\tau(o,g)\\
&\land\mathsf{ContextOK}_\tau(o,g)\\
&\land\mathsf{SupportCoverOK}_\tau(o,g)\\
&\land\mathsf{CutAuthOK}_\sigma(\tau,o,g)\\
&\land\mathsf{ProvOK}_\tau(o)\\
&\land\mathsf{ContinuityOK}_\tau(o,g)\\
&\land\mathsf{ResumeOK}_\sigma(\tau,o,g)\\
&\land\mathsf{PostExcludeOK}_\tau(o,g)\\
&\land\mathsf{MessageProtectOK}_\tau(o,g).
\end{aligned}
\]

Every conjunct is deterministic. In particular, `PostExcludeOK` says that no successful exercise event occurs; it does not say that success has negligible probability.

### 5. Replacement theorem statements

Separate the elementary two-inclusion result from the realization argument. First define the exact core used by the set proof:

\[
\begin{aligned}
\mathsf{CoverAuthCore}_\sigma(\tau)\iff
\forall o:\mathsf{Exposed}_\tau(o)\Longrightarrow\exists g:\ {}&
\mathsf{MediationOK}_\tau(o,g)\\
&\land\mathsf{SupportCoverOK}_\tau(o,g)\\
&\land\mathsf{CutAuthOK}_\sigma(\tau,o,g).
\end{aligned}
\]

Replace present Theorem 6.6 with the following theorem and corollary, keeping the number if minimizing cross-reference churn:

> **Definition 6.6a (Structural good trace).** `GoodTrace_sigma(tau)` is the deterministic predicate above.
>
> **Theorem 6.6 (Elementary cover-authorization theorem).** Fix a revocation semantics `sigma` and an admissible trace `tau`. Then
> \[
>   \mathsf{CoverAuthCore}_\sigma(\tau)
>   \Longrightarrow
>   \mathsf{AuthCapSafe}_\sigma(\tau).
> \]
> This is the elementary set-transitivity core. It assumes neither an ACC implementation nor the absence of a bad-event family.
>
> **Corollary 6.6b (Structural good-trace safety).** `GoodTrace_sigma(tau) -> AuthCapSafe_sigma(tau)`, because `GoodTrace_sigma(tau) -> CoverAuthCore_sigma(tau)` by projection.

The proof of Theorem 6.6 should be only:

> Fix an exposed `o` and `S in Users_tau(o)`. By `SupportCoverOK`, `S in widehat G(o,g)`. By `CutAuthOK`, `Auth^{r_o}_{cut_sigma(tau,o)}(S)=1`. Hence `S in Allowed_sigma(tau,o)`. Since `o` and `S` were arbitrary, `AuthCapSafe_sigma(tau)` holds.

No continuity, provenance, exclusion, or message-protection conjunct is needed for this two-inclusion inference once `SoundCover` and cover authorization are assumed. Those clauses are needed in the separate mechanism/realization lemma that establishes `GoodTrace`; they must not be presented as proof premises used by set transitivity or smuggled in through probabilistic phrases.

State the separate bridge explicitly:

> **Lemma 6.6c (Mechanism/realization establishes a good trace).** For a named realization `Pi`, if its ACC mediation, context, prefix-local extraction, frontier/carry, provenance, resumption, exclusion, and protection mechanisms satisfy their stated deterministic invariants on `tau`, and no corresponding implementation-specific bad event occurs, then `GoodTrace_sigma(tau)`.

The proof of this lemma discharges every `GoodTrace` conjunct one by one. It is the place for realization assumptions and bad-event exclusions; it is not part of the elementary cover-authorization theorem.

Restate the ideal composition corollary as:

> **Corollary (Ideal structural composition).** If every admissible trace of `Pi` is a `GoodTrace_sigma`, then `SecComp^{tr}_{Pi,sigma}` holds, where trace composition security quantifies `AuthCapSafe_sigma`.

Restate fail-closed separation as:

> **Proposition (Fail-closed safety is not liveness).** `AuthCapSafe_sigma` alone implies neither a qualifying exclusion nor eventual authorized progress.

Restate the safe-resumption result as a consequence of the explicit good-trace resumption clauses, not of target safety alone:

> **Corollary (Safe resumption on a good trace).** Let exact source `x=(i,g,r,gamma)` be denied at the effective cut and occur in a pre-cut accepted support on the relevant lineage. If `GoodTrace_sigma(tau)` and a later operation for `r` is exposed on that lineage, a qualifying `Exclude_C^r` for `x` precedes that exposure, and no successful exercise of the later operation has a support containing `x`. A separately authenticated support omitting `x` remains eligible for its own guard check.

The separation theorem (6.3) and lower bound (6.13-6.17) remain substantively valid after replacing the target name and deriving their `Users` facts from explicit `recover` events.

### 6. Mechanism failures and probability, strictly after the trace theorem

Define implementation-specific bad events on one named sampled execution. The minimum useful family is:

\[
\mathcal B'=
\{B_{auth},B_{mediate},B_{context},B_{cover},B_{cut},B_{guard},
B_{frontier},B_{lineage},B_{provenance},B_{resume},B_{exclude},B_{protect}\}.
\]

For an exposure occurrence `xi`, let `GuardRef_tau(xi)=g` be its exact checked guard record and let `CheckedCover_tau(g)=widehat G(o,g)`. Define support omission with all occurrence and operand quantifiers explicit:

\[
\begin{aligned}
B_{cover}(\tau)\iff
\exists \xi,o,g,S:\ {}&
 \mathsf{ExposeOcc}_\tau(\xi,o)\\
&\land \mathsf{GuardRef}_\tau(\xi)=g\\
&\land \mathsf{SuccessfulGuard}_\tau(g,o)\\
&\land S\in\mathsf{Users}_\tau(o)
       \setminus\mathsf{CheckedCover}_\tau(g).
\end{aligned}
\]

Define the distinct resumption failure event:

\[
\begin{aligned}
B_{resume}(\tau)\iff
\exists \xi,o,g,x,S:\ {}&
 \mathsf{ExposeOcc}_\tau(\xi,o)
 \land \mathsf{GuardRef}_\tau(\xi)=g\\
&\land x\in S
 \land \mathsf{PreCutAcceptedLineageSupp}_\tau(S,x,o)\\
&\land \mathsf{Auth}^{r_o}_{\mathsf{cut}_\sigma(\tau,o)}(S)=0\\
&\land \neg\exists e,e',\eta<_{\tau}g:\
   (\eta:\mathsf{Exclude}^{r_o}_{C}(e,e',x))\in\tau\\
&\hspace{34mm}\land
   \mathsf{Qualifies}^{r_o}_{C}(e,e',x)=1.
\end{aligned}
\]

`B_resume` is failure to perform the required qualifying exclusion before a later exposure. It is distinct from `B_exclude`, which is an actual successful exercise after a qualifying exclusion through a support still containing the excluded source.

Use `B_context` only for authentic-binding failures; do not treat support omission as a context-signature failure. Use `B_guard` when exposure follows a purported successful guard even though some member of the exact `CheckedCover_tau(g)` was unauthorized at the named revision. `B_cut` is a verifying but non-covering freshness witness. `B_provenance` includes a canonical bottom tag, a missing/invalid operational witness, a context mismatch, or an invalid prefix proof. The existing `B_sound` installation event may remain as an additional realization event, but it is not a premise of the elementary structural theorem.

The mechanism/realization lemma must prove, conjunct by conjunct, the mechanism-to-structure statement:

\[
  \{\tau:\neg\mathsf{GoodTrace}_\sigma(\tau)\}
  \subseteq \bigcup_{B_j\in\mathcal B'} B_j.
\]

Together with Theorem 6.6, on one common distribution over sampled traces:

\[
\begin{aligned}
\Pr[\neg\mathsf{AuthCapSafe}_\sigma]
&\le \Pr[\neg\mathsf{GoodTrace}_\sigma]\\
&\le \Pr\!\left[\bigcup_{B_j\in\mathcal B'}B_j\right]\\
&\le \sum_{B_j\in\mathcal B'}\Pr[B_j]\\
&\le \sum_{B_j\in\mathcal B'}\epsilon_j(\lambda).
\end{aligned}
\]

This replaces the current theorem premise "implement ACC-1 through ACC-6 and no bad event occurs." The elementary theorem uses only the two inclusions. ACC mechanisms are the means by which a concrete realization proves every `GoodTrace` conjunct, including the coverage inclusion, and bounds the `B_j`; they are not duplicated as assumptions of the set-transitivity theorem.

## Exhaustive location ledger

### A. Trace-level capability/use semantics

The following locations must change together:

| Location | Present issue | Required edit |
|---|---|---|
| Executive Conceptual Preview, "Capability support" (physical PDF p. 4) | Says "exercisable" without yet distinguishing actual trace use from computational ability. | Say supports tag actual successful uses in a trace; ability/advantage is defined in experiments. |
| Section 1.6, printed p. 4 | `Users_tau` is described as actual use but inherits `Cap_tau`. | Point forward to explicit `recover`/`acceptedAct` events. |
| Section 2.7, printed p. 8 | Repeats `Users` as actual use. | State that it is the projection of successful exercise events. |
| Section 3.1 symbol table, printed pp. 12-13 (physical pp. 23-24) | Defines `Cap_tau`, `UseSupp_tau`, and `Users_tau` under the ambiguous semantics. | Remove `Cap_tau`; add occurrence-indexed `ExerciseOcc_tau`, direction-specific success occurrences, the canonical operational-witness/bottom rule, and revised `UseSupp`/`Users`. |
| Section 3.2, printed p. 13 | Claims logical-level separation that the model does not actually satisfy. | After the repair, explicitly give the chain deterministic event trace -> sampled bad events -> computational advantages. |
| Section 4.4 opening, printed p. 18 | Says `Cap_tau` includes retained/corrupt capability. | Replace with actual exercise events; retain potential ability only in game-facing prose. |
| Section 4.4.1, printed p. 20 (physical p. 31) | Defines `Cap_tau(... )` "with non-negligible probability." | Delete and insert the event semantics above. |
| Section 4.4.2, printed pp. 21-22 | Support conservation quantifies `Cap_tau` and "callable" historical proofs. | Quantify exact `ExerciseOcc_tau` occurrences and their prefixes; move modal callable/non-negligible language to `Sec_C^r`. |
| Section 4.4.3 item 3, printed p. 23 | "Every usable capability" blurs trace and experiment. | Trace version: every successful exercise has valid nonempty provenance; computational version: invalid provenance occurs only negligibly. |
| Section 4.6, printed pp. 25-27 (physical pp. 36-38) | `Readers_tau` and `Actors_tau` contain `Cap_tau`; `UseSupp` inherits it. | Replace the whole block with direction-specific success events and deterministic projections. |
| Section 4.10.3, printed p. 32 | Trace composed security points to the old target. | Use `AuthCapSafe`; semantics is now over actual exercise events. |
| Section 4.11 introduction, printed p. 33 (physical p. 44) | Calls probability-bearing `Cap_tau` a trace abstraction. | Say sampled traces contain deterministic exercise events; games bound the probability of bad traces/events. |
| Sections 4.11.2-4.11.3, printed pp. 33-34 | Games refer to support-tagged use without specifying how the trace records it. | Make challenge recovery/accepted action append the corresponding deterministic event; rename advantages. |
| Section 5.4, printed p. 38 | Infers `{x_p} in Users_tau(o)` from retained key ability. | Include the explicit `recover(d_p,o,...)` event, then derive the set membership. |
| Definition 6.1, printed p. 42 | Says "actually used" but depends on the old model. | Replace with the event-based definition and `AuthCapSafe`. |
| Theorem 6.3 proof, printed p. 43 | Same inferred `Users` membership. | Cite the explicit recovery event. |
| Theorem 6.6 proof, printed pp. 45-46 | Starts from `UseSupp` plus probability-bearing `Cap_tau`; excluded case contradicts the assumed actual success. | Replace the entire theorem/proof with the structural theorem above. |
| Section 7.5, printed pp. 54-55 | Repeats the old live/excluded proof case split. | Replace with the cover proof; explain provenance/continuity/exclusion as mechanisms establishing sound cover and post-exclusion non-use. |
| Section 7.6, printed p. 55 | Bad-event prose says "usable/callable." | Use actual exercise events at trace level; reserve ability/advantage for experiments. |
| Appendix B.5-B.6, printed pp. 79-80 | Historical record endorses callable-proof/excluded-support case split as the final formal shape. | Mark it as superseded by the Phase 1 deterministic-event/cover repair; do not leave it as evidence that the old theorem was fully verified. |

### B. Exact support completeness versus sound cover

| Location | Present issue | Required edit |
|---|---|---|
| Section 3.1 frontier and support symbols, printed pp. 12-13 | Frontier `chi_h` is described as a support-family commitment without cover/exact distinction. | Introduce `widehat G` and `CoverCommitOK`; label exactness optional. |
| Section 4.4.2, printed p. 21 | `CompleteSupp_tau(chi_e^r,e,r)` requires exact live family and recomputation of every proof. | Rename/demote to `ExactLiveSupp`; add the safe live-support cover as the ordinary condition. |
| Section 4.4.2, printed pp. 21-22 | `TransitionOK` requires every successor commitment complete; `DispositionOK` uses exact live membership. | Use conservative cover carry-forward and actual-use disposition. |
| Section 4.5.1, printed pp. 24-25 | `F <=_F F'`, `ResolveOK`, and `FrontierOK` depend on `CompleteSupp`/exact merge knowledge. | Replace with `FrontierCoverOK`, conservative parent-cover carry-forward, and union cover at fork resolution. |
| Section 4.7.1, printed p. 28 (physical p. 39) | Defines `G_o` as the exact relevant projection; `CompleteSupp(chi_o,o)` makes omission or insertion false; witness authenticates the "complete family." | Replace with finite `widehat G_o`, `CoverCommitOK`, and separate `SoundCover`; extra unsupported entries are allowed and fail closed if unauthorized. |
| `VerifyWitness` and `Match`, Section 4.7.1 | Verification imports exact completeness. | Bind the exact cover operand seen by the guard, not global exactness. Freshness and authorization remain separate. |
| Section 4.13 item 8, printed p. 34 | Requires "the complete derivation hypergraph, support-family rule" with no cover trade-off. | Require a typed support-cover construction and soundness argument; list exactness only if claimed by the realization. |
| Section 6.3 pre-Theorem 6.6, printed pp. 44-45 | Guard authenticates and checks an exact complete family; bad-event list has no distinct cover-under-approximation event. | Use `widehat G_o`; add `B_cover`; split binding from cover soundness. |
| Theorem 6.6/proof, printed pp. 45-46 | Principal theorem relies on exact completeness in the live-support case. | Replace with `GoodTrace -> AuthCapSafe`. |
| Section 7.2, printed pp. 51-52 | `bind(o)` carries exact `G_o`, and prose calls it complete. | Bind the checked cover family and its commitment. |
| ACC-2, printed p. 52 | "complete context" also requires exact support alternatives. | Keep complete context binding, but say it binds every element of the submitted cover; cover soundness is a distinct condition. |
| ACC-4, printed p. 53 (physical p. 64) | Guard contains `CompleteSupp`. | Replace with `CoverCommitOK`; put `SoundCover` in `GoodTrace`, not the run-time algorithm. |
| ACC-5, printed p. 53 | Fork resolution accounts for every live alternative exactly. | Require a sound union cover; extras may persist and reduce availability. |
| Sections 7.4-7.6, printed pp. 54-55 | Prose treats completeness as exactly auditable and the theorem as a two-case completeness proof. | Explain the agreement cost, under-/over-approximation distinction, and new cover theorem/bad event. |
| Section 7.10.1, printed p. 57 | MLS checklist asks for "complete support mapping." | Ask for a sound, authenticated support cover; exact mapping is an optional optimization. |
| Appendix B.5, printed p. 79 (physical p. 90) | Verification record says exact `CompleteSupp` repaired the model. | Add a supersession note: exactness is no longer a principal theorem premise after Phase 1. |
| Appendix B.6.2, printed p. 80 | Final result summary says guard authorizes live support via complete support accounting. | State that the guard authorizes a sound cover and that over-approximation may block. |

The notebook should add, near Sections 4.7.1 and 6.3, the explicit prose:

> Computing the exact family of supports capable of an operation can itself require distributed agreement. The principal theorem therefore requires only an authenticated sound cover. An over-approximation may reject an otherwise safe operation and reduce availability; an under-approximation is a safety failure because it can omit an actually exercised unauthorized support.

### C. GoodTrace and bad-event separation

| Location | Required edit |
|---|---|
| Abstract and Status, physical PDF p. 2 | Describe the elementary cover/authorization theorem and its `GoodTrace -> AuthCapSafe` corollary. Say separately that a mechanism/realization lemma establishes all good-trace clauses and that mechanism failures probabilistically cover non-good traces. |
| Executive Conceptual Preview, physical p. 5 | Keep the hierarchy, but say the good-trace theorem is deterministic and the union bound is a separate concrete-refinement layer. |
| Sections 1.7 and 1.9, printed pp. 4-5 | Replace "ACC plus component security on traces where mechanisms do not fail" with the structural theorem; list mechanism coverage as a later corollary. |
| Section 2.8.2, printed p. 9 | State that `Sec_C^r` bounds violations of deterministic post-exclusion non-use in sampled executions; it is not a trace predicate. |
| Section 3.2, printed p. 13 | Make the three layers explicit and correct after removing probability from `Cap_tau`. |
| Section 6.1, printed p. 42 | Announce the elementary two-inclusion core, its `GoodTrace` projection corollary, and the separate realization bridge. |
| Section 6.3, printed pp. 44-46 | Replace Theorem 6.6 and its proof. State explicitly which two inclusions the elementary proof uses; move the conjunct-by-conjunct mechanism lemma and `B` assumptions after it. |
| Remark 6.7, printed p. 46 | Retain the non-tautology point, but focus on cover soundness versus authorization of the cover; do not defend the obsolete excluded-support case split. |
| Corollaries 6.8-6.9, printed p. 46 | Restate using the two inclusions `unsafe subseteq not GoodTrace subseteq union B`; include the middle probability term. |
| Corollary 6.12, printed p. 46 | Replace "good trace satisfying ACC" with `GoodTrace_sigma(tau)` and the deterministic non-use statement. |
| Sections 7.1, 7.4-7.6, printed pp. 51, 54-55 | Present ACC clauses as mechanisms that establish good-trace conjuncts, then give the short structural proof and only afterward bad-event coverage. |
| Section 7.11, printed p. 58 | Change claim 2 to the pure structural theorem plus a separate conditional bad-event refinement. |
| Appendix B.2, p. 77; B.5-B.7, pp. 79-80 | Historical statements saying trace/probability were already fully split are no longer accurate. Mark the old shape as superseded and summarize the final Phase 1 separation. |

### D. Complete `ACCSafe` rename inventory

Every occurrence below must become `AuthCapSafe` (with the same arguments/subscripts), and nearby prose must call it authorization-capability safety rather than ACC safety:

- Section 3.1 symbol table and Section 3.2 safety/liveness paragraph, printed p. 13.
- Section 4.7 compatibility definition, printed p. 27.
- Section 4.10.1 safety items and Section 4.10.3 trace-composition definition, printed p. 32.
- Section 5.4 counterexample conclusion, printed p. 38.
- Definition 6.1, Theorem 6.3 statement/proof, printed pp. 42-43.
- Theorem 6.6 statement/proof, Corollary 6.9, Proposition 6.11, printed pp. 45-46.
- Theorem 6.13 statement/proof, Corollary 6.14 event `U`, printed pp. 47-48.
- Sections 7.6 and 7.7, printed pp. 55-56.

Also rename `Adv^{ACConf}` and `Adv^{ACInt}` in Sections 4.10.3 and 4.11.2-4.11.3 to `Adv^{AuthCapConf}` and `Adv^{AuthCapInt}`. `Compat_sigma`, `SecComp`, and `ACC_sigma` can retain their names: `Compat` is neutral, `SecComp` is the composed-security wrapper, and `ACC` is the sufficient interface.

### E. Effective-authorization and group-focused wording

The following prose edits are required:

| Location | Replacement direction |
|---|---|
| Abstract, physical p. 2, opening and contribution framing | Lead with external authorization and retained capability in dynamic secure groups. Qualify “keys, authenticators, tokens, or other state” as abstraction breadth/future applicability, not evidence for a universal first-paper claim; describe the positive result as group-focused and instantiated for MLS/CGKA. |
| Abstract, physical p. 2 | Replace "the combined system may authorize an operation that policy now forbids" with "an honest boundary may expose a confidentiality artifact or accept an integrity-relevant group operation that the authorization policy, effective under the selected revocation semantics, forbids." |
| Abstract, physical p. 2 | Replace "current authorization" with "authorization effective for the operation under the selected revocation semantics." |
| Executive preview, physical p. 4 | Replace "current state says Alice is denied" with "the denial is effective for this operation under the selected semantics." |
| Section 1.1, printed p. 2 | Replace "Who is permitted ... now?" with "Who is permitted for this operation under the selected revocation semantics?" |
| Section 1.8, printed p. 5 | Narrow the positive-contribution paragraph to a protocol-independent composition abstraction developed for dynamic secure groups, with MLS/CGKA as the first realization target. Do not present arbitrary retained-capability composition as demonstrated scope. |
| Section 1.9, printed p. 5 | Replace “best protocol-independent interface” with “candidate protocol-independent interface for dynamic secure groups”; retain broader applicability as open future work. |
| Section 2.4, printed p. 7 | Replace "CGKA/MLS is the principal modern sanity check, but the definitions do not depend on MLS" with "The first publication develops a protocol-independent composition abstraction for dynamic secure groups and instantiates it for MLS/CGKA. The abstract types may later support other retained cryptographic capabilities, but those are outside the first paper's evidentiary claim." |
| Section 2.6 challenge exclusion, printed p. 8 | Replace "currently authorized corrupt member" with "a corrupt member whose support is authorized at the operation's effective cut." |
| Section 2.8.4, printed p. 9 | Replace "general formulation" with "group-focused composition abstraction." |
| Section 4.2 reauthorization prose, printed p. 17 | Replace "currently authorized" with "authorized at the applicable operation cut." |
| Section 4.6 challenge exclusions, printed p. 26 | Use "support authorized at the effective cut," not "currently authorized." |
| Section 4.7 opening, printed p. 27 | Replace the quoted "current authorization state" sentence with "An authorization revision is not effective for an operation until `sigma` selects its cut." |
| Sections 4.11.2-4.11.3, printed pp. 33-34 | Define insider/delegation exclusions relative to `Allowed_sigma(tau,o*)` at the effective cut. |
| Section 5.5.1, printed p. 39 | Replace "The current authorization answer for p is deny" with "The exact support containing `x_p` is denied at `cut_sigma0(tau,o)`." |
| Section 5.10, printed p. 41 | Replace "the general contract and theorem" with "the group-focused composition contract and theorem." |
| Sections 4.1 and 6.1, printed pp. 16 and 42 | Qualify “protocol-independent model” and “principal positive contribution” as protocol-independent across dynamic secure-group protocols, not across every authorization/cryptographic-capability pairing. |
| Section 7.10.2, printed p. 57 | Rename to "Out-of-scope analogy: encrypted object access" and state that it is intuition/future work, not an instantiation or evidence of universal applicability. Omit it from the first paper's contribution argument. |
| Section 7.11 claim 4, printed p. 58 | Replace "useful general formulation" with "useful group-focused composition abstraction for dynamic secure groups." |
| Section 8.2, printed p. 60 | Frame the assessed positive contribution as a protocol-independent abstraction developed for dynamic secure groups/MLS/CGKA, not arbitrary authorization/cryptographic compositions. |
| Section 8.9.2, printed p. 68 | Qualify the package-derived sufficiency claim as a dynamic-secure-group abstraction; do not let “abstract model” imply demonstrated universality. |
| Section 8.9.3, printed p. 68 | Replace "no materially equivalent general theorem" with the narrower "no materially equivalent group-focused authorization/capability-cut theorem in the reviewed corpus." |
| Appendix B.3 item 19, printed p. 78 | Define authorized insider leakage at the effective cut. |
| Appendix B.6-B.7, printed p. 80 | Use `AuthCapSafe`, structural-good-trace wording, sound cover, and the group-focused publication scope. |

The generic examples of keys, authenticators, and retained state can remain in the abstract model only if immediately qualified as abstraction breadth, not demonstrated first-paper generality. Apply the same qualification to every broad contribution phrase found by a final search for “general,” “generic,” “protocol-independent,” “arbitrary,” and “other state”; prior-art descriptions and explicit non-claims are not narrowed mechanically. The title is already group-focused and needs no change.

## Proof and typing checks after repair

The repaired theorem should be checked against these cases:

1. **Unprovenanced success:** a `recover` event with bottom support makes `AuthCapSafe` false and `GoodTrace` false; it cannot disappear from `Users`.
2. **Safe over-approximation:** `Users={S_1}`, `widehat G={S_1,S_2}`, both authorized. The operation may proceed and is safe.
3. **Availability loss:** `Users={S_1}`, `widehat G={S_1,S_2}`, but `S_2` is unauthorized and impossible. The guard rejects; safety holds and availability decreases.
4. **Unsafe under-approximation:** `Users={S_1,S_2}`, `widehat G={S_1}`. `B_cover` occurs, so the trace is not good.
5. **Joint support:** `{x_1,x_2}` remains one element of the cover; it is not replaced by singleton supports.
6. **Alternative support:** `{x_1}` and `{x_2}` remain distinct cover elements; denying `x_1` does not invalidate the separately authorized `{x_2}` path.
7. **Retained excluded proof:** after qualifying exclusion of `x`, an actual exercise through `S` containing `x` is a deterministic `PostExcludeOK` failure and a sampled `B_exclude` event.
8. **Allow-revoke-allow:** the old exercise support contains the old incarnation/generation and remains unauthorized at the later cut; a fresh support is checked independently.
9. **Fork merge:** the resolved cover includes the conservative union of unexcluded parent covers. Dropping an uncertain parent support is not allowed merely because the resolver lacks knowledge of its feasibility.
10. **Lease semantics:** a denial committed after lease issue but before lease expiry is not called "current" or automatically effective; authorization is evaluated at `cut_sigmaL`.
11. **Fail closed:** no exercise/exposure event yields `AuthCapSafe` vacuously, but no liveness or exclusion conclusion follows.
12. **Probability-space consistency:** `not AuthCapSafe`, `not GoodTrace`, and every `B_j` are events on the same sampled trace distribution before applying the union bound.
13. **Repeated occurrence/prefix:** two identical-looking success labels at different positions remain distinct occurrences; a proof valid only by the second occurrence cannot validate the first.
14. **No provenance relabeling:** an exercise without the exact operational witness normalizes to `bottom_r` even if an unrelated valid and authorized proof exists.
15. **Guard/frontier extraction:** the checked operation cover is exactly the prefix-local extraction from the frontier named by its guard record; a different or later frontier cannot justify it.
16. **Missing qualifying exclusion:** a later exposure on a lineage carrying an effectively denied source, without a qualifying exclusion, triggers `B_resume` even when no post-exclusion exercise occurs.

## Major residual concerns

1. A support cover over actual successful uses is a semantic condition, not by itself a construction. The MLS/CGKA realization must show how authenticated metadata conservatively covers all exercise paths without requiring impossible global omniscience.
2. The bottom support tag, or an equivalent total provenance-failure representation, is needed to stop rootless cryptographic success from making `Users` incomplete.
3. Right-specific post-exclusion non-use must be stated twice at different levels: deterministically as absence of a successful exercise event on a good trace, and probabilistically as a concrete `Sec_C^r`/message-protection bound. These must not be conflated.
4. Exact `CompleteSupp` cannot remain indirectly mandatory through `TransitionOK`, `FrontierOK`, or `ResolveOK`; otherwise the main safety result still hides agreement despite changing the operation guard.
5. The current Appendix B says several now-rejected proof shapes were fully verified. It should be retained only as research history with an explicit Phase 1 supersession note, and excluded from the paper as already planned.
6. The abstract theorem remains a sufficient structural interface result. Publication strength still depends on a non-vacuous MLS/CGKA realization and a separate conditional progress theorem.

## Final integration typing correction

Here `Grant` is the disjoint union of `Grant_q` over source rights q. The support index r denotes the protected effect. A joint admit support contains the authorizer-admin and candidate-admit grants, evaluated at their own source rights and generations. `Auth_v^r` enforces the effect policy and group context. This repairs the original homogeneous-support restriction without adding an endorsement mechanism; the set-inclusion proof is unchanged.

## Final bad-event integration correction

The final reviewed notebook and article bind `B_resume` and `B_exclude` to the exact exposure and successful `GuardRef`, use denial of the exact source `Denied_v(x)` (not failure of the whole joint support), and require the challenged operation to lie in the qualifying successor lineage. Earlier formulas in this design report are superseded where they omit those conditions. The frozen Third Edition is the authoritative statement.
