# Mechanization artifact report

## Accepted executable result

An independent run of `python3 output/artifact/check_acc_model.py --json`
completed with **states=5712, transitions=6098, depth=3,
invariant_violations=0**. `python3 output/artifact/test_acc_model.py` completed
with **15 passing tests**. All four rights have an explicit successful
consumption scenario, the repair-progress scenario reaches one successful
read occurrence, and all **12** deliberately mutated transition scenarios
produce named invariant violations. The exact record is saved in
`output/artifact/checker-result.json` and the checker/GREEN transcripts.

These counts supersede the earlier 2,810-state/4,115-transition, four-test,
five-mutant result. The earlier result was rejected during independent
review and must not appear as the final package's evidence.

## Model and scope

The Python artifact has three principals, one group, four rights, five
operation IDs, at most three policy revisions, generation and epoch bounds
of two, and at most six release/spent records and successful occurrences.
It separates allocation, one-shot authorization/release, exact-envelope
exposure, and per-recipient consumption. Authorization/release is the
operation cut. An immutable reservation binds the operation/certificate IDs,
direction, actor/target, content/context commitments, authorization snapshot,
cover, roster, revision, branch, and epoch.

Read supports are recipient read grants; write/admin supports are actor
grants; the joint admit support is actor admin plus target admit. The
observed support is derived independently of the claimed cover. Successful
effects have unique occurrence-indexed witnesses; the unattributed mutation
records bottom and fails authorization. Durable server/local frontiers bind
exclusions, generations, and append-only release/spent roots. Recovery
requires the current authoritative frontier and rejects stale/incomparable
candidates. Reauthorization refreshes generation/key/credential versions.
Read fencing is right-specific. Canonicalization checks the public candidate
and parent; client-valid processing and local persistence are separate.

The breadth-first search exhausts the generated transition relation only
through depth three. At this depth it reaches exposure, not consumption or
post-canonical local persistence. Those are covered by four length-four
positive scenarios and a length-eight repair-progress scenario, plus focused
acceptance scenarios. This is explicit scenario coverage, not exhaustive
coverage of longer interleavings.

## Review corrections and controls

The redesign repaired the wrong admit pair, missing synchronized release
frontier, absent release/spent roots, and missing exact-envelope state.
Independent final inspection then reproduced three additional defects:

1. Exposure and consumption invariants rejected every non-read operation
   while read-fenced, despite the intended right-specific fence.
2. Python canonicalization did not enforce its advertised epoch cap.
3. Admit effect support was copied from the claimed cover, making an omitted
   support disappear rather than independently challengeable.

`RED3-transcript.txt` preserves three focused failures; their fixes pass in
the final run. The TLA cfg also referenced deleted invariant/constant names.
It now supplies all current constants, function-valued operator overrides,
and existing invariant names, with a static consistency test. The companion
has a locally defined sequence-to-set operator, clearer bounded type checks,
frontier-history guards, and the same right-specific exposure fence and
independently derived admit support.

The twelve reachable faulty scenarios are omitted cover, unattributed
success, envelope mutation, duplicate release, duplicate consumption,
spent-root rollback, stale release revision, stale reauthorization material,
missing parent CAS, missing client validity, missing frontier readiness,
and missing read fence. They use faulty transitions from reachable prefixes;
they are not hand-forged bad initial states. They are deliberately
constructed traces, not exhaustive mutant-search results.

## TLA and remaining obligations

**No SANY or TLC run was performed.** The TLA+/cfg files are an unparsed,
unexecuted audit companion. Static inspection and name-consistency checks do
not certify parser acceptance or a refinement relation to Python. The TLA
transition relation includes all recipients and both client-validity choices;
Python BFS fixes recipient A and valid repair candidates, with explicit
negative tests covering omitted choices. Do not equate their state spaces.

The artifact does not model full MLS transcripts, KeyPackage/Welcome/Add
processing, real keys, per-device incarnations, arbitrary branch competition,
authority implementation, or actual rollback-resistant storage. It models an
admit authorization effect, not a complete MLS Add. No claim is made that
all fifteen design-report invariants are mechanized or that full lineage
support propagation, general safety/liveness, cryptographic post-exclusion
secrecy, or the MLS/ETK bridge lemma is proved. Cryptography remains abstract.

The single repair execution is a scenario witness under a stable policy
suffix, continuing authorized committer, valid processing, reachability,
fair scheduling/delivery, no permanent fork, and durable storage. It is not
a temporal-model-checker liveness proof. These limitations are repeated in
the artifact README so the package cannot imply a stronger outcome.
