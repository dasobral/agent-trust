# Prior-art audit — Authorization–Capability Coherence (Phase 2)

## Bottom line

The defensible contribution is a **group/MLS/CGKA-focused composition abstraction and structural trace theorem**. It states conditions connecting an independently evolving authorization decision, retained cryptographic capability, group state, and an operation so that the system does not expose or accept an operation forbidden under a selected revocation semantics. It is not a claim to invent revocation, rekeying, mediated capabilities, causal group communication, CGKA/MLS security, or generic cryptographic composition.

Two limits are decisive.

1. Boneh--Ding--Tsudik--Wong already give online-mediator, operation-specific decryption/signing tokens and immediate revocation even while a user retains a key share. A claim that use-boundary revocation through external authorization is new is untenable.
2. MLS work already gives modular component composition, authenticated group-state consistency, and a formal ideal functionality for RFC 9420 external operations. A generic MLS composition claim is untenable.

No source reviewed here states the proposed `AuthCapSafe` property with all of: (i) independently evolving external authorization, (ii) an explicit commit-immediate/causal/deadline/lease effectiveness cut, (iii) a sound *over-approximate* cover of live operation supports, (iv) provenance/continuity from that cut to use, and (v) an operation-level structural theorem. This is a **scope-qualified gap**, not an absolute novelty certification. It remains credible only after a concrete MLS/CGKA realization maps every term to protocol and authorization state.

## Method and classification

Only original papers, official proceedings/repositories, and the IETF standard support technical assertions below. Classifications are relative to the notebook's surviving claim.

| Classification | Meaning |
|---|---|
| **Kills a claim** | A broader claim should not appear; the source already supplies its substance. |
| **Narrows a claim** | The source covers an important subset or imposes a material scope/precondition. |
| **Mechanism precedent** | Reusable construction/semantic machinery; cite it rather than present it as new. |
| **Proof technique** | A model, game, ideal functionality, or modular proof pattern limiting methodological novelty. |

## Claim boundary

| Candidate assertion | Result | Claim-safe replacement |
|---|---|---|
| “We introduce revocation at the cryptographic-use boundary.” | **Killed** by security-mediated RSA. | “We model a use boundary for a dynamic group realization; mediator-based immediate revocation is prior art.” |
| “We introduce retained-state/key-exposure-aware revocation.” | **Killed/narrowed** by key regression, revocable IBE/ABE, and CGKA/MLS FS/PCS. | “We account for retained state while connecting an authorization cut to a group operation.” |
| “We introduce dynamic cryptographic access control or revocation of old cloud data.” | **Killed** as a broad assertion by Sahai--Seyalioglu--Waters and Garrison et al. | “This is not a new access-control cryptosystem; it gives a group-focused interface theorem.” |
| “We introduce causal membership/delivery for secure dynamic groups.” | **Killed/narrowed** by virtual synchrony/causal multicast, with Causal TreeKEM as a design precedent and DCGKA as the proven secure-group comparator. | “Causal effectiveness is one selectable revocation semantics layered on prior group mechanisms.” |
| “We give the first generic cryptographic composition proof for MLS.” | **Killed** by Alwen et al.'s modular SGM/MLS proof. | “The theorem is a different cross-layer contract including external policy, support coverage, provenance, and operation acceptance.” |
| “MLS itself maintains authorization--key coherence.” | **Unsupported.** MLS architecture leaves important authentication/infrastructure choices to the application; ETK shows external operations change the analysis. | “The realization adds and proves an application/authorization binding; MLS/CGKA alone is not claimed to establish it.” |

## Source table

| Source | Direct primary URL / DOI | Relevant result | Classification and consequence |
|---|---|---|---|
| K. Birman and T. Joseph, *Reliable Communication in the Presence of Failures*, TOCS 1987; *Exploiting Virtual Synchrony in Distributed Systems*, SOSP 1987 | [TOCS DOI](https://doi.org/10.1145/7351.7478); [SOSP DOI](https://doi.org/10.1145/37499.37515) | Reliable process-group communication with consistent observation of group-affecting events; virtual synchrony makes broadcasts and membership changes appear synchronous to a group view. | **Mechanism precedent / narrows.** Membership views and view changes are established abstractions; they neither authenticate external policy nor stop a holder of a usable crypto secret. |
| K. Birman, A. Schiper, and P. Stephenson, *Lightweight Causal and Atomic Group Multicast*, TOCS 1991 | [DOI](https://doi.org/10.1145/128738.128742) | Causal and atomic multicast for fault-tolerant process groups. | **Mechanism precedent / proof technique.** Causal ordering/view-sensitive delivery are not novel. A causal `cut_sigma` must be an application interpretation of prior ordering, not a new causal-delivery primitive. |
| K. Fu, S. Kamara, and Y. Kohno, *Key Regression: Enabling Efficient Key Distribution for Secure Distributed Storage*, NDSS 2006 | [Official NDSS record and PDF](https://www.ndss-symposium.org/ndss2006/key-regression-enabling-efficient-key-distribution-secure-distributed-storage/) | Key evolution for efficient temporal storage-key distribution, separating derivability in the two time directions. | **Mechanism precedent / narrows.** Key evolution and retained-key exposure are not new; it does not decide authorization at use, represent multi-party supports, or bind an independent policy service to a group operation. |
| A. Boldyreva, V. Goyal, and V. Kumar, *Identity-Based Encryption with Efficient Revocation*, CCS 2008 | [DOI](https://doi.org/10.1145/1455770.1455823) | Tree-based revocation reduces authority update work while receivers obtain time/update material. | **Mechanism precedent / narrows.** Efficient revocation and time-indexed key updates are prior art. **Bibliographic correction:** this source is revocable **IBE**, not ABE; do not cite it as a CP-/KP-ABE construction. |
| A. Sahai, H. Seyalioglu, and B. Waters, *Dynamic Credentials and Ciphertext Delegation for Attribute-Based Encryption*, CRYPTO 2012 | [Springer DOI](https://doi.org/10.1007/978-3-642-32009-5_13); [IACR record](https://eprint.iacr.org/2012/437) | Defines revocable storage: an untrusted third party transforms old ciphertexts using public information to disqualify revoked users; also gives revocable ABE. | **Mechanism precedent / narrows.** Revocation of access to previously encrypted storage and policy-restricting ciphertext delegation are established. It does not prove operation-level coherence with an independent authorization service for a dynamic MLS group. “Revocable-storage ABE” is the contribution/term, not the CRYPTO title. |
| W. C. Garrison III, A. Shull, S. Myers, and A. J. Lee, *On the Practicality of Cryptographically Enforcing Dynamic Access Control Policies in the Cloud*, IEEE S&P 2016 | [IEEE DOI](https://doi.org/10.1109/SP.2016.54); [authors' extended version](https://arxiv.org/abs/1602.09069) | Constructs cryptographic RBAC0 enforcement over cloud files and evaluates dynamic revocation/file-update costs, finding severe costs on dynamic workloads. | **Mechanism precedent / narrows.** Dynamic cryptographic access control and its costs are not new. **Our inference:** these documented state-change costs reinforce the need to model, rather than assume away, the cost/availability implications of maintaining an exact support cover. |
| D. Boneh, X. Ding, G. Tsudik, and C. M. Wong, *A Method for Fast Revocation of Public Key Certificates and Security Capabilities*, USENIX Security 2001 | [Official USENIX record and paper](https://www.usenix.org/conference/10th-usenix-security-symposium/method-fast-revocation-public-key-certificates-and) | Security-mediated RSA makes each signature/decryption depend on a message-specific token from an online semi-trusted mediator; withholding future tokens immediately revokes use. | **Kills a broad claim.** Do not claim novelty for external authorization plus a retained cryptographic share, immediate revocation, or per-operation mediation. The remaining distinction must be external policy plus group/MLS supports/cuts and a cross-system theorem. |
| K. Bhargavan, R. Barnes, and E. Rescorla, *TreeKEM: Asynchronous Decentralized Key Management for Large Dynamic Groups*, 2018 | [Official IETF archive PDF](https://mailarchive.ietf.org/arch/msg/mls/v1CY0jFAOVOHokB4DtNqS__tX1o/4/); [HAL record](https://inria.hal.science/hal-02425247) | MLS key-management proposal supporting asynchronous adds/removes/key updates. | **Mechanism precedent / narrows.** A realization cannot claim TreeKEM rekeying, FS/PCS, or dynamic membership as new. Its ordered state evolution makes the chosen effectiveness semantics material. |
| J. Alwen, S. Coretti, D. Jost, and M. Mularczyk, *Continuous Group Key Agreement with Active Security*, TCC 2020 | [Springer DOI](https://doi.org/10.1007/978-3-030-64378-2_10); [IACR record](https://eprint.iacr.org/2020/752) | Formalizes CGKA with changing membership, asynchronous availability, FS/PCS, exposed states, and active adversaries; gives composable notions/constructions. | **Proof technique / narrows.** Snapshot/non-erasable adversarial state and evolving group keys already have formal treatment. Do not advertise the structural theorem as the first composable dynamic-group-key security treatment. |
| M. Weidner, M. Kleppmann, D. Hugenroth, and A. R. Beresford, *Key Agreement for Decentralized Secure Group Messaging with Strong Security Guarantees*, CCS 2021 | [ACM DOI](https://doi.org/10.1145/3460120.3484542); [authors' PDF](https://www.cl.cam.ac.uk/~arb33/papers/WeidnerEtAl-DecentralisedGroupKeyAgreement-CCS2021.pdf) | Defines DCGKA and gives decentralized asynchronous secure messaging with FS/PCS and concurrent membership/key updates; members converge after receiving the same control messages. | **Kills/narrows.** Do not claim decentralized dynamic-group key agreement, concurrent/causal membership handling, or full-state-compromise security as novel. It does not impose independent external authorization at an operation cut. |
| M. Weidner, *Group Messaging for Secure Asynchronous Collaboration*, 2019 dissertation (Causal TreeKEM) | [Primary dissertation PDF](https://mattweidner.com/assets/pdf/acs-dissertation.pdf) | Design for dynamic group key management without a total order on state changes, with a causal-delivery messaging design. The dissertation itself says its Causal TreeKEM security proofs are incomplete. | **Mechanism/design precedent only.** It rules out presenting the causal TreeKEM design as new, but should not be used as the proven security comparator. Use the DCGKA CCS 2021 result above for the latter. |
| J. Alwen, S. Coretti, Y. Dodis, and Y. Tselekounis, *Modular Design of Secure Group Messaging Protocols and the Security of MLS*, CCS 2021 | [ACM DOI](https://doi.org/10.1145/3460120.3484820); [IACR record](https://eprint.iacr.org/2021/1083) | Defines an SGM game parameterized by a safety predicate and builds MLS modularly from CGKA, FS-GAEAD, and PRF-PRNG; component predicates yield the SGM result. | **Kills a generic composition/proof-novelty claim.** ACC must be sold only as a different cross-layer sufficient contract—not as the first modular compositional security proof. This is the closest proof-design precedent. |
| T. Wallez, J. Protzenko, B. Beurdouche, and K. Bhargavan, *TreeSync: Authenticated Group Management for Messaging Layer Security*, USENIX Security 2023 | [Official USENIX record and paper](https://www.usenix.org/conference/usenixsecurity23/presentation/wallez) | Machine-checked specification and symbolic proof for **MLS group-state** consistency, integrity, and authentication; identifies and repairs a group-management attack. | **Proof technique / narrows.** This is a precise mechanized result for authenticated MLS group management. It does not establish cross-system authorization provenance or continuity; those remain additional obligations for the proposed interface. |
| R. Barnes et al., *The Messaging Layer Security (MLS) Protocol*, RFC 9420 (2023); C. Cremers, E. Günsay, V. Wesselkamp, and M. Zhao, *ETK: External-Operations TreeKEM and the Security of MLS in RFC 9420*, ePrint 2025/229, revised/published EUROCRYPT 2026 | [RFC 9420](https://doi.org/10.17487/RFC9420); [ETK IACR record](https://eprint.iacr.org/2025/229) | RFC 9420 includes external commits/proposals. ETK formalizes them, defines ideal `F_ECGKA`, proves consistency/confidentiality/authentication, and shows weaker PCS when external operations are allowed. The current ePrint record reports a 2026 revision and EUROCRYPT 2026 publication status. | **Proof technique / major narrowing.** A realization using external proposals/commits must state whether it adopts ETK's model and precisely what authorization evidence it carries/validates. Do not claim the first formal external-operation analysis or unqualified PCS. |

## Targeted-topic synthesis

### External authorization and retained capability

Mediated RSA is the direct antecedent: a party retains a private-operation share but cannot decrypt or sign without the mediator's message-specific response. It establishes immediate revocation at a use boundary. It does not decide membership against a separately evolving authorization policy, cover multi-device/group supports, or provide causal group-state delivery. That is the only credible delta.

MLS architecture likewise separates authentication, delivery, and MLS group state. This supports the motivation, not a policy-coherence theorem: application choices determine the binding. The paper should present an interface for composing these layers, not the observation that the layers differ.

### Authorization cuts and revocation semantics

The literature makes time/state boundaries central: key regression evolves keys; revocable IBE and RS-ABE use update/time material; TreeKEM/CGKA evolve epochs; virtual synchrony and causal multicast delineate membership/delivery views. These are precedents for a cut.

The only safe contribution is to parameterize **which** named operation cut an external authorization predicate must hold at, and to require provenance/continuity between that cut and a later use. Do not call cuts, delayed effectiveness, or leases novel. Lease/deadline variants must state clock, expiry, refresh, and acceptance assumptions; none may silently assume global time.

### Policy/key consistency, provenance, and non-erasable state

RS-ABE and Garrison et al. establish that policy/key evolution and cryptographic enforcement are longstanding problems. TreeSync establishes machine-checked MLS group-state consistency/integrity/authentication, while ETK models MLS external operations. CGKA/DCGKA establishes an explicit compromise model in which the adversary learns endpoint state; FS/PCS, not magical erasure, delimit the result.

Define `provenance` operationally: a verified chain from the accepted operation to signed MLS state and to authorization/support evidence. Define retained adversarial state explicitly. Never imply that revocation removes learned plaintext, a message key, a ciphertext key, or an unmediated signing ability.

### Causal group delivery

Virtual synchrony and causal multicast are established delivery/state-evolution precedents. Causal TreeKEM is a further design precedent, but its 2019 dissertation records incomplete security proofs; DCGKA is the proved secure-group comparator. None makes causality mean “authorization now holds.” In a causal realization, `cut_sigma` must be a named event (for example, authenticated processing of a qualifying exclusion/commit); quantify only over operations whose evidence is causally downstream. Liveness remains outside the safety theorem.

## Claim-safe related-work language

> Dynamic cryptographic access control, key evolution, and revocation are established areas. Key regression and revocable IBE/ABE provide temporal and revocation mechanisms, while revocable-storage ABE can update protected cloud ciphertexts to exclude revoked users. Cryptographic RBAC studies also document the cost of policy and key evolution. Our contribution is not a new revocation primitive or a claim that past knowledge can be erased.

> Secure group communication has long supplied membership views and causal delivery; MLS/TreeKEM and CGKA/DCGKA supply dynamic group-key evolution with forward secrecy and post-compromise security. Existing MLS analyses give modular security proofs, authenticated group-management specifications, and analyses of external operations. These results do not by themselves state when an independently maintained authorization policy becomes effective for a later group operation, or require application validation of a sound cover of every live operation support at that cut.

> We present Authorization--Capability Coherence as a sufficient cross-layer interface, instantiated for dynamic secure groups. For a chosen revocation semantics, it requires mediation at the operation boundary, authentic context, sound support coverage, valid provenance, and continuity to the effective authorization cut. Under these conditions, the structural trace theorem says the system does not expose or accept an operation forbidden under the selected semantics. The interface is not necessary, canonical, or a replacement for MLS/CGKA cryptographic proofs or an application-specific progress argument.

## Required revisions before freezing the novelty boundary

1. Correct the bibliography: Boldyreva--Goyal--Kumar is revocable **IBE**, not ABE; cite Sahai--Seyalioglu--Waters by its actual CRYPTO title.
2. Add mediated cryptography. It is the closest direct antecedent for external authorization at the cryptographic-use boundary; disclaim priority for that mechanism.
3. Add an MLS external-operations paragraph citing RFC 9420 and ETK (ePrint 2025/229, revised/published EUROCRYPT 2026). If the realization uses external proposals/commits, state the operation, evidence, corruption model, and PCS limitation inherited or avoided.
4. Cite group-communication and CGKA lines separately: virtual synchrony/causal multicast are delivery/view ancestors; Causal TreeKEM is a mechanism/design antecedent with incomplete dissertation proofs, while DCGKA is the proven secure-group comparator.
5. Keep the sound over-approximate support-cover repair. **Our inference, not a Garrison theorem,** is that exact support knowledge has a coordination/availability cost; state that premise in the model and prove only the resulting scoped trade-off.
6. Freeze novelty only after a concrete mapping from every `GoodTrace` operand to MLS/CGKA and authorization artifacts. Until then, call it a proposed sufficient interface with a structural theorem.

## Residual search risk

This targeted audit supports the wording above, not an absolute novelty certification. Before submission, rerun a narrow primary-source search using the exact realization's authorization artifact, `cut_sigma`, group protocol, and corruption model. Highest-risk adjacent work: mediated/threshold cryptography with policy tokens; MLS external-commit/authorization extensions; verified group-management protocols; and dynamic RBAC/ABAC with leases.

## Round-1 fix note — primary-source checks

- **ETK:** the IACR record is ePrint 2025/229; its current record reports a 2026 revision and describes it as a major revision of an IACR publication in **EUROCRYPT 2026**. The citation now reflects that status.
- **Causal TreeKEM:** the 2019 primary dissertation explicitly says its Causal TreeKEM security proofs are incomplete because there were then no published proofs for ordinary TreeKEM. The report now uses it only as a mechanism/design precedent and cites CCS 2021 DCGKA as the proved comparator.
- **TreeSync:** the USENIX paper states a machine-checked specification/proof of MLS **group-state** consistency, integrity, and authentication. Cross-system authorization provenance/continuity language has been removed.
- **Garrison et al.:** the primary extended paper supports dynamic RBAC cryptographic enforcement and costly revocation/file-update state changes. The exact-support-cover/global-coordination conclusion is now expressly marked as our inference, not attributed to the paper.
