#!/usr/bin/env python3
"""Acceptance tests for the bounded ACC/LAP-MLS structural model."""
from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import check_acc_model as model  # noqa: E402


class BoundedACCModelAcceptance(unittest.TestCase):
    def require_api(self, name: str):
        value = getattr(model, name, None)
        self.assertTrue(callable(value), f"missing required model API: {name}")
        return value

    def released(self, opid: str = "write-1"):
        allocate = self.require_api("allocate")
        authorize_release = self.require_api("authorize_release")
        state = allocate(model.initial_state(), opid)
        self.assertIsNotNone(state)
        state = authorize_release(state, opid)
        self.assertIsNotNone(state)
        return state

    def test_checker_finishes_with_machine_readable_zero_violation_report(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(HERE / "check_acc_model.py"), "--json"],
            cwd=HERE.parent.parent,
            capture_output=True,
            text=True,
            timeout=15,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        report = json.loads(completed.stdout.splitlines()[-1])
        self.assertEqual(report["invariant_violations"], 0)
        self.assertGreater(report["states"], 0)
        self.assertGreater(report["transitions"], 0)

    def test_admit_joint_cover_and_denied_candidate(self) -> None:
        state = model.initial_state()
        self.assertEqual(
            model.cover_for(state, "admit-1"),
            frozenset({model.support(state, "A", "admin"), model.support(state, "B", "admit")}),
        )
        allocate = self.require_api("allocate")
        authorize_release = self.require_api("authorize_release")
        state = model.revoke(state, "B", "admit")
        self.assertIsNotNone(state)
        state = allocate(state, "admit-1")
        self.assertIsNotNone(state)
        self.assertIsNone(authorize_release(state, "admit-1"))

    def test_release_requires_persisted_matching_frontier(self) -> None:
        build_repair = self.require_api("build_repair")
        canonicalize = self.require_api("canonicalize")
        process_and_persist = self.require_api("process_and_persist")
        allocate = self.require_api("allocate")
        authorize_release = self.require_api("authorize_release")
        is_ready = self.require_api("is_ready")
        state = model.revoke(model.initial_state(), "B", "read")
        state = build_repair(state, "B", client_valid=True)
        state = canonicalize(state)
        self.assertFalse(is_ready(state))
        state = allocate(state, "read-1")
        self.assertIsNone(authorize_release(state, "read-1"))
        state = process_and_persist(state)
        self.assertTrue(is_ready(state))
        self.assertIsNotNone(authorize_release(state, "read-1"))

    def test_release_binds_op_cert_direction_content_context_and_exact_envelope(self) -> None:
        reservation_for = self.require_api("reservation_for")
        state = self.released("write-1")
        reservation = reservation_for(state, "write-1")
        for field in ("opid", "certid", "direction", "payload", "kappa", "mu", "envelope"):
            self.assertTrue(getattr(reservation, field), field)
        self.assertIsNone(model.expose(state, "write-1", reservation.envelope + "-changed"))
        self.assertIsNotNone(model.expose(state, "write-1", reservation.envelope))

    def test_release_and_per_recipient_consumption_are_one_shot(self) -> None:
        reservation_for = self.require_api("reservation_for")
        consume = self.require_api("consume")
        state = self.released("write-1")
        reservation = reservation_for(state, "write-1")
        self.assertIsNone(self.require_api("authorize_release")(state, "write-1"))
        state = model.expose(state, "write-1", reservation.envelope)
        self.assertIsNotNone(state)
        state = consume(state, "write-1", "A", reservation.envelope)
        self.assertIsNotNone(state)
        self.assertIsNone(consume(state, "write-1", "A", reservation.envelope))
        self.assertEqual(len(state.server_frontier.release_root), 1)
        self.assertEqual(len(state.server_frontier.spent_root), 1)

    def test_successful_effect_has_unique_total_witness(self) -> None:
        consume = self.require_api("consume")
        reservation_for = self.require_api("reservation_for")
        state = self.released("admin-1")
        reservation = reservation_for(state, "admin-1")
        state = model.expose(state, "admin-1", reservation.envelope)
        state = consume(state, "admin-1", "A", reservation.envelope)
        self.assertIsNotNone(state)
        self.assertEqual(len(state.occurrences), 1)
        occurrence = state.occurrences[0]
        self.assertEqual(occurrence.witness_kind, "prov")
        self.assertNotEqual(occurrence.support[0], "BOTTOM")
        self.assertEqual(len({item.occurrence_id for item in state.occurrences}), len(state.occurrences))
        self.assertFalse(model.authorized_in_snapshot(reservation.auth_snapshot, model.bottom("admin")))

    def test_reauthorization_refreshes_generation_key_and_credential(self) -> None:
        auth_cell = self.require_api("auth_cell")
        state = model.initial_state()
        old = auth_cell(state, "B", "write")
        state = model.revoke(state, "B", "write")
        state = model.reauthorize(state, "B", "write")
        new = auth_cell(state, "B", "write")
        self.assertGreater(new.generation, old.generation)
        self.assertGreater(new.key_version, old.key_version)
        self.assertGreater(new.credential_version, old.credential_version)

    def test_parent_cas_and_client_validity_gate_persistence(self) -> None:
        build_repair = self.require_api("build_repair")
        canonicalize = self.require_api("canonicalize")
        process_and_persist = self.require_api("process_and_persist")
        state = model.revoke(model.initial_state(), "B", "read")
        wrong = build_repair(state, "B", parent_branch=99)
        self.assertIsNone(canonicalize(wrong))
        state = build_repair(state, "B", client_valid=False)
        state = canonicalize(state)
        self.assertIsNotNone(state)
        self.assertIsNone(process_and_persist(state))

    def test_required_mutants_have_reachable_counterexamples(self) -> None:
        traces = model.find_mutant_counterexamples()
        required = {
            "omitted_cover", "total_provenance", "envelope_equality",
            "duplicate_release", "duplicate_consume", "spent_root_rollback",
            "stale_release_revision", "fresh_reauthorization_material",
            "parent_cas", "client_validity", "frontier_readiness", "read_fence",
        }
        self.assertEqual(set(traces), required)
        for name, record in traces.items():
            self.assertTrue(record["trace"], name)
            self.assertTrue(any(step.startswith("mutant_") for step in record["trace"]), name)
            self.assertTrue(record["violations"], name)

    def test_progress_reaches_successful_occurrence(self) -> None:
        progress = model.progress_scenario()
        required_steps = ("revoke", "build_repair", "canonicalize", "process_and_persist",
                          "allocate", "authorize_release", "expose", "consume")
        joined = " -> ".join(progress["trace"])
        for step in required_steps:
            self.assertIn(step, joined)
        self.assertEqual(progress["occurrences"], 1)
        self.assertEqual(progress["violations"], [])

    def test_nonread_use_remains_valid_during_read_fence(self) -> None:
        for opid in ("write-1", "admin-1", "admit-1"):
            state = model.revoke(model.initial_state(), "C", "read")
            state = model.recover_current(state)
            state = model.allocate(state, opid)
            state = model.authorize_release(state, opid)
            state = model.expose(state, opid)
            state = model.consume(state, opid, "A")
            self.assertIsNotNone(state)
            self.assertEqual(model.violations(state), [])

    def test_epoch_limit_is_enforced(self) -> None:
        state = model.initial_state()
        for member in model.MEMBERS:
            state = model.revoke(state, member, "read")
            state = model.build_repair(state, member)
            if state.server_frontier.epoch == model.MAX_EPOCH:
                self.assertIsNone(model.canonicalize(state))
            else:
                state = model.canonicalize(state)
                state = model.process_and_persist(state)

    def test_admit_effect_support_is_independent_of_claimed_cover(self) -> None:
        state = self.released("admit-1")
        reservation = model.reservation_for(state, "admit-1")
        expected = model.occurrence_supports(reservation, "A")
        corrupted = reservation._replace(cover=frozenset({model.support(state, "A", "admin")}))
        self.assertEqual(model.occurrence_supports(corrupted, "A"), expected)

    def test_tla_configuration_references_existing_operators_and_constants(self) -> None:
        import re
        tla = (HERE / "ACCModel.tla").read_text()
        cfg = (HERE / "ACCModel.cfg").read_text()
        declared = set(re.findall(r"[A-Za-z][A-Za-z0-9_]*", tla.split("CONSTANTS", 1)[1].split("VARIABLES", 1)[0]))
        configured = set(re.findall(r"^  (\w+) (?:=|<-)", cfg, re.MULTILINE))
        self.assertEqual(configured, declared)
        for name in cfg.split("INVARIANTS", 1)[1].split():
            self.assertRegex(tla, rf"(?m)^{name} ==")
        for name in re.findall(r"<- (\w+)", cfg):
            self.assertRegex(tla, rf"(?m)^{name} ==")

    def test_tla_companion_declares_principal_fields_and_finite_bounds(self) -> None:
        tla = (HERE / "ACCModel.tla").read_text()
        for token in (
            "certid", "direction", "kappa", "mu", "releaseRoot", "spentRoot",
            "consumeCell", "occurrences", "keyVersion", "credentialVersion",
            "parentBranch", "publicValid", "clientValid", "ready",
            "MaxGeneration", "MaxRevision", "MaxEpoch", "MaxLog", "MaxOccurrences",
        ):
            self.assertIn(token, tla)
        self.assertNotIn("THEN auth[m][r][2]-1 ELSE auth[m][r][2]", tla)


if __name__ == "__main__":
    unittest.main(verbosity=2)
