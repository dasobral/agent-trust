#!/usr/bin/env python3
"""Finite executable evidence for the ACC/LAP-MLS structural interface.

The checker explores the generated good transition relation to a fixed depth,
runs four complete positive-operation scenarios and one repair/progress
scenario, and constructs reachable traces in deliberately mutated transition
systems.  It is not TLC, an unbounded proof, or a cryptographic proof.
"""
from __future__ import annotations

import hashlib
import json
import sys
from collections import deque
from dataclasses import dataclass
from typing import Callable, Iterable, NamedTuple


MEMBERS = ("A", "B", "C")
RIGHTS = ("read", "write", "admin", "admit")
GROUP = "G"
MAX_DEPTH = 3
MAX_GENERATION = 2
MAX_REVISION = 3
MAX_EPOCH = 2
MAX_LOG = 6
MAX_OCCURRENCES = 6


class OpSpec(NamedTuple):
    right: str
    actor: str
    target: str | None
    direction: str
    payload: str
    aux: str


OP_SPECS = {
    "read-1": OpSpec("read", "A", None, "recover", "message-1", "application"),
    "read-2": OpSpec("read", "A", None, "recover", "message-2", "application"),
    "write-1": OpSpec("write", "A", None, "acceptedAct", "write-action", "application"),
    "admin-1": OpSpec("admin", "A", None, "acceptedAct", "admin-action", "control"),
    "admit-1": OpSpec("admit", "A", "B", "acceptedAct", "admit-B", "membership"),
}
OP_IDS = tuple(OP_SPECS)
Support = tuple[str, str, int]


class AuthCell(NamedTuple):
    allowed: bool
    generation: int
    key_version: int
    credential_version: int


AuthSnapshot = tuple[AuthCell, ...]


class Frontier(NamedTuple):
    branch: int
    epoch: int
    revision: int
    generations: tuple[int, ...]
    exclusions: frozenset[Support]
    release_root: tuple[str, ...]
    spent_root: tuple[str, ...]


class Reservation(NamedTuple):
    opid: str
    certid: str
    status: str
    right: str
    actor: str
    target: str | None
    direction: str
    payload: str
    aux: str
    cover: frozenset[Support]
    auth_snapshot: AuthSnapshot
    roster_snapshot: frozenset[str]
    cut_revision: int
    epoch: int
    branch: int
    kappa: str
    mu: str
    certificate: str
    envelope: str
    release_local: Frontier
    release_server: Frontier
    release_fenced: bool


class Exposure(NamedTuple):
    opid: str
    certid: str
    envelope: str
    local_frontier: Frontier
    server_frontier: Frontier
    fenced: bool


class Consumption(NamedTuple):
    opid: str
    certid: str
    recipient: str
    envelope: str
    local_frontier: Frontier
    server_frontier: Frontier
    fenced: bool


class Occurrence(NamedTuple):
    occurrence_id: str
    event_kind: str
    recipient: str
    opid: str
    certid: str
    witness_kind: str
    support: Support
    support_set: frozenset[Support]
    cut_revision: int
    frontier: Frontier


class RepairCandidate(NamedTuple):
    candidate_id: str
    member: str
    parent_branch: int
    parent_epoch: int
    public_valid: bool
    client_valid: bool
    required_revision: int


class CanonicalRecord(NamedTuple):
    candidate_id: str
    member: str
    parent_branch: int
    parent_epoch: int
    child_branch: int
    child_epoch: int
    public_valid: bool
    client_valid: bool


@dataclass(frozen=True)
class State:
    auth: AuthSnapshot
    auth_history: tuple[AuthSnapshot, ...]
    revision: int
    roster: frozenset[str]
    pending_read: frozenset[Support]
    fenced: bool
    closed_grants: frozenset[Support]
    reservations: tuple[Reservation | None, ...]
    exposures: tuple[Exposure, ...]
    consume_cells: tuple[str, ...]
    consumptions: tuple[Consumption, ...]
    occurrences: tuple[Occurrence, ...]
    server_frontier: Frontier
    local_frontier: Frontier
    ready: bool
    frontier_history: tuple[Frontier, ...]
    rejected_recoveries: frozenset[str]
    candidate: RepairCandidate | None
    canonical_history: tuple[CanonicalRecord, ...]
    current_canonical_id: str | None
    next_occurrence: int


def index(member: str, right: str) -> int:
    return MEMBERS.index(member) * len(RIGHTS) + RIGHTS.index(right)


def op_index(opid: str) -> int:
    return OP_IDS.index(opid)


def auth_cell(state: State, member: str, right: str) -> AuthCell:
    return state.auth[index(member, right)]


def support(state: State, member: str, right: str) -> Support:
    return member, right, auth_cell(state, member, right).generation


def snapshot_support(snapshot: AuthSnapshot, member: str, right: str) -> Support:
    return member, right, snapshot[index(member, right)].generation


def bottom(right: str) -> Support:
    return "BOTTOM", right, -1


def authorized_in_snapshot(snapshot: AuthSnapshot, value: Support) -> bool:
    member, right, generation = value
    if member not in MEMBERS or right not in RIGHTS:
        return False
    cell = snapshot[index(member, right)]
    return cell.allowed and cell.generation == generation


def authorized(state: State, value: Support) -> bool:
    return authorized_in_snapshot(state.auth, value)


def generation_vector(auth: AuthSnapshot) -> tuple[int, ...]:
    return tuple(cell.generation for cell in auth)


def stable_hash(*parts: object) -> str:
    encoded = "\x1f".join(repr(part) for part in parts).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def initial_state() -> State:
    auth = tuple(AuthCell(True, 0, 0, 0) for _ in range(len(MEMBERS) * len(RIGHTS)))
    frontier = Frontier(0, 0, 0, generation_vector(auth), frozenset(), (), ())
    return State(
        auth=auth,
        auth_history=(auth,),
        revision=0,
        roster=frozenset(MEMBERS),
        pending_read=frozenset(),
        fenced=False,
        closed_grants=frozenset(),
        reservations=tuple(None for _ in OP_IDS),
        exposures=(),
        consume_cells=(),
        consumptions=(),
        occurrences=(),
        server_frontier=frontier,
        local_frontier=frontier,
        ready=True,
        frontier_history=(frontier,),
        rejected_recoveries=frozenset(),
        candidate=None,
        canonical_history=(),
        current_canonical_id=None,
        next_occurrence=0,
    )


def replace(state: State, **changes: object) -> State:
    values = {field: getattr(state, field) for field in State.__dataclass_fields__}
    values.update(changes)
    return State(**values)


def replace_reservation(state: State, opid: str, reservation: Reservation) -> State:
    values = list(state.reservations)
    values[op_index(opid)] = reservation
    return replace(state, reservations=tuple(values))


def reservation_for(state: State, opid: str) -> Reservation | None:
    return state.reservations[op_index(opid)]


def is_ready(state: State) -> bool:
    return state.ready and state.local_frontier == state.server_frontier


def prefix(left: tuple[str, ...], right: tuple[str, ...]) -> bool:
    """Return whether ``left`` is an append-only prefix of ``right``."""
    return len(left) <= len(right) and right[:len(left)] == left


def dominates(left: Frontier, right: Frontier) -> bool:
    return (
        left.branch >= right.branch
        and left.epoch >= right.epoch
        and left.revision >= right.revision
        and all(a >= b for a, b in zip(left.generations, right.generations))
        and left.exclusions >= right.exclusions
        and prefix(right.release_root, left.release_root)
        and prefix(right.spent_root, left.spent_root)
    )


def frontier_with(state: State, **changes: object) -> Frontier:
    values = state.server_frontier._asdict()
    values.update(changes)
    return Frontier(**values)


def install_server_frontier(state: State, frontier: Frontier, *, sync_local: bool) -> State:
    return replace(
        state,
        server_frontier=frontier,
        local_frontier=frontier if sync_local else state.local_frontier,
        ready=sync_local,
        frontier_history=state.frontier_history + (frontier,),
    )


def revoke(state: State, member: str, right: str) -> State | None:
    cell = auth_cell(state, member, right)
    if not cell.allowed or state.revision >= MAX_REVISION:
        return None
    old = (member, right, cell.generation)
    auth = list(state.auth)
    auth[index(member, right)] = AuthCell(False, cell.generation, cell.key_version, cell.credential_version)
    auth_tuple = tuple(auth)
    pending = state.pending_read
    closed = state.closed_grants
    exclusions = state.server_frontier.exclusions
    fenced = state.fenced
    if right == "read" and member in state.roster:
        pending = pending | {old}
        fenced = True
    else:
        closed = closed | {old}
        exclusions = exclusions | {old}
    revision = state.revision + 1
    frontier = frontier_with(
        state,
        revision=revision,
        generations=generation_vector(auth_tuple),
        exclusions=frozenset(exclusions),
    )
    changed = replace(
        state,
        auth=auth_tuple,
        auth_history=state.auth_history + (auth_tuple,),
        revision=revision,
        pending_read=frozenset(pending),
        fenced=fenced,
        closed_grants=frozenset(closed),
    )
    return install_server_frontier(changed, frontier, sync_local=False)


def reauthorize(state: State, member: str, right: str) -> State | None:
    cell = auth_cell(state, member, right)
    if cell.allowed or cell.generation >= MAX_GENERATION or state.revision >= MAX_REVISION:
        return None
    auth = list(state.auth)
    auth[index(member, right)] = AuthCell(
        True,
        cell.generation + 1,
        cell.key_version + 1,
        cell.credential_version + 1,
    )
    auth_tuple = tuple(auth)
    revision = state.revision + 1
    frontier = frontier_with(state, revision=revision, generations=generation_vector(auth_tuple))
    changed = replace(
        state,
        auth=auth_tuple,
        auth_history=state.auth_history + (auth_tuple,),
        revision=revision,
    )
    return install_server_frontier(changed, frontier, sync_local=False)


def cover_for(state: State, opid: str) -> frozenset[Support]:
    spec = OP_SPECS[opid]
    if spec.right == "read":
        return frozenset(support(state, member, "read") for member in state.roster)
    if spec.right == "admit":
        assert spec.target is not None
        return frozenset({support(state, spec.actor, "admin"), support(state, spec.target, "admit")})
    return frozenset({support(state, spec.actor, spec.right)})


def allocate(state: State, opid: str) -> State | None:
    if reservation_for(state, opid) is not None:
        return None
    spec = OP_SPECS[opid]
    empty_frontier = state.local_frontier
    reservation = Reservation(
        opid=opid,
        certid=f"cert-{opid}",
        status="allocated",
        right=spec.right,
        actor=spec.actor,
        target=spec.target,
        direction=spec.direction,
        payload=spec.payload,
        aux=spec.aux,
        cover=frozenset(),
        auth_snapshot=state.auth,
        roster_snapshot=state.roster,
        cut_revision=-1,
        epoch=-1,
        branch=-1,
        kappa="",
        mu=stable_hash("ACC-content-v1", GROUP, spec.right, spec.direction, spec.payload, spec.aux),
        certificate="",
        envelope="",
        release_local=empty_frontier,
        release_server=empty_frontier,
        release_fenced=state.fenced,
    )
    return replace_reservation(state, opid, reservation)


def make_released_reservation(
    state: State,
    allocated: Reservation,
    cover: frozenset[Support],
    *,
    cut_revision: int,
) -> Reservation:
    kappa = stable_hash(
        "ACC-kappa-v1", GROUP, allocated.opid, allocated.certid, allocated.right,
        allocated.direction, allocated.actor, allocated.target, state.server_frontier.branch,
        state.server_frontier.epoch, cut_revision, allocated.aux, allocated.mu,
    )
    certificate = stable_hash(
        "ACC-cert-v1", allocated.opid, allocated.certid, kappa, allocated.mu,
        cover, cut_revision, state.server_frontier.branch, state.server_frontier.epoch,
        generation_vector(state.auth),
    )
    envelope = "|".join(("ACC-envelope-v1", kappa, certificate, allocated.mu, allocated.payload))
    return allocated._replace(
        status="released",
        cover=cover,
        auth_snapshot=state.auth,
        roster_snapshot=state.roster,
        cut_revision=cut_revision,
        epoch=state.server_frontier.epoch,
        branch=state.server_frontier.branch,
        kappa=kappa,
        certificate=certificate,
        envelope=envelope,
        release_local=state.local_frontier,
        release_server=state.server_frontier,
        release_fenced=state.fenced,
    )


def _authorize_release(
    state: State,
    opid: str,
    *,
    bypass_ready: bool = False,
    bypass_fence: bool = False,
    cover_override: frozenset[Support] | None = None,
    cut_revision_override: int | None = None,
) -> State | None:
    reservation = reservation_for(state, opid)
    if reservation is None or reservation.status != "allocated":
        return None
    if not bypass_ready and not is_ready(state):
        return None
    if reservation.right == "read" and state.fenced and not bypass_fence:
        return None
    cover = cover_override if cover_override is not None else cover_for(state, opid)
    if not all(authorized(state, value) for value in cover):
        return None
    release_key = f"{reservation.opid}:{reservation.certid}"
    if release_key in state.server_frontier.release_root or len(state.server_frontier.release_root) >= MAX_LOG:
        return None
    cut_revision = state.revision if cut_revision_override is None else cut_revision_override
    released = make_released_reservation(state, reservation, cover, cut_revision=cut_revision)
    state = replace_reservation(state, opid, released)
    frontier = frontier_with(state, release_root=state.server_frontier.release_root + (release_key,))
    return install_server_frontier(state, frontier, sync_local=True)


def authorize_release(state: State, opid: str) -> State | None:
    return _authorize_release(state, opid)


def expose(state: State, opid: str, envelope: str | None = None) -> State | None:
    reservation = reservation_for(state, opid)
    if reservation is None or reservation.status != "released" or not is_ready(state):
        return None
    if reservation.right == "read" and state.fenced:
        return None
    if any(item.opid == opid for item in state.exposures):
        return None
    emitted = reservation.envelope if envelope is None else envelope
    if emitted != reservation.envelope:
        return None
    release_key = f"{reservation.opid}:{reservation.certid}"
    if release_key not in state.server_frontier.release_root:
        return None
    record = Exposure(opid, reservation.certid, emitted, state.local_frontier, state.server_frontier, state.fenced)
    return replace(state, exposures=state.exposures + (record,))


def occurrence_supports(reservation: Reservation, recipient: str) -> frozenset[Support]:
    if reservation.right == "read":
        return frozenset({snapshot_support(reservation.auth_snapshot, recipient, "read")})
    if reservation.right == "admit":
        assert reservation.target is not None
        return frozenset({
            snapshot_support(reservation.auth_snapshot, reservation.actor, "admin"),
            snapshot_support(reservation.auth_snapshot, reservation.target, "admit"),
        })
    return frozenset({snapshot_support(reservation.auth_snapshot, reservation.actor, reservation.right)})


def _consume(
    state: State,
    opid: str,
    recipient: str,
    envelope: str,
    *,
    witness_kind: str = "prov",
    support_override: frozenset[Support] | None = None,
    bypass_duplicate: bool = False,
    bypass_envelope: bool = False,
    bypass_cover: bool = False,
) -> State | None:
    reservation = reservation_for(state, opid)
    exposure = next((item for item in state.exposures if item.opid == opid), None)
    if reservation is None or exposure is None or not is_ready(state):
        return None
    if reservation.right == "read" and state.fenced:
        return None
    if not bypass_envelope and (envelope != reservation.envelope or exposure.envelope != reservation.envelope):
        return None
    cell = f"{opid}:{reservation.certid}:{recipient}"
    if cell in state.consume_cells and not bypass_duplicate:
        return None
    if len(state.occurrences) >= MAX_OCCURRENCES or len(state.server_frontier.spent_root) >= MAX_LOG:
        return None
    supports = support_override if support_override is not None else occurrence_supports(reservation, recipient)
    if witness_kind == "unattributed":
        primary = bottom(reservation.right)
        supports = frozenset({primary})
    else:
        primary = sorted(supports)[0]
        if not bypass_cover and not supports <= reservation.cover:
            return None
    frontier_before = state.server_frontier
    consumption = Consumption(
        opid, reservation.certid, recipient, envelope,
        state.local_frontier, state.server_frontier, state.fenced,
    )
    occurrence = Occurrence(
        occurrence_id=f"occ-{state.next_occurrence}",
        event_kind="recover" if reservation.right == "read" else "acceptedAct",
        recipient=recipient,
        opid=opid,
        certid=reservation.certid,
        witness_kind=witness_kind,
        support=primary,
        support_set=supports,
        cut_revision=reservation.cut_revision,
        frontier=frontier_before,
    )
    changed = replace(
        state,
        consume_cells=state.consume_cells + (cell,),
        consumptions=state.consumptions + (consumption,),
        occurrences=state.occurrences + (occurrence,),
        next_occurrence=state.next_occurrence + 1,
    )
    frontier = frontier_with(changed, spent_root=state.server_frontier.spent_root + (cell,))
    return install_server_frontier(changed, frontier, sync_local=True)


def consume(state: State, opid: str, recipient: str, envelope: str | None = None) -> State | None:
    reservation = reservation_for(state, opid)
    if reservation is None:
        return None
    return _consume(state, opid, recipient, reservation.envelope if envelope is None else envelope)


def build_repair(
    state: State,
    member: str,
    *,
    public_valid: bool = True,
    client_valid: bool = True,
    parent_branch: int | None = None,
    parent_epoch: int | None = None,
) -> State | None:
    if state.candidate is not None or not any(value[0] == member for value in state.pending_read):
        return None
    candidate = RepairCandidate(
        candidate_id=f"candidate-{len(state.canonical_history)}",
        member=member,
        parent_branch=state.server_frontier.branch if parent_branch is None else parent_branch,
        parent_epoch=state.server_frontier.epoch if parent_epoch is None else parent_epoch,
        public_valid=public_valid,
        client_valid=client_valid,
        required_revision=state.revision,
    )
    return replace(state, candidate=candidate)


def _canonicalize(state: State, *, bypass_parent_cas: bool = False, bypass_public_validity: bool = False) -> State | None:
    candidate = state.candidate
    if candidate is None:
        return None
    if state.server_frontier.epoch >= MAX_EPOCH or state.server_frontier.branch >= MAX_EPOCH:
        return None
    if not bypass_public_validity and not candidate.public_valid:
        return None
    if not bypass_parent_cas and (
        candidate.parent_branch != state.server_frontier.branch
        or candidate.parent_epoch != state.server_frontier.epoch
    ):
        return None
    removed = frozenset(value for value in state.pending_read if value[0] == candidate.member)
    pending = frozenset(value for value in state.pending_read if value[0] != candidate.member)
    frontier = frontier_with(
        state,
        branch=state.server_frontier.branch + 1,
        epoch=state.server_frontier.epoch + 1,
        exclusions=state.server_frontier.exclusions | removed,
    )
    record = CanonicalRecord(
        candidate.candidate_id,
        candidate.member,
        candidate.parent_branch,
        candidate.parent_epoch,
        frontier.branch,
        frontier.epoch,
        candidate.public_valid,
        candidate.client_valid,
    )
    changed = replace(
        state,
        roster=state.roster - {candidate.member},
        pending_read=pending,
        candidate=None,
        canonical_history=state.canonical_history + (record,),
        current_canonical_id=candidate.candidate_id,
    )
    return install_server_frontier(changed, frontier, sync_local=False)


def canonicalize(state: State) -> State | None:
    return _canonicalize(state)


def process_and_persist(state: State) -> State | None:
    if state.current_canonical_id is None:
        return None
    record = next(item for item in state.canonical_history if item.candidate_id == state.current_canonical_id)
    if not record.client_valid:
        return None
    return replace(
        state,
        local_frontier=state.server_frontier,
        ready=True,
        fenced=bool(state.pending_read),
    )


def recover_current(state: State) -> State | None:
    if is_ready(state):
        return None
    if state.current_canonical_id is not None:
        record = next(item for item in state.canonical_history if item.candidate_id == state.current_canonical_id)
        if not record.client_valid:
            return None
    return replace(state, local_frontier=state.server_frontier, ready=True)


def recovery_candidate(state: State, kind: str) -> Frontier:
    if kind == "current":
        return state.server_frontier
    if kind == "stale":
        return initial_state().server_frontier
    if kind == "incomparable":
        generations = list(state.server_frontier.generations)
        positive = next((i for i, value in enumerate(generations) if value > 0), 0)
        generations[positive] = max(0, generations[positive] - 1)
        return state.server_frontier._replace(
            branch=min(MAX_EPOCH, state.server_frontier.branch + 1),
            generations=tuple(generations),
        )
    raise ValueError(kind)


def attempt_recovery(state: State, candidate: Frontier, label: str) -> State | None:
    if candidate == state.server_frontier:
        return recover_current(state)
    if dominates(candidate, state.server_frontier):
        return None  # arbitrary server-frontier installation is outside this model
    if label in state.rejected_recoveries:
        return None
    return replace(state, rejected_recoveries=state.rejected_recoveries | {label})


def expected_binding(reservation: Reservation) -> tuple[str, str, str]:
    kappa = stable_hash(
        "ACC-kappa-v1", GROUP, reservation.opid, reservation.certid, reservation.right,
        reservation.direction, reservation.actor, reservation.target, reservation.branch,
        reservation.epoch, reservation.cut_revision, reservation.aux, reservation.mu,
    )
    certificate = stable_hash(
        "ACC-cert-v1", reservation.opid, reservation.certid, kappa, reservation.mu,
        reservation.cover, reservation.cut_revision, reservation.branch, reservation.epoch,
        generation_vector(reservation.auth_snapshot),
    )
    envelope = "|".join(("ACC-envelope-v1", kappa, certificate, reservation.mu, reservation.payload))
    return kappa, certificate, envelope


def inv_frontier_current(state: State) -> bool:
    return (
        state.server_frontier.revision == state.revision
        and state.server_frontier.generations == generation_vector(state.auth)
        and (not state.ready or state.local_frontier == state.server_frontier)
    )


def inv_frontier_monotone(state: State) -> bool:
    return all(dominates(later, earlier) for earlier, later in zip(state.frontier_history, state.frontier_history[1:]))


def inv_release_records(state: State) -> bool:
    released = [item for item in state.reservations if item is not None and item.status == "released"]
    keys = [f"{item.opid}:{item.certid}" for item in released]
    return (
        len(state.server_frontier.release_root) == len(set(state.server_frontier.release_root))
        and sorted(state.server_frontier.release_root) == sorted(keys)
        and all(
            item.release_local == item.release_server
            and item.cut_revision == item.release_server.revision
            and item.branch == item.release_server.branch
            and item.epoch == item.release_server.epoch
            and not (item.right == "read" and item.release_fenced)
            and all(authorized_in_snapshot(item.auth_snapshot, value) for value in item.cover)
            for item in released
        )
    )


def inv_admit_cover(state: State) -> bool:
    for item in state.reservations:
        if item is None or item.status != "released" or item.right != "admit":
            continue
        assert item.target is not None
        expected = frozenset({
            snapshot_support(item.auth_snapshot, item.actor, "admin"),
            snapshot_support(item.auth_snapshot, item.target, "admit"),
        })
        if item.cover != expected:
            return False
    return True


def inv_exact_binding(state: State) -> bool:
    for item in state.reservations:
        if item is None or item.status != "released":
            continue
        mu = stable_hash("ACC-content-v1", GROUP, item.right, item.direction, item.payload, item.aux)
        if item.mu != mu or (item.kappa, item.certificate, item.envelope) != expected_binding(item):
            return False
    return all(
        item.local_frontier == item.server_frontier
        and not (OP_SPECS[item.opid].right == "read" and item.fenced)
        and (reservation_for(state, item.opid) is not None)
        and item.envelope == reservation_for(state, item.opid).envelope
        for item in state.exposures
    )


def inv_consumption(state: State) -> bool:
    root = state.server_frontier.spent_root
    if len(root) != len(set(root)) or root != state.consume_cells or len(state.consume_cells) != len(state.consumptions):
        return False
    return all(
        item.local_frontier == item.server_frontier
        and not (OP_SPECS[item.opid].right == "read" and item.fenced)
        and reservation_for(state, item.opid) is not None
        and item.envelope == reservation_for(state, item.opid).envelope
        for item in state.consumptions
    )


def inv_total_occurrences(state: State) -> bool:
    ids = [item.occurrence_id for item in state.occurrences]
    if len(ids) != len(set(ids)) or len(state.occurrences) != len(state.consumptions):
        return False
    for item in state.occurrences:
        reservation = reservation_for(state, item.opid)
        if reservation is None or item.event_kind not in {"recover", "acceptedAct"}:
            return False
        if item.witness_kind == "unattributed":
            if item.support != bottom(reservation.right) or item.support_set != frozenset({item.support}):
                return False
        elif item.witness_kind == "prov":
            if item.support[0] == "BOTTOM" or item.support not in item.support_set:
                return False
        else:
            return False
    return True


def inv_successful_effect_authorized(state: State) -> bool:
    for item in state.occurrences:
        reservation = reservation_for(state, item.opid)
        if reservation is None or item.witness_kind != "prov":
            return False
        if not item.support_set <= reservation.cover:
            return False
        if not all(authorized_in_snapshot(reservation.auth_snapshot, value) for value in item.support_set):
            return False
    return True


def inv_reauthorization_fresh(state: State) -> bool:
    for before, after in zip(state.auth_history, state.auth_history[1:]):
        for old, new in zip(before, after):
            if not old.allowed and new.allowed:
                if not (
                    new.generation > old.generation
                    and new.key_version > old.key_version
                    and new.credential_version > old.credential_version
                ):
                    return False
    return True


def inv_canonical_branch(state: State) -> bool:
    branch = 0
    epoch = 0
    for item in state.canonical_history:
        if not item.public_valid or item.parent_branch != branch or item.parent_epoch != epoch:
            return False
        if item.child_branch != branch + 1 or item.child_epoch != epoch + 1:
            return False
        branch, epoch = item.child_branch, item.child_epoch
    return True


def inv_ready_client_valid(state: State) -> bool:
    if not state.ready or state.current_canonical_id is None:
        return True
    record = next(item for item in state.canonical_history if item.candidate_id == state.current_canonical_id)
    return record.client_valid


def inv_read_roster(state: State) -> bool:
    for reservation in state.reservations:
        if reservation is None or reservation.status != "released" or reservation.right != "read":
            continue
        for member in reservation.roster_snapshot:
            if not authorized_in_snapshot(
                reservation.auth_snapshot,
                snapshot_support(reservation.auth_snapshot, member, "read"),
            ):
                return False
    return True


INVARIANTS: tuple[tuple[str, Callable[[State], bool]], ...] = (
    ("frontier_current_and_ready", inv_frontier_current),
    ("frontier_and_roots_monotone", inv_frontier_monotone),
    ("release_exact_ready_current_one_shot", inv_release_records),
    ("admit_joint_cover", inv_admit_cover),
    ("immutable_content_context_envelope_equality", inv_exact_binding),
    ("per_recipient_consumption_one_shot", inv_consumption),
    ("total_unique_occurrence_witness", inv_total_occurrences),
    ("successful_effect_support_authorized_and_covered", inv_successful_effect_authorized),
    ("fresh_reauthorization_generation_key_credential", inv_reauthorization_fresh),
    ("canonical_parent_cas_and_public_validity", inv_canonical_branch),
    ("ready_frontier_has_client_valid_candidate", inv_ready_client_valid),
    ("denied_roster_member_absent_before_read_release", inv_read_roster),
)


def violations(state: State) -> list[str]:
    return [name for name, predicate in INVARIANTS if not predicate(state)]


def successors(state: State) -> Iterable[tuple[str, State]]:
    for member in MEMBERS:
        for right in RIGHTS:
            nxt = revoke(state, member, right)
            if nxt is not None:
                yield f"revoke({member},{right})", nxt
            nxt = reauthorize(state, member, right)
            if nxt is not None:
                yield f"reauthorize({member},{right})", nxt
    for opid in OP_IDS:
        nxt = allocate(state, opid)
        if nxt is not None:
            yield f"allocate({opid})", nxt
        nxt = authorize_release(state, opid)
        if nxt is not None:
            yield f"authorize_release({opid})", nxt
        reservation = reservation_for(state, opid)
        if reservation is not None:
            nxt = expose(state, opid, reservation.envelope)
            if nxt is not None:
                yield f"expose({opid})", nxt
            nxt = consume(state, opid, "A", reservation.envelope)
            if nxt is not None:
                yield f"consume({opid},A)", nxt
    if state.candidate is None:
        for member in MEMBERS:
            nxt = build_repair(state, member)
            if nxt is not None:
                yield f"build_repair({member})", nxt
    nxt = canonicalize(state)
    if nxt is not None:
        yield "canonicalize", nxt
    nxt = process_and_persist(state)
    if nxt is not None:
        yield "process_and_persist", nxt
    nxt = recover_current(state)
    if nxt is not None:
        yield "recover_current", nxt
    for kind in ("stale", "incomparable"):
        nxt = attempt_recovery(state, recovery_candidate(state, kind), kind)
        if nxt is not None:
            yield f"recover_{kind}", nxt


def exhaustive_check() -> tuple[int, int, set[str]]:
    initial = initial_state()
    queue: deque[tuple[State, tuple[str, ...]]] = deque([(initial, ())])
    visited = {initial}
    transitions = 0
    actions: set[str] = set()
    while queue:
        state, trace = queue.popleft()
        if len(trace) == MAX_DEPTH:
            continue
        for label, nxt in successors(state):
            transitions += 1
            actions.add(label.split("(", 1)[0])
            bad = violations(nxt)
            if bad:
                raise AssertionError(f"good model violates {bad}: {' -> '.join(trace + (label,))}")
            if nxt not in visited:
                visited.add(nxt)
                queue.append((nxt, trace + (label,)))
    return len(visited), transitions, actions


def complete_operation(opid: str) -> State:
    state = allocate(initial_state(), opid)
    assert state is not None
    state = authorize_release(state, opid)
    assert state is not None
    reservation = reservation_for(state, opid)
    assert reservation is not None
    state = expose(state, opid, reservation.envelope)
    assert state is not None
    state = consume(state, opid, "A", reservation.envelope)
    assert state is not None and not violations(state)
    return state


def positive_rights() -> set[str]:
    result = set()
    for opid in ("read-1", "write-1", "admin-1", "admit-1"):
        state = complete_operation(opid)
        result.add(OP_SPECS[state.occurrences[-1].opid].right)
    return result


def progress_scenario() -> dict[str, object]:
    state = initial_state()
    trace: list[str] = []

    def step(label: str, action: Callable[[State], State | None]) -> None:
        nonlocal state
        nxt = action(state)
        if nxt is None:
            raise AssertionError(f"progress step unavailable: {label}")
        state = nxt
        trace.append(label)

    step("revoke(B,read)", lambda s: revoke(s, "B", "read"))
    step("build_repair(B)", lambda s: build_repair(s, "B", client_valid=True))
    step("canonicalize", canonicalize)
    step("process_and_persist", process_and_persist)
    step("allocate(read-1)", lambda s: allocate(s, "read-1"))
    step("authorize_release(read-1)", lambda s: authorize_release(s, "read-1"))
    reservation = reservation_for(state, "read-1")
    assert reservation is not None
    step("expose(read-1)", lambda s: expose(s, "read-1", reservation.envelope))
    step("consume(read-1,A)", lambda s: consume(s, "read-1", "A", reservation.envelope))
    return {"trace": trace, "occurrences": len(state.occurrences), "violations": violations(state)}


def _mutant_expose(state: State, opid: str, envelope: str) -> State:
    reservation = reservation_for(state, opid)
    assert reservation is not None
    record = Exposure(opid, reservation.certid, envelope, state.local_frontier, state.server_frontier, state.fenced)
    return replace(state, exposures=state.exposures + (record,))


def _mutant_consume(
    state: State,
    opid: str,
    recipient: str,
    *,
    witness_kind: str = "prov",
    supports: frozenset[Support] | None = None,
    duplicate: bool = False,
) -> State:
    reservation = reservation_for(state, opid)
    assert reservation is not None
    return _consume(
        state,
        opid,
        recipient,
        reservation.envelope,
        witness_kind=witness_kind,
        support_override=supports,
        bypass_duplicate=duplicate,
        bypass_cover=supports is not None,
    )  # type: ignore[return-value]


def _counterexample(name: str) -> tuple[State, list[str]]:
    state = initial_state()
    trace: list[str] = []

    def step(label: str, action: Callable[[State], State | None]) -> None:
        nonlocal state
        nxt = action(state)
        if nxt is None:
            raise AssertionError(f"{name}: transition unavailable: {label}")
        state = nxt
        trace.append(label)

    if name == "omitted_cover":
        step("allocate(read-1)", lambda s: allocate(s, "read-1"))
        step("mutant_authorize_omitted_cover(read-1)", lambda s: _authorize_release(
            s, "read-1", cover_override=frozenset({support(s, "A", "read")}),
        ))
        reservation = reservation_for(state, "read-1"); assert reservation is not None
        step("expose(read-1)", lambda s: expose(s, "read-1", reservation.envelope))
        step("mutant_consume_outside_cover(read-1,B)", lambda s: _mutant_consume(
            s, "read-1", "B", supports=frozenset({support(s, "B", "read")}),
        ))
    elif name == "total_provenance":
        step("allocate(write-1)", lambda s: allocate(s, "write-1"))
        step("authorize_release(write-1)", lambda s: authorize_release(s, "write-1"))
        reservation = reservation_for(state, "write-1"); assert reservation is not None
        step("expose(write-1)", lambda s: expose(s, "write-1", reservation.envelope))
        step("mutant_consume_unattributed(write-1,A)", lambda s: _mutant_consume(s, "write-1", "A", witness_kind="unattributed"))
    elif name == "envelope_equality":
        step("allocate(write-1)", lambda s: allocate(s, "write-1"))
        step("authorize_release(write-1)", lambda s: authorize_release(s, "write-1"))
        reservation = reservation_for(state, "write-1"); assert reservation is not None
        step("mutant_expose_changed_envelope(write-1)", lambda s: _mutant_expose(s, "write-1", reservation.envelope + "-changed"))
    elif name == "duplicate_release":
        step("allocate(write-1)", lambda s: allocate(s, "write-1"))
        step("authorize_release(write-1)", lambda s: authorize_release(s, "write-1"))
        def duplicate_release(s: State) -> State:
            key = s.server_frontier.release_root[-1]
            frontier = frontier_with(s, release_root=s.server_frontier.release_root + (key,))
            return install_server_frontier(s, frontier, sync_local=True)
        step("mutant_duplicate_release(write-1)", duplicate_release)
    elif name == "duplicate_consume":
        state = complete_operation("write-1")
        trace.extend(("allocate(write-1)", "authorize_release(write-1)", "expose(write-1)", "consume(write-1,A)"))
        step("mutant_duplicate_consume(write-1,A)", lambda s: _mutant_consume(s, "write-1", "A", duplicate=True))
    elif name == "spent_root_rollback":
        state = complete_operation("write-1")
        trace.extend(("allocate(write-1)", "authorize_release(write-1)", "expose(write-1)", "consume(write-1,A)"))
        def rollback(s: State) -> State:
            frontier = s.server_frontier._replace(spent_root=())
            changed = replace(s, server_frontier=frontier, local_frontier=frontier, ready=True)
            return replace(changed, frontier_history=changed.frontier_history + (frontier,))
        step("mutant_accept_spent_root_rollback", rollback)
    elif name == "stale_release_revision":
        step("revoke(B,write)", lambda s: revoke(s, "B", "write"))
        step("recover_current", recover_current)
        step("allocate(write-1)", lambda s: allocate(s, "write-1"))
        step("mutant_authorize_stale_revision(write-1)", lambda s: _authorize_release(s, "write-1", cut_revision_override=0))
    elif name == "fresh_reauthorization_material":
        step("revoke(B,write)", lambda s: revoke(s, "B", "write"))
        def stale_material(s: State) -> State:
            cell = auth_cell(s, "B", "write")
            auth = list(s.auth)
            auth[index("B", "write")] = AuthCell(True, cell.generation + 1, cell.key_version, cell.credential_version)
            auth_tuple = tuple(auth)
            revision = s.revision + 1
            frontier = frontier_with(s, revision=revision, generations=generation_vector(auth_tuple))
            changed = replace(s, auth=auth_tuple, auth_history=s.auth_history + (auth_tuple,), revision=revision)
            return install_server_frontier(changed, frontier, sync_local=False)
        step("mutant_reauthorize_stale_key_credential(B,write)", stale_material)
    elif name == "parent_cas":
        step("revoke(B,read)", lambda s: revoke(s, "B", "read"))
        step("build_repair_wrong_parent(B)", lambda s: build_repair(s, "B", parent_branch=99))
        step("mutant_canonicalize_without_parent_cas", lambda s: _canonicalize(s, bypass_parent_cas=True))
    elif name == "client_validity":
        step("revoke(B,read)", lambda s: revoke(s, "B", "read"))
        step("build_repair_client_invalid(B)", lambda s: build_repair(s, "B", client_valid=False))
        step("canonicalize", canonicalize)
        step("mutant_persist_client_invalid", lambda s: replace(s, local_frontier=s.server_frontier, ready=True, fenced=False))
    elif name == "frontier_readiness":
        step("revoke(B,write)", lambda s: revoke(s, "B", "write"))
        step("allocate(write-1)", lambda s: allocate(s, "write-1"))
        step("mutant_authorize_without_frontier_readiness(write-1)", lambda s: _authorize_release(s, "write-1", bypass_ready=True))
    elif name == "read_fence":
        step("revoke(B,read)", lambda s: revoke(s, "B", "read"))
        step("recover_current", recover_current)
        step("allocate(read-1)", lambda s: allocate(s, "read-1"))
        step("mutant_authorize_while_read_fenced(read-1)", lambda s: _authorize_release(
            s,
            "read-1",
            bypass_fence=True,
            cover_override=frozenset({support(s, "A", "read"), support(s, "C", "read")}),
        ))
    else:
        raise ValueError(name)
    return state, trace


MUTANTS = (
    "omitted_cover",
    "total_provenance",
    "envelope_equality",
    "duplicate_release",
    "duplicate_consume",
    "spent_root_rollback",
    "stale_release_revision",
    "fresh_reauthorization_material",
    "parent_cas",
    "client_validity",
    "frontier_readiness",
    "read_fence",
)


def find_mutant_counterexamples() -> dict[str, dict[str, list[str]]]:
    result: dict[str, dict[str, list[str]]] = {}
    for name in MUTANTS:
        state, trace = _counterexample(name)
        bad = violations(state)
        if not bad:
            raise AssertionError(f"mutant did not violate an invariant: {name}")
        result[name] = {"trace": trace, "violations": bad}
    return result


def run_bounded_checks() -> dict[str, object]:
    states, transitions, actions = exhaustive_check()
    positive = positive_rights()
    if positive != set(RIGHTS):
        raise AssertionError(f"missing positive rights: {set(RIGHTS) - positive}")
    progress = progress_scenario()
    if progress["violations"] or progress["occurrences"] != 1:
        raise AssertionError(f"progress scenario failed: {progress}")
    return {
        "states": states,
        "transitions": transitions,
        "depth": MAX_DEPTH,
        "invariant_violations": 0,
        "positive_exercises": sorted(positive),
        "actions": sorted(actions),
        "mutant_counterexamples": find_mutant_counterexamples(),
        "progress_scenario": progress,
    }


def main() -> None:
    report = run_bounded_checks()
    print(
        "GOOD MODEL: states={states} transitions={transitions} "
        "invariant_violations=0 depth={depth}".format(**report)
    )
    print("RIGHTS EXERCISED: " + ", ".join(report["positive_exercises"]))
    print("PROGRESS SCENARIO: " + " -> ".join(report["progress_scenario"]["trace"]))
    print("MUTANT COUNTEREXAMPLES:")
    for name, record in report["mutant_counterexamples"].items():
        print(f"  {name}: {' -> '.join(record['trace'])} :: {', '.join(record['violations'])}")
    if "--json" in sys.argv:
        print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
