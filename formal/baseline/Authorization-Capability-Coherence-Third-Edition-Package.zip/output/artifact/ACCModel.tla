------------------------------- MODULE ACCModel -------------------------------
EXTENDS FiniteSets, Naturals, Sequences
\* Finite audit companion to check_acc_model.py. It has not been parsed by SANY
\* or executed by TLC in this environment; no such claim is made.

CONSTANTS Members, Rights, OpIds, CertIds, OpCert, OpRight, OpActor, OpTarget,
          OpDirection, OpPayload, OpAux, NoTarget, Group, Bottom,
          NoReservation, NoCandidate, NoCanonical, NoEnvelope,
          MaxGeneration, MaxRevision, MaxEpoch, MaxLog, MaxOccurrences,
          MaxHistory, MaxKeyVersion, MaxCredentialVersion

VARIABLES auth, authHist, authRev, roster, pendingRead, readFenced, closedGrant,
          reservations, exposed, emittedEnvelope, exposureLocal, exposureServer,
          exposureFenced, consumeCell, occurrences, serverF, localF, ready,
          frontierHist, rejectedRecoveries, candidate, canonicalHist,
          currentCanonical


Generations == 0..MaxGeneration
Revisions == 0..MaxRevision
Epochs == 0..MaxEpoch
KeyVersions == 0..MaxKeyVersion
CredentialVersions == 0..MaxCredentialVersion
Directions == {"recover", "acceptedAct"}
WitnessKinds == {"prov", "unattributed"}
ReservationStates == {"allocated", "released"}

Support == (Members \cup {Bottom}) \X Rights \X Generations
Grant(m,r,n) == <<m,r,n>>
BottomSupport(r) == Grant(Bottom,r,0)
AuthCell == BOOLEAN \X Generations \X KeyVersions \X CredentialVersions
AuthType == [Members -> [Rights -> AuthCell]]
GenerationMap == [Members -> [Rights -> Generations]]
InitialAuth == [m \in Members |-> [r \in Rights |-> <<TRUE,0,0,0>>]]
Current(m,r) == Grant(m,r,auth[m][r][2])
CurrentFrom(a,m,r) == Grant(m,r,a[m][r][2])
AuthAt(a,s) ==
  /\ s[1] \in Members
  /\ s[2] \in Rights
  /\ a[s[1]][s[2]][1]
  /\ a[s[1]][s[2]][2] = s[3]
keyVersion(m,r) == auth[m][r][3]
credentialVersion(m,r) == auth[m][r][4]
GenMap(a) == [m \in Members |-> [r \in Rights |-> a[m][r][2]]]

SeqToSet(s) == {s[i] : i \in DOMAIN s}
BoundedSeq(S,n) == UNION {[1..i -> S] : i \in 0..n}
NoDuplicates(s) == \A i,j \in DOMAIN s : i # j => s[i] # s[j]
SeqPrefix(a,b) == /\ Len(a) <= Len(b) /\ \A i \in 1..Len(a) : a[i] = b[i]
ReleaseKey == OpIds \X CertIds
ConsumeKey == OpIds \X CertIds \X Members

FrontierOK(f) ==
  /\ f.branch \in Epochs
  /\ f.epoch \in Epochs
  /\ f.revision \in Revisions
  /\ f.generations \in GenerationMap
  /\ f.exclusions \subseteq Support
  /\ f.releaseRoot \in BoundedSeq(ReleaseKey,MaxLog)
  /\ f.spentRoot \in BoundedSeq(ConsumeKey,MaxLog)

InitialFrontier == [branch |-> 0,
                    epoch |-> 0,
                    revision |-> 0,
                    generations |-> GenMap(InitialAuth),
                    exclusions |-> {},
                    releaseRoot |-> <<>>,
                    spentRoot |-> <<>>]

FrontierDominates(a,b) ==
  /\ a.branch >= b.branch
  /\ a.epoch >= b.epoch
  /\ a.revision >= b.revision
  /\ \A m \in Members,r \in Rights : a.generations[m][r] >= b.generations[m][r]
  /\ a.exclusions \supseteq b.exclusions
  /\ SeqPrefix(b.releaseRoot,a.releaseRoot)
  /\ SeqPrefix(b.spentRoot,a.spentRoot)

ReadCover == {Current(m,"read") : m \in roster}
CoverFor(o) ==
  IF OpRight[o] = "read" THEN ReadCover
  ELSE IF OpRight[o] = "admit"
    THEN {Current(OpActor[o],"admin"),Current(OpTarget[o],"admit")}
  ELSE {Current(OpActor[o],OpRight[o])}

Mu(o) == <<"ACC-content-v1",Group,OpRight[o],OpDirection[o],OpPayload[o],OpAux[o]>>
Kappa(o,c,v,f) == <<"ACC-kappa-v1",Group,o,OpCert[o],OpRight[o],
                    OpDirection[o],OpActor[o],OpTarget[o],f.branch,f.epoch,
                    v,OpAux[o],Mu(o)>>
Certificate(o,c,a,v,f) == <<"ACC-cert-v1",o,OpCert[o],Kappa(o,c,v,f),
                            Mu(o),c,v,f.branch,f.epoch,GenMap(a)>>
Envelope(o,c,a,v,f) == <<"ACC-envelope-v1",Kappa(o,c,v,f),
                         Certificate(o,c,a,v,f),Mu(o),OpPayload[o]>>

ReservationOK(p) ==
  p = NoReservation \/
  /\ p.opid \in OpIds
  /\ p.certid \in CertIds
  /\ p.status \in ReservationStates
  /\ p.right \in Rights
  /\ p.actor \in Members
  /\ p.target \in Members \cup {NoTarget}
  /\ p.direction \in Directions
  /\ p.cover \subseteq Support
  /\ p.authsnap \in AuthType
  /\ p.rostersnap \subseteq Members
  /\ p.cutRev \in Revisions
  /\ p.branch \in Epochs
  /\ p.epoch \in Epochs
  /\ FrontierOK(p.releaseLocal)
  /\ FrontierOK(p.releaseServer)
  /\ p.releaseFenced \in BOOLEAN

CanonicalOK(c) ==
  c = NoCanonical \/
  /\ c.candidateId \in 0..MaxHistory
  /\ c.member \in Members
  /\ c.parentBranch \in Epochs
  /\ c.parentEpoch \in Epochs
  /\ c.childBranch \in Epochs
  /\ c.childEpoch \in Epochs
  /\ c.publicValid \in BOOLEAN
  /\ c.clientValid \in BOOLEAN


vars == <<auth,authHist,authRev,roster,pendingRead,readFenced,closedGrant,
          reservations,exposed,emittedEnvelope,exposureLocal,exposureServer,
          exposureFenced,consumeCell,occurrences,serverF,localF,ready,
          frontierHist,rejectedRecoveries,candidate,canonicalHist,
          currentCanonical>>

OccurrenceOK(x) ==
  /\ x.occurrenceId \in 0..(MaxOccurrences-1)
  /\ x.eventKind \in Directions
  /\ x.recipient \in Members
  /\ x.opid \in OpIds
  /\ x.certid \in CertIds
  /\ x.witnessKind \in WitnessKinds
  /\ x.support \in Support
  /\ x.supportSet \subseteq Support
  /\ x.cutRev \in Revisions
  /\ FrontierOK(x.frontier)

TypeOK ==
  /\ auth \in AuthType
  /\ authHist \in BoundedSeq(AuthType,MaxHistory)
  /\ authRev \in Revisions
  /\ roster \subseteq Members
  /\ pendingRead \subseteq Support
  /\ readFenced \in BOOLEAN
  /\ closedGrant \subseteq Support
  /\ DOMAIN reservations = OpIds
  /\ \A o \in OpIds : ReservationOK(reservations[o])
  /\ exposed \subseteq OpIds
  /\ DOMAIN emittedEnvelope = OpIds
  /\ \A o \in OpIds :
       IF o \in exposed THEN emittedEnvelope[o] = reservations[o].envelope
       ELSE emittedEnvelope[o] = NoEnvelope
  /\ DOMAIN exposureLocal = OpIds
  /\ DOMAIN exposureServer = OpIds
  /\ \A o \in OpIds : FrontierOK(exposureLocal[o]) /\ FrontierOK(exposureServer[o])
  /\ exposureFenced \in [OpIds -> BOOLEAN]
  /\ consumeCell \in [OpIds -> [Members -> {"unused","spent"}]]
  /\ Len(occurrences) <= MaxOccurrences
  /\ \A i \in DOMAIN occurrences : OccurrenceOK(occurrences[i])
  /\ FrontierOK(serverF) /\ FrontierOK(localF)
  /\ ready \in BOOLEAN
  /\ Len(frontierHist) <= MaxHistory
  /\ \A i \in DOMAIN frontierHist : FrontierOK(frontierHist[i])
  /\ rejectedRecoveries \subseteq {"stale","incomparable"}
  /\ (candidate = NoCandidate \/
       /\ candidate.candidateId \in 0..MaxHistory
       /\ candidate.member \in Members
       /\ candidate.parentBranch \in Epochs
       /\ candidate.parentEpoch \in Epochs
       /\ candidate.publicValid \in BOOLEAN
       /\ candidate.clientValid \in BOOLEAN
       /\ candidate.requiredRevision \in Revisions)
  /\ Len(canonicalHist) <= MaxHistory
  /\ \A i \in DOMAIN canonicalHist : CanonicalOK(canonicalHist[i])
  /\ CanonicalOK(currentCanonical)

Init ==
  /\ auth = InitialAuth
  /\ authHist = <<InitialAuth>>
  /\ authRev = 0
  /\ roster = Members
  /\ pendingRead = {}
  /\ readFenced = FALSE
  /\ closedGrant = {}
  /\ reservations = [o \in OpIds |-> NoReservation]
  /\ exposed = {}
  /\ emittedEnvelope = [o \in OpIds |-> NoEnvelope]
  /\ exposureLocal = [o \in OpIds |-> InitialFrontier]
  /\ exposureServer = [o \in OpIds |-> InitialFrontier]
  /\ exposureFenced = [o \in OpIds |-> FALSE]
  /\ consumeCell = [o \in OpIds |-> [m \in Members |-> "unused"]]
  /\ occurrences = <<>>
  /\ serverF = InitialFrontier
  /\ localF = InitialFrontier
  /\ ready = TRUE
  /\ frontierHist = <<InitialFrontier>>
  /\ rejectedRecoveries = {}
  /\ candidate = NoCandidate
  /\ canonicalHist = <<>>
  /\ currentCanonical = NoCanonical

PolicyDeny(m,r) ==
  /\ auth[m][r][1]
  /\ authRev < MaxRevision
  /\ Len(authHist) < MaxHistory
  /\ Len(frontierHist) < MaxHistory
  /\ LET old == Current(m,r)
         newAuth == [auth EXCEPT ![m][r] = <<FALSE,@[2],@[3],@[4]>>]
         newF == [serverF EXCEPT
                   !.revision = authRev+1,
                   !.generations[m][r] = newAuth[m][r][2],
                   !.exclusions = IF r = "read" /\ m \in roster THEN @ ELSE @ \cup {old}]
     IN /\ auth' = newAuth
        /\ authHist' = Append(authHist,newAuth)
        /\ authRev' = authRev+1
        /\ pendingRead' = IF r = "read" /\ m \in roster THEN pendingRead \cup {old} ELSE pendingRead
        /\ readFenced' = readFenced \/ (r = "read" /\ m \in roster)
        /\ closedGrant' = IF r = "read" /\ m \in roster THEN closedGrant ELSE closedGrant \cup {old}
        /\ serverF' = newF
        /\ frontierHist' = Append(frontierHist,newF)
  /\ ready' = FALSE
  /\ UNCHANGED <<roster,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,occurrences,localF,
       rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

PolicyAllow(m,r) ==
  /\ ~auth[m][r][1]
  /\ auth[m][r][2] < MaxGeneration
  /\ auth[m][r][3] < MaxKeyVersion
  /\ auth[m][r][4] < MaxCredentialVersion
  /\ authRev < MaxRevision
  /\ Len(authHist) < MaxHistory
  /\ Len(frontierHist) < MaxHistory
  /\ LET newAuth == [auth EXCEPT ![m][r] = <<TRUE,@[2]+1,@[3]+1,@[4]+1>>]
         newF == [serverF EXCEPT
                   !.revision = authRev+1,
                   !.generations[m][r] = newAuth[m][r][2]]
     IN /\ auth' = newAuth
        /\ authHist' = Append(authHist,newAuth)
        /\ authRev' = authRev+1
        /\ serverF' = newF
        /\ frontierHist' = Append(frontierHist,newF)
  /\ ready' = FALSE
  /\ UNCHANGED <<roster,pendingRead,readFenced,closedGrant,reservations,
       exposed,emittedEnvelope,exposureLocal,exposureServer,exposureFenced,
       consumeCell,occurrences,localF,rejectedRecoveries,candidate,
       canonicalHist,currentCanonical>>

Allocate(o) ==
  /\ reservations[o] = NoReservation
  /\ reservations' = [reservations EXCEPT ![o] =
       [opid |-> o, certid |-> OpCert[o], status |-> "allocated",
        right |-> OpRight[o], actor |-> OpActor[o], target |-> OpTarget[o],
        direction |-> OpDirection[o], payload |-> OpPayload[o], aux |-> OpAux[o],
        cover |-> {}, authsnap |-> auth, rostersnap |-> roster,
        cutRev |-> 0, branch |-> 0, epoch |-> 0,
        kappa |-> Kappa(o,{},0,InitialFrontier), mu |-> Mu(o),
        certificate |-> Certificate(o,{},InitialAuth,0,InitialFrontier),
        envelope |-> Envelope(o,{},InitialAuth,0,InitialFrontier),
        releaseLocal |-> localF, releaseServer |-> serverF,
        releaseFenced |-> readFenced]]
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,exposed,emittedEnvelope,exposureLocal,exposureServer,
       exposureFenced,consumeCell,occurrences,serverF,localF,ready,
       frontierHist,rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

AuthorizeRelease(o) ==
  /\ Len(frontierHist) < MaxHistory
  /\ reservations[o] # NoReservation
  /\ reservations[o].status = "allocated"
  /\ ready /\ localF = serverF
  /\ ~(OpRight[o] = "read" /\ readFenced)
  /\ Len(serverF.releaseRoot) < MaxLog
  /\ LET c == CoverFor(o)
         p == [reservations[o] EXCEPT
               !.status = "released", !.cover = c, !.authsnap = auth,
               !.rostersnap = roster, !.cutRev = authRev,
               !.branch = serverF.branch, !.epoch = serverF.epoch,
               !.kappa = Kappa(o,c,authRev,serverF),
               !.certificate = Certificate(o,c,auth,authRev,serverF),
               !.envelope = Envelope(o,c,auth,authRev,serverF),
               !.releaseLocal = localF, !.releaseServer = serverF,
               !.releaseFenced = readFenced]
         newF == [serverF EXCEPT !.releaseRoot = Append(@,<<o,OpCert[o]>>)]
     IN /\ \A s \in c : AuthAt(auth,s)
        /\ reservations' = [reservations EXCEPT ![o] = p]
        /\ serverF' = newF /\ localF' = newF /\ ready' = TRUE
        /\ frontierHist' = Append(frontierHist,newF)
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,exposed,emittedEnvelope,exposureLocal,exposureServer,
       exposureFenced,consumeCell,occurrences,rejectedRecoveries,candidate,
       canonicalHist,currentCanonical>>

Expose(o) ==
  /\ reservations[o] # NoReservation
  /\ reservations[o].status = "released"
  /\ ready /\ localF = serverF
  /\ ~(OpRight[o] = "read" /\ readFenced)
  /\ o \notin exposed
  /\ <<o,OpCert[o]>> \in SeqToSet(serverF.releaseRoot)
  /\ exposed' = exposed \cup {o}
  /\ emittedEnvelope' = [emittedEnvelope EXCEPT ![o] = reservations[o].envelope]
  /\ exposureLocal' = [exposureLocal EXCEPT ![o] = localF]
  /\ exposureServer' = [exposureServer EXCEPT ![o] = serverF]
  /\ exposureFenced' = [exposureFenced EXCEPT ![o] = readFenced]
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,consumeCell,occurrences,serverF,localF,ready,
       frontierHist,rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

UseSupportSet(o,m) ==
  IF OpRight[o] = "read" THEN {CurrentFrom(reservations[o].authsnap,m,"read")}
  ELSE IF OpRight[o] = "admit" THEN {
    CurrentFrom(reservations[o].authsnap,OpActor[o],"admin"),
    CurrentFrom(reservations[o].authsnap,OpTarget[o],"admit")}
  ELSE {CurrentFrom(reservations[o].authsnap,OpActor[o],OpRight[o])}

Consume(o,m) ==
  /\ Len(frontierHist) < MaxHistory
  /\ o \in exposed
  /\ reservations[o] # NoReservation
  /\ emittedEnvelope[o] = reservations[o].envelope
  /\ ready /\ localF = serverF
  /\ ~(OpRight[o] = "read" /\ readFenced)
  /\ consumeCell[o][m] = "unused"
  /\ Len(serverF.spentRoot) < MaxLog
  /\ Len(occurrences) < MaxOccurrences
  /\ LET supports == UseSupportSet(o,m)
         newF == [serverF EXCEPT !.spentRoot = Append(@,<<o,OpCert[o],m>>)]
         occ == [occurrenceId |-> Len(occurrences),
                 eventKind |-> OpDirection[o], recipient |-> m, opid |-> o,
                 certid |-> OpCert[o], witnessKind |-> "prov",
                 support |-> CHOOSE s \in supports : TRUE,
                 supportSet |-> supports, cutRev |-> reservations[o].cutRev,
                 frontier |-> serverF]
     IN /\ supports \subseteq reservations[o].cover
        /\ consumeCell' = [consumeCell EXCEPT ![o][m] = "spent"]
        /\ occurrences' = Append(occurrences,occ)
        /\ serverF' = newF /\ localF' = newF /\ ready' = TRUE
        /\ frontierHist' = Append(frontierHist,newF)
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,rejectedRecoveries,candidate,
       canonicalHist,currentCanonical>>

\* Negative-control operator: not included in Next. It records a malformed
\* successful effect as unattributed/bottom instead of deleting it.
ConsumeUnattributed(o,m) ==
  /\ o \in exposed /\ consumeCell[o][m] = "unused"
  /\ Len(occurrences) < MaxOccurrences
  /\ occurrences' = Append(occurrences,
       [occurrenceId |-> Len(occurrences),eventKind |-> OpDirection[o],
        recipient |-> m,opid |-> o,certid |-> OpCert[o],
        witnessKind |-> "unattributed",support |-> BottomSupport(OpRight[o]),
        supportSet |-> {BottomSupport(OpRight[o])},
        cutRev |-> reservations[o].cutRev,frontier |-> serverF])
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,serverF,localF,ready,
       frontierHist,rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

BuildRepair(m,cv) ==
  /\ candidate = NoCandidate
  /\ \E s \in pendingRead : s[1] = m
  /\ candidate' = [candidateId |-> Len(canonicalHist),member |-> m,
       parentBranch |-> serverF.branch,parentEpoch |-> serverF.epoch,
       publicValid |-> TRUE,clientValid |-> cv,requiredRevision |-> authRev]
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,occurrences,serverF,localF,
       ready,frontierHist,rejectedRecoveries,canonicalHist,currentCanonical>>

Canonicalize ==
  /\ candidate # NoCandidate
  /\ candidate.publicValid
  /\ candidate.parentBranch = serverF.branch
  /\ candidate.parentEpoch = serverF.epoch
  /\ serverF.branch < MaxEpoch /\ serverF.epoch < MaxEpoch
  /\ Len(canonicalHist) < MaxHistory /\ Len(frontierHist) < MaxHistory
  /\ LET removed == {s \in pendingRead : s[1] = candidate.member}
         newF == [serverF EXCEPT !.branch = @+1, !.epoch = @+1,
                   !.exclusions = @ \cup removed]
         record == [candidateId |-> candidate.candidateId,
                    member |-> candidate.member,
                    parentBranch |-> candidate.parentBranch,
                    parentEpoch |-> candidate.parentEpoch,
                    childBranch |-> newF.branch,childEpoch |-> newF.epoch,
                    publicValid |-> candidate.publicValid,
                    clientValid |-> candidate.clientValid]
     IN /\ roster' = roster \ {candidate.member}
        /\ pendingRead' = pendingRead \ removed
        /\ serverF' = newF /\ frontierHist' = Append(frontierHist,newF)
        /\ canonicalHist' = Append(canonicalHist,record)
        /\ currentCanonical' = record
  /\ candidate' = NoCandidate /\ ready' = FALSE
  /\ UNCHANGED <<auth,authHist,authRev,readFenced,closedGrant,reservations,
       exposed,emittedEnvelope,exposureLocal,exposureServer,exposureFenced,
       consumeCell,occurrences,localF,rejectedRecoveries>>

ProcessAndPersist ==
  /\ currentCanonical # NoCanonical
  /\ currentCanonical.clientValid
  /\ localF' = serverF /\ ready' = TRUE /\ readFenced' = (pendingRead # {})
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,closedGrant,
       reservations,exposed,emittedEnvelope,exposureLocal,exposureServer,
       exposureFenced,consumeCell,occurrences,serverF,frontierHist,
       rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

RecoverCurrent ==
  /\ ~ready \/ localF # serverF
  /\ currentCanonical = NoCanonical \/ currentCanonical.clientValid
  /\ localF' = serverF /\ ready' = TRUE
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,occurrences,serverF,
       frontierHist,rejectedRecoveries,candidate,canonicalHist,currentCanonical>>

IncomparableGens ==
  [m \in Members |-> [r \in Rights |->
    IF m = "A" /\ r = "read" /\ serverF.generations[m][r] > 0
    THEN serverF.generations[m][r]-1 ELSE serverF.generations[m][r]]]
IncomparableCandidate == [serverF EXCEPT
  !.branch = IF @ < MaxEpoch THEN @+1 ELSE @,
  !.generations = IncomparableGens]

RejectStale ==
  /\ ~FrontierDominates(InitialFrontier,serverF)
  /\ "stale" \notin rejectedRecoveries
  /\ rejectedRecoveries' = rejectedRecoveries \cup {"stale"}
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,occurrences,serverF,localF,
       ready,frontierHist,candidate,canonicalHist,currentCanonical>>

RejectIncomparable ==
  /\ ~FrontierDominates(IncomparableCandidate,serverF)
  /\ "incomparable" \notin rejectedRecoveries
  /\ rejectedRecoveries' = rejectedRecoveries \cup {"incomparable"}
  /\ UNCHANGED <<auth,authHist,authRev,roster,pendingRead,readFenced,
       closedGrant,reservations,exposed,emittedEnvelope,exposureLocal,
       exposureServer,exposureFenced,consumeCell,occurrences,serverF,localF,
       ready,frontierHist,candidate,canonicalHist,currentCanonical>>

Next ==
  (\E m \in Members,r \in Rights : PolicyDeny(m,r))
  \/ (\E m \in Members,r \in Rights : PolicyAllow(m,r))
  \/ (\E o \in OpIds : Allocate(o))
  \/ (\E o \in OpIds : AuthorizeRelease(o))
  \/ (\E o \in OpIds : Expose(o))
  \/ (\E o \in OpIds,m \in Members : Consume(o,m))
  \/ (\E m \in Members,cv \in BOOLEAN : BuildRepair(m,cv))
  \/ Canonicalize \/ ProcessAndPersist \/ RecoverCurrent
  \/ RejectStale \/ RejectIncomparable

ReadyFrontier == ready => localF = serverF
FrontierCurrent == serverF.revision = authRev /\ serverF.generations = GenMap(auth)
FrontierMonotone ==
  \A i \in 1..(Len(frontierHist)-1) : FrontierDominates(frontierHist[i+1],frontierHist[i])

ReleaseExact ==
  /\ NoDuplicates(serverF.releaseRoot)
  /\ \A o \in OpIds : reservations[o] # NoReservation /\ reservations[o].status = "released" =>
       /\ <<o,reservations[o].certid>> \in SeqToSet(serverF.releaseRoot)
       /\ reservations[o].releaseLocal = reservations[o].releaseServer
       /\ reservations[o].cutRev = reservations[o].releaseServer.revision
       /\ reservations[o].kappa = Kappa(o,reservations[o].cover,
            reservations[o].cutRev,reservations[o].releaseServer)
       /\ reservations[o].certificate = Certificate(o,reservations[o].cover,
            reservations[o].authsnap,reservations[o].cutRev,
            reservations[o].releaseServer)
       /\ reservations[o].envelope = Envelope(o,reservations[o].cover,
            reservations[o].authsnap,reservations[o].cutRev,
            reservations[o].releaseServer)
       /\ \A s \in reservations[o].cover : AuthAt(reservations[o].authsnap,s)
       /\ ~(reservations[o].right = "read" /\ reservations[o].releaseFenced)

AdmitJointCover ==
  \A o \in OpIds : reservations[o] # NoReservation /\ reservations[o].status = "released"
    /\ reservations[o].right = "admit" =>
      reservations[o].cover = {
        CurrentFrom(reservations[o].authsnap,reservations[o].actor,"admin"),
        CurrentFrom(reservations[o].authsnap,reservations[o].target,"admit")}

EnvelopeEquality ==
  \A o \in exposed :
    /\ emittedEnvelope[o] = reservations[o].envelope
    /\ exposureLocal[o] = exposureServer[o]
    /\ ~(OpRight[o] = "read" /\ exposureFenced[o])

ConsumptionOneShot ==
  /\ NoDuplicates(serverF.spentRoot)
  /\ \A o \in OpIds,m \in Members : consumeCell[o][m] = "spent" <=>
       <<o,OpCert[o],m>> \in SeqToSet(serverF.spentRoot)

TotalOccurrences ==
  /\ Cardinality({occurrences[i].occurrenceId : i \in DOMAIN occurrences}) = Len(occurrences)
  /\ \A i \in DOMAIN occurrences :
       /\ occurrences[i].witnessKind \in WitnessKinds
       /\ (occurrences[i].witnessKind = "unattributed" =>
            /\ occurrences[i].support = BottomSupport(OpRight[occurrences[i].opid])
            /\ occurrences[i].supportSet = {occurrences[i].support})
       /\ (occurrences[i].witnessKind = "prov" =>
            /\ occurrences[i].support[1] # Bottom
            /\ occurrences[i].support \in occurrences[i].supportSet)

SuccessfulEffectsAuthorized ==
  \A i \in DOMAIN occurrences :
    LET x == occurrences[i]
        p == reservations[x.opid]
    IN /\ x.witnessKind = "prov"
       /\ x.supportSet \subseteq p.cover
       /\ \A s \in x.supportSet : AuthAt(p.authsnap,s)

ReauthorizationFresh ==
  \A i \in 1..(Len(authHist)-1),m \in Members,r \in Rights :
    (~authHist[i][m][r][1] /\ authHist[i+1][m][r][1]) =>
      /\ authHist[i+1][m][r][2] > authHist[i][m][r][2]
      /\ authHist[i+1][m][r][3] > authHist[i][m][r][3]
      /\ authHist[i+1][m][r][4] > authHist[i][m][r][4]

CanonicalParentCAS ==
  /\ \A i \in DOMAIN canonicalHist : canonicalHist[i].publicValid
  /\ (Len(canonicalHist) > 0 =>
       /\ canonicalHist[1].parentBranch = 0
       /\ canonicalHist[1].parentEpoch = 0)
  /\ \A i \in 1..(Len(canonicalHist)-1) :
       /\ canonicalHist[i+1].parentBranch = canonicalHist[i].childBranch
       /\ canonicalHist[i+1].parentEpoch = canonicalHist[i].childEpoch

ReadyClientValid == ready /\ currentCanonical # NoCanonical => currentCanonical.clientValid

Safety == TypeOK /\ ReadyFrontier /\ FrontierCurrent /\ FrontierMonotone
          /\ ReleaseExact /\ AdmitJointCover /\ EnvelopeEquality
          /\ ConsumptionOneShot /\ TotalOccurrences
          /\ SuccessfulEffectsAuthorized /\ ReauthorizationFresh
          /\ CanonicalParentCAS /\ ReadyClientValid

ConfigOpRight == [o \in OpIds |-> CASE
  o = "read-1" \/ o = "read-2" -> "read" [] o = "write-1" -> "write"
  [] o = "admin-1" -> "admin" [] OTHER -> "admit"]
ConfigOpActor == [o \in OpIds |-> "A"]
ConfigOpTarget == [o \in OpIds |-> IF o = "admit-1" THEN "B" ELSE NoTarget]
ConfigOpCert == [o \in OpIds |-> o]
ConfigOpDirection == [o \in OpIds |-> IF ConfigOpRight[o] = "read" THEN "recover" ELSE "acceptedAct"]
ConfigOpPayload == [o \in OpIds |-> o]
ConfigOpAux == [o \in OpIds |-> "application"]

Spec == Init /\ [][Next]_vars
=============================================================================
