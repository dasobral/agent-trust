# Source build notes

The two LaTeX deliverables in this directory are self-contained. Build them
from the workspace root with:

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error \
  -outdir=output/pdf output/source/Authorization-Capability-Coherence-Third-Edition-Study-Notes.tex

latexmk -xelatex -interaction=nonstopmode -halt-on-error \
  -outdir=output/pdf output/source/Authorization-Capability-Coherence-Article-Draft.tex
```

Each source embeds its bibliography so that the PDF can be reproduced without
an external bibliography database. The original Second Edition remains
unchanged in `upload/`; the Third Edition is a rebuilt, self-contained source
document because no editable Second-Edition source was supplied.
