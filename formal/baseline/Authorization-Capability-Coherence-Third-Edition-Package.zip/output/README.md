# Authorization–Capability Coherence — Third Edition research package

Start with the Third Edition study notes for the full model and derivations,
or the article draft for the paper-oriented presentation. Both PDFs have
self-contained editable LaTeX sources.

## Status

This is a repaired research notebook, a conditional LAP-MLS realization and
article draft, and bounded executable structural evidence. The exact final-RFC
MLS/ETK removal-to-secrecy bridge remains an **open proof obligation**. Neither
the package nor its checker establishes an unconditional computational security
theorem or a general mechanized proof.

## Contents

- `output/pdf/`: study notes and article PDFs.
- `output/source/`: editable LaTeX and build instructions.
- `output/artifact/`: Python checker, acceptance tests, TLA+ audit companion,
  machine-readable results, and preserved failing/passing transcripts.
- `output/EXECUTION-AND-VERIFICATION-REPORT.md`: final evidence and limitations.
- `reports/`: formal, realization, prior-art, and artifact audit records.
- `work/`: final review records and package acceptance script.

## Reproduce

From the unpacked package root, with Python 3.12 or compatible Python installed:

```sh
python3 output/artifact/check_acc_model.py --json
python3 output/artifact/test_acc_model.py
```

The checker uses the Python standard library. Its exhaustive search has depth
three; complete-operation, repair, and mutant scenarios are separate directed
runs. Read `output/artifact/README.md` before interpreting the evidence.
TLC was unavailable and the TLA+ companion was not executed.

To rebuild the documents, install XeLaTeX and latexmk, then follow
`output/source/README.md`. With Poppler's `pdfinfo` available, run:

```sh
python3 work/verify_package.py
```

That script checks package structure, selected claim markers, PDF page counts,
and executable model results. It does not replace mathematical peer review or
visual inspection.

The supplied Second Edition remains unchanged in the original session and is
not duplicated in this release archive.
