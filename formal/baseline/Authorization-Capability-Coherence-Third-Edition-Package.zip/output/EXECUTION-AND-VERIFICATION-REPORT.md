# ACC handoff — execution and verification report

Final verification: 5 September 2026

## Outcome boundary

The supplied Second Edition PDF remains unchanged. Because no editable source
was supplied, the Third Edition is rebuilt as a self-contained LaTeX research
notebook rather than presented as a byte-for-byte PDF edit. The article is
written from a blank structure.

The package completes the formal/interface and systems-realization work. It
does **not** claim a completed end-to-end computational proof for final-RFC
MLS: the exact `Bridge_ETK_remove` lemma is deliberately recorded as an open
cryptographic proof obligation. This narrows the publishable status rather
than silently treating ETK as a theorem about the authorization adapter.

## Executed phases

1. **Formal repair.** Replaced the probability-bearing fixed-trace capability
   predicate with occurrence-indexed successful-use events and total
   provenance; introduced the unauthorized bottom support; renamed the target
   to `AuthCapSafe`; replaced exact global support completeness with a sound
   conservative cover; typed the frontier/fork carry rule; separated the
   elementary structural theorem, mechanism bridge, and common-experiment
   bad-event layer; and added the missing pre-resumption exclusion event.
2. **Prior-art audit.** Reviewed the required revocation, dynamic access
   control, virtual-synchrony, CGKA/DCGKA, MLS, TreeSync, external-operations,
   key-regression, and mediated-cryptography families. Claims were killed or
   narrowed where precedents apply. In particular, use-boundary mediation is
   not claimed as new, and Boldyreva--Goyal--Kumar is classified as revocable
   IBE.
3. **Concrete realization.** Specified LAP-MLS: a linearizable authorization,
   permit, fence, release, consumption, and frontier service; a cycle-free
   two-phase immutable logical-object commitment; rollback-resistant release
   and spent roots; an authorization-bound MLS successor; mandatory adapters;
   read-group fencing; and grant-scoped write/admin/admit validation.
4. **Theorems.** Stated the deterministic `GoodTrace_0 => AuthCapSafe_0`
   theorem, a conditional common-experiment computational theorem, and a
   stable-suffix progress theorem with explicit service, delivery, continuing
   committer, sequencer-validity, persistence, and fairness premises.
5. **Bounded artifact.** Rebuilt the executable finite abstraction under TDD,
   added real reachable mutant transition systems, and aligned the audit TLA+
   model/configuration. TLC was unavailable, so no TLC or TLA syntax-execution
   claim is made.
6. **Documents.** Third Edition and article build/visual verification are
   recorded below after the final render gate.

## Bounded executable evidence

Fresh command:

```sh
python3 output/artifact/check_acc_model.py --json
```

Verified result (fresh root-agent rerun):

- 5,712 reachable states through depth 3;
- 6,098 generated successful transitions;
- zero invariant violations in the explored good model;
- positive complete exercises for read, write, admin, and admit;
- a finite eight-step read-repair/resumption witness; and
- 12 reachable negative controls: omitted cover, total provenance, envelope
  equality, duplicate release, duplicate consume, spent-root rollback, stale
  release revision, fresh reauthorization material, parent CAS, client
  validity, frontier readiness, and read fence.

The acceptance harness reports 15 passing tests. Three focused final-review
regressions cover non-read operation during a read fence, the epoch limit, and
admit support generated independently of the claimed cover. Earlier failing
runs are retained as `RED-transcript.txt`, `RED2-transcript.txt`, and
`RED3-transcript.txt`. Full current results accompany the package.

Reproduction commands:

```sh
python3 output/artifact/check_acc_model.py --json
python3 output/artifact/test_acc_model.py
```

The three-action exploration does not reach every full transaction. Complete
positive and repair scenarios, and mutant traces, are separate directed runs;
they must not be interpreted as exhaustive verification at their longer depths.
The TLA+ module is an unexecuted audit companion, not a proven equivalent
encoding of the Python model.

## Document build and render evidence

Third Edition: 62 pages, 18,121 whitespace-delimited LaTeX source words.
Article: 15 pages. Both are self-contained editable LaTeX sources.
Fresh latexmk/XeLaTeX build checks succeeded. Final logs have no overfull
boxes or undefined references. Contact sheets cover all notebook pages;
readable renderings of the release protocol and composition theorem were
inspected. The article received full-source independent review, contact-sheet
inspection, and readable checks of revised certificate, bad-event, and
validator pages. No clipping or overlap was observed.

Final integration corrected mixed-source support typing, exact guard/source
bad-event bindings, APF-scoped repair authorization, and signed pre-release
frontier plus append-only release evidence. These corrections are reflected
in both documents. The final Third Edition supersedes intermediate audit
formulas where the latter omit these conditions.

## Mandatory-language gate

The package gate checks deterministic target naming, bottom/provenance and
sound-cover markers, four-right coverage, explicit open bridge and stable-suffix
status, obsolete-name exclusions, PDF presence/page counts, and current checker
results. Final source review confirms the structural theorem is sufficient
only, the computational theorem is conditional, the bounded runs are not an
unbounded proof, and the TLA+ companion remains unexecuted.

Package acceptance command: `python3 work/verify_package.py`.
The gate is a reproducibility and consistency check, not a proof checker for
the mathematical arguments.

## Deliverables

- `output/source/Authorization-Capability-Coherence-Third-Edition-Study-Notes.tex`
- `output/pdf/Authorization-Capability-Coherence-Third-Edition-Study-Notes.pdf`
- `output/source/Authorization-Capability-Coherence-Article-Draft.tex`
- `output/pdf/Authorization-Capability-Coherence-Article-Draft.pdf`
- `output/artifact/ACCModel.tla`
- `output/artifact/ACCModel.cfg`
- `output/artifact/check_acc_model.py`
- `output/artifact/test_acc_model.py`
- `output/artifact/README.md`

## Residual limitations

- `Bridge_ETK_remove` is open. No source in the audited literature was treated
  as already proving the exact LAP-MLS removal-to-ETK freshness bridge.
- The executable artifact is finite and depth-bounded. It is not an unbounded
  mechanized proof, a TLC result, a cryptographic reduction, or a liveness
  model-checking result.
- Linearizability, honest mandatory adapters, durable monotonic APF storage,
  sound cover construction, and the progress theorem's delivery/fairness
  premises remain explicit assumptions unless discharged by an implementation.
- The targeted prior-art pass narrows the claims but is not an absolute novelty
  certification; a final realization-specific search remains advisable before
  submission.
