# Primary-source verification lockfile

Checked 26 August 2026. This note fixes the factual scope used in the Third
Edition and article; it is not an exhaustive novelty certification.

## MLS and secure group messaging

- RFC 9420 defines MLS. A Proposal does not change group state until a Commit;
  a Remove requires an UpdatePath; external senders may submit Remove and
  GroupContextExtensions proposals when configured; GroupContext extensions
  are confirmed through the key schedule. Application-level access-control
  validation remains outside the protocol core.
- Cremers, Günsay, Wesselkamp, and Zhao, ePrint 2025/229, version 2.0 (11 April
  2026), models final-RFC external proposals and external commits. The ePrint
  record describes it as a major revision of an IACR publication in EUROCRYPT
  2026 and reports weaker PCS in the presence of external operations. It is a
  component theorem, not a proof of the LAP-MLS authorization adapter.
- Alwen, Coretti, Dodis, and Tselekounis, ePrint 2021/1083 / CCS 2021, gives a
  modular SGM analysis built from CGKA, forward-secure group AEAD, and related
  primitives. It analyzes an MLS-era construction but does not state the
  cross-system authorization-cut theorem in this project.
- Wallez et al., USENIX Security 2023, provides an executable, machine-checked
  F* specification and proofs for TreeSync group-state consistency, integrity,
  and authentication. Do not extend that result to external authorization
  provenance or authorization continuity.
- Weidner et al., CCS 2021, defines DCGKA, provides a practical construction,
  and proves security for decentralized secure group messaging. It is the
  proven causal/decentralized group-state comparator.

## Revocation and dynamic access-control precedents

- Boneh, Ding, Tsudik, and Wong, USENIX Security 2001, places a semi-trusted
  mediator at the cryptographic-use boundary for fast revocation. This kills
  any priority claim for use-boundary mediation.
- Fu, Kamara, and Kohno, NDSS 2006, shows naïve composition of key rotation with
  other cryptographic objects can be insecure and develops key regression.
- Boldyreva, Goyal, and Kumar, CCS 2008, is revocable identity-based encryption
  (IBE), not attribute-based encryption.
- Sahai, Seyalioglu, and Waters, CRYPTO 2012, studies dynamic credentials and
  ciphertext delegation, including revocable storage for ABE.
- Garrison et al., IEEE S&P 2016, studies cryptographic enforcement of dynamic
  RBAC and documents high update/revocation cost. Any conclusion about exact
  support covers and global agreement is this project's inference, not their
  theorem.
- Birman and Joseph, SOSP 1987, establishes virtual synchrony as prior art for
  group membership views and coordinated delivery, not authorization cuts.

## URLs

- https://www.rfc-editor.org/rfc/rfc9420.html
- https://eprint.iacr.org/2025/229
- https://eprint.iacr.org/2021/1083
- https://www.usenix.org/conference/usenixsecurity23/presentation/wallez
- https://martin.kleppmann.com/2021/11/17/decentralized-key-agreement.html
- https://www.usenix.org/conference/10th-usenix-security-symposium/presentation/method-fast-revocation-public-key-certificate
- https://www.ndss-symposium.org/ndss2006/key-regression-enabling-efficient-key-distribution-secure-distributed-storage/
- https://www.microsoft.com/en-us/research/publication/identity-based-encryption-efficient-revocation/
- https://eprint.iacr.org/2012/437
- https://arxiv.org/abs/1602.09069
- https://doi.org/10.1145/37499.37515
