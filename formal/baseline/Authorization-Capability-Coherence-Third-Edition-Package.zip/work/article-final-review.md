# Article final review

Reviewed the complete article source against `reports/formal-repair-audit.md`, `reports/mls-realization-design.md`, and `work/article-authoring-spec.md`. Initial verdict: corrections required. Root subsequently authorized this reviewer to implement the corrections in the article.

Material corrections implemented:

1. Bound support-omission, resumption, and post-exclusion bad events to the exact exposure occurrence and its successful guard. Resumption tests denial of the exact source, rather than inferring that every member of an unauthorized joint support is denied. Post-exclusion failure additionally requires the operation's qualifying successor lineage, so an old pre-cut operation recovered later is not mislabeled. This also corrects a source-denial versus joint-support mismatch inherited from the frozen formal report.
2. Restored the frozen realization's narrowly scoped APF repair authorization path. A continuing reader need not possess a human admin grant to execute precisely the certified removal/binding/UpdatePath maintenance. Its APF maintenance-authority support is explicit, and unrelated state changes remain rejected. The object map, admin validator, and repair witness agree.
3. Added the checked pre-release frontier hash to the signed operation certificate. Release returns signed post-release checkpoint/inclusion/append-only evidence, and emission validates it. Binding the pre-release frontier avoids a certificate/log-root cycle.
4. Root repaired the heterogeneous-source support type before these changes: output right and each source's grant right are distinct, allowing the admin-plus-admit conjunction.

Claim discipline otherwise passes: deterministic occurrence semantics; explicit bottom; sound cover separated from runtime operand authentication; elementary two-inclusion theorem separated from realization; common probability space and conditional operational assumptions; explicit open ETK removal bridge; bounded artifact and unavailable-TLC limitations. No unconditional cryptographic proof is claimed.

Build and visual verification are recorded below after final rerun. These checks do not certify the open ETK bridge or the independently reviewed artifact.

Final verification: PASS for the repaired article's structural/interface claim scope. Two clean XeLaTeX passes produced a 15-page PDF; the final log has no undefined references/citations, overfull boxes, or fatal errors. Rendered pages 7–14 and inspected the changed release/certificate and bad-event pages at readable resolution; no clipping or overlap was observed. Root retains responsibility for the package-level artifact gate and final persistence.
