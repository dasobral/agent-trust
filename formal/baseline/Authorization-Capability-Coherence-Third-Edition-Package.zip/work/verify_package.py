#!/usr/bin/env python3
"""Acceptance gate for the ACC handoff package.

Run from the workspace root after both LaTeX builds. This is intentionally
strict about the handoff's mandatory deliverables and claim-language markers.
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK = ROOT / "output/source/Authorization-Capability-Coherence-Third-Edition-Study-Notes.tex"
ARTICLE = ROOT / "output/source/Authorization-Capability-Coherence-Article-Draft.tex"
NOTEBOOK_PDF = ROOT / "output/pdf/Authorization-Capability-Coherence-Third-Edition-Study-Notes.pdf"
ARTICLE_PDF = ROOT / "output/pdf/Authorization-Capability-Coherence-Article-Draft.pdf"
REQUIRED = [
    NOTEBOOK,
    ARTICLE,
    NOTEBOOK_PDF,
    ARTICLE_PDF,
    ROOT / "output/artifact/ACCModel.tla",
    ROOT / "output/artifact/ACCModel.cfg",
    ROOT / "output/artifact/check_acc_model.py",
    ROOT / "output/artifact/test_acc_model.py",
    ROOT / "output/artifact/README.md",
    ROOT / "output/EXECUTION-AND-VERIFICATION-REPORT.md",
]


def must(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def pdf_pages(path: Path) -> int:
    result = subprocess.run(["pdfinfo", str(path)], check=True, capture_output=True, text=True)
    match = re.search(r"^Pages:\s+(\d+)$", result.stdout, re.MULTILINE)
    must(match is not None, f"no page count in {path}")
    return int(match.group(1))


def check_source(path: Path, *, article: bool) -> None:
    text = path.read_text(encoding="utf-8")
    must("\\begin{document}" in text and "\\end{document}" in text, f"incomplete LaTeX: {path}")
    for marker in ("AuthCapSafe", "GoodTrace", "unattributed", "bottom", "sound cover"):
        must(marker.lower() in text.lower(), f"missing {marker} in {path.name}")
    must("Bridge" in text and "OPEN" in text, f"open MLS bridge not disclosed in {path.name}")
    must("stable suffix" in text.lower(), f"progress assumptions incomplete in {path.name}")
    must("read" in text and "write" in text and "admin" in text and "admit" in text,
         f"four-right coverage missing in {path.name}")
    must("non-negligible probability" not in text, f"stale trace-probability phrase in {path.name}")
    if article:
        must("ACCSafe" not in text, "obsolete target name appears in article")
        must("adversarial review history" not in text.lower(), "internal review history leaked into article")
    else:
        occurrences = [m.start() for m in re.finditer(r"ACCSafe", text)]
        must(len(occurrences) <= 1, "obsolete target name appears more than once in notebook")


def check_model() -> None:
    result = subprocess.run(
        ["python3", str(ROOT / "output/artifact/check_acc_model.py"), "--json"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
        timeout=20,
    )
    report = json.loads(result.stdout.strip().splitlines()[-1])
    must(report["invariant_violations"] == 0, "bounded model has invariant violations")
    must(set(report["positive_exercises"]) == {"read", "write", "admin", "admit"},
         "bounded model does not exercise every right")
    must(set(report["mutant_counterexamples"]) == {
        "omitted_cover", "total_provenance", "envelope_equality",
        "duplicate_release", "duplicate_consume", "spent_root_rollback",
        "stale_release_revision", "fresh_reauthorization_material",
        "parent_cas", "client_validity", "frontier_readiness", "read_fence",
    }, "mutant coverage changed")
    must(all(item["trace"] and item["violations"] for item in report["mutant_counterexamples"].values()), "empty negative-control evidence")


def main() -> None:
    missing = [str(path.relative_to(ROOT)) for path in REQUIRED if not path.is_file()]
    must(not missing, "missing deliverables: " + ", ".join(missing))
    check_source(NOTEBOOK, article=False)
    check_source(ARTICLE, article=True)
    must(pdf_pages(NOTEBOOK_PDF) >= 25, "notebook is not a substantive rebuilt monograph")
    must(pdf_pages(ARTICLE_PDF) >= 10, "article draft is unexpectedly short")
    check_model()
    report_text = (ROOT / "output/EXECUTION-AND-VERIFICATION-REPORT.md").read_text()
    must("PENDING_FINAL" not in report_text, "final verification report is unfinished")
    for stem in (NOTEBOOK.stem, ARTICLE.stem):
        log = ROOT / "output/pdf" / (stem + ".log")
        if log.exists():
            log_text = log.read_text(errors="replace")
            must("Overfull" not in log_text, f"layout overflow in {stem}")
            must("undefined references" not in log_text, f"unresolved references in {stem}")
    print("PACKAGE ACCEPTANCE: PASS")


if __name__ == "__main__":
    main()
